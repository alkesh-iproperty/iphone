//
//  AppDelegate.m
//  ResidentApp
//
//  Created by TheAppGuruz-New-6 on 07/07/15.
//  Copyright (c) 2015 TheAppGuruz-New-6. All rights reserved.
//

#import "AppDelegate.h"
#import "PayPalMobile.h"
#import "ALAssetsLibrary+CustomPhotoAlbum.h"
#import "WebsiteViewController.h"
#import "HomeScreenViewController.h"
#import "WebsiteViewController.h"

@interface AppDelegate ()

@end

@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    // Override point for customization after application launch.
    
    
    if ([application respondsToSelector:@selector(isRegisteredForRemoteNotifications)])
    {
        // iOS 8 Notifications
        UIUserNotificationSettings *settings = [UIUserNotificationSettings settingsForTypes:(UIRemoteNotificationTypeBadge
                                                                                             |UIRemoteNotificationTypeSound
                                                                                             |UIRemoteNotificationTypeAlert) categories:nil];
        [application registerUserNotificationSettings:settings];
    } else {
        // iOS < 8 Notifications
        UIRemoteNotificationType myTypes = UIRemoteNotificationTypeBadge | UIRemoteNotificationTypeAlert | UIRemoteNotificationTypeSound;
        [application registerForRemoteNotificationTypes:myTypes];
    }
    ALAssetsLibrary* libraryFolderSozialConnectVideo = [[ALAssetsLibrary alloc] init];
    [libraryFolderSozialConnectVideo addAssetsGroupAlbumWithName:@"Navsix Maintenance" resultBlock:^(ALAssetsGroup *group)
     {
     } failureBlock:^(NSError *error) {
     }];
    NSDictionary* userInfo = [launchOptions objectForKey:UIApplicationLaunchOptionsRemoteNotificationKey];
    if(userInfo != nil)
        [[NSUserDefaults standardUserDefaults] setObject:userInfo forKey:@"NotificationObject"];
    else
        [[NSUserDefaults standardUserDefaults] setObject:nil forKey:@"NotificationObject"];
    [[NSUserDefaults standardUserDefaults] synchronize];

//
//    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Notification" message:[NSString stringWithFormat:@"Dictionary %@",userInfo] delegate:self cancelButtonTitle:nil otherButtonTitles:@"ok", nil];
//    [alert show];

    return YES;
}

- (void)applicationWillResignActive:(UIApplication *)application {
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
}

- (void)applicationDidEnterBackground:(UIApplication *)application {
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}

- (void)applicationWillEnterForeground:(UIApplication *)application {
    // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
}

- (void)applicationDidBecomeActive:(UIApplication *)application {
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}

- (void)applicationWillTerminate:(UIApplication *)application {
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}

- (void)application:(UIApplication*)application didRegisterForRemoteNotificationsWithDeviceToken:(NSData*)deviceToken
{
    NSString* strDeviceToken = [[[[deviceToken description]
                                stringByReplacingOccurrencesOfString: @"<" withString: @""]
                               stringByReplacingOccurrencesOfString: @">" withString: @""]
                              stringByReplacingOccurrencesOfString: @" " withString: @""];
    [[NSUserDefaults standardUserDefaults] setValue:strDeviceToken forKey:@"deviceToken"];
    [[NSUserDefaults standardUserDefaults] synchronize];
    NSLog(@"My token is: %@", strDeviceToken);
    
    // api call krwani . . .
}

/*
 - (void)application:(UIApplication*)application didRegisterForRemoteNotificationsWithDeviceToken:(NSData*)deviceToken
 {
 //	NSLog(@"My token is: %@", deviceToken);
 //
 // NSString* newToken = [deviceToken description];
 //	newToken = [newToken stringByTrimmingCharactersInSet:[NSCharacterSet characterSetWithCharactersInString:@"<>"]];
 //	newToken = [newToken stringByReplacingOccurrencesOfString:@" " withString:@""];
 //
 //	NSLog(@"My token is: %@", newToken);
 //
 // [[NSUserDefaults standardUserDefaults]setValue:newToken forKey:@"DToken"];
 
 // [self saveToken:newToken];
 
 }
 
 */


- (void)application:(UIApplication *)application didReceiveRemoteNotification:(NSDictionary *)userInfo
{
    NSLog(@"user infooo %@",userInfo);
    UIApplicationState state = [application applicationState];
    if (state == UIApplicationStateActive)
    {
        if([[userInfo valueForKey:@"content_type"] isEqualToString:@"2"] || [[userInfo valueForKey:@"content_type"] isEqualToString:@"3"])
        {
            UIAlertView *alert=[[UIAlertView alloc]initWithTitle:@"Notification" message:[[userInfo valueForKey:@"aps"] valueForKey:@"alert"] delegate:self cancelButtonTitle:@"Cancel" otherButtonTitles:@"Go", nil];
            notificationInfo = userInfo;
            [alert show];
            
        }
        else
        {
            UIAlertView *alert=[[UIAlertView alloc]initWithTitle:@"Notification" message:[[userInfo valueForKey:@"aps"] valueForKey:@"alert"] delegate:nil cancelButtonTitle:nil otherButtonTitles:@"Ok", nil];
            [alert show];
        }
    }

    
     NSLog(@"remote notification: %@",[userInfo description]);
}


- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if(buttonIndex==1)
    {
        UIStoryboard *storyBoard = [UIStoryboard storyboardWithName:@"Main" bundle:[NSBundle mainBundle]];
        if([[notificationInfo valueForKey:@"content_type"] isEqualToString:@"2"])
        {
            UINavigationController *nav = (UINavigationController*)self.window.rootViewController;
            if(![nav.visibleViewController isKindOfClass:[HomeScreenViewController class]])
            {
                for (id controller in [nav.visibleViewController.navigationController viewControllers])
                {
                    if ([controller isKindOfClass:[HomeScreenViewController class]])
                    {
                        [nav.visibleViewController.navigationController popToViewController:controller animated:NO];
                        break;
                    }
                }
            
            }
            WebsiteViewController *websiteViewController = [storyBoard instantiateViewControllerWithIdentifier:@"WebsiteViewController"];
            SlidingViewController *sliding = (SlidingViewController*)nav.visibleViewController;
            websiteViewController.userLogin = sliding.userLogin;
            NSString *url = [notificationInfo valueForKey:@"content_type_data"];
            if ([url rangeOfString:@"http://"].location == NSNotFound) {
                url = [@"http://" stringByAppendingString:[notificationInfo valueForKey:@"content_type_data"]];
            }
            websiteViewController.webURL = url;
            [nav.visibleViewController.navigationController pushViewController:websiteViewController animated:NO];
        }
        if([[notificationInfo valueForKey:@"content_type"] isEqualToString:@"3"])
        {
            UINavigationController *nav = (UINavigationController*)self.window.rootViewController;
            if(![nav.visibleViewController isKindOfClass:[HomeScreenViewController class]])
            {
                for (id controller in [nav.visibleViewController.navigationController viewControllers])
                {
                    if ([controller isKindOfClass:[HomeScreenViewController class]])
                    {
                        [nav.visibleViewController.navigationController popToViewController:controller animated:NO];
                        break;
                    }
                }
                
            }
            SlidingViewController *viewController;
            SlidingViewController *sliding = (SlidingViewController*)nav.visibleViewController;
            if([[notificationInfo valueForKey:@"content_type_data"] isEqualToString:@"facility"])
            {
                viewController = [storyBoard instantiateViewControllerWithIdentifier:@"BookingViewController"];
            }
            else if([[notificationInfo valueForKey:@"content_type_data"] isEqualToString:@"fault_reporting"])
            {
                viewController = [storyBoard instantiateViewControllerWithIdentifier:@"FaultReportingViewController"];
            }
            else if([[notificationInfo valueForKey:@"content_type_data"] isEqualToString:@"emergency_no"])
            {
                viewController = [storyBoard instantiateViewControllerWithIdentifier:@"ImportantNumberViewController"];
            }
            else if([[notificationInfo valueForKey:@"content_type_data"] isEqualToString:@"notice"])
            {
                viewController = [storyBoard instantiateViewControllerWithIdentifier:@"NoticesViewController"];
            }
            else if([[notificationInfo valueForKey:@"content_type_data"] isEqualToString:@"management"])
            {
                viewController = [storyBoard instantiateViewControllerWithIdentifier:@"ManagementViewController"];
            }
            else if([[notificationInfo valueForKey:@"content_type_data"] isEqualToString:@"event"])
            {
                viewController = [storyBoard instantiateViewControllerWithIdentifier:@"EventsViewController"];
            }
            else if([[notificationInfo valueForKey:@"content_type_data"] isEqualToString:@"gallery"])
            {
                viewController = [storyBoard instantiateViewControllerWithIdentifier:@"GalleryViewController"];
            }
            else if([[notificationInfo valueForKey:@"content_type_data"] isEqualToString:@"website"])
            {
                viewController = [storyBoard instantiateViewControllerWithIdentifier:@"WebsiteViewController"];
            }
            else if([[notificationInfo valueForKey:@"content_type_data"] isEqualToString:@"guest_list_request"])
            {
                viewController = [storyBoard instantiateViewControllerWithIdentifier:@"GuestViewController"];
            }
            else if([[notificationInfo valueForKey:@"content_type_data"] isEqualToString:@"maintenance"])
            {
                viewController = [storyBoard instantiateViewControllerWithIdentifier:@"MaintenanceViewController"];
            }
            viewController.userLogin = sliding.userLogin;
            [nav.visibleViewController.navigationController pushViewController:viewController animated:NO];
        }
    }
}
- (void)application:(UIApplication*)application didFailToRegisterForRemoteNotificationsWithError:(NSError*)error
{
    NSLog(@"Failed to get token, error: %@", error);
}

- (void)application:(UIApplication *)application didRegisterUserNotificationSettings:(UIUserNotificationSettings *)notificationSettings
{
    //register to receive notifications
    [application registerForRemoteNotifications];
}

- (void)application:(UIApplication *)application handleActionWithIdentifier:(NSString *)identifier forRemoteNotification:(NSDictionary *)userInfo completionHandler:(void(^)())completionHandler
{
    //handle the actions
    if ([identifier isEqualToString:@"declineAction"])
    {
    }
    else if ([identifier isEqualToString:@"answerAction"])
    {
    }
}

@end
