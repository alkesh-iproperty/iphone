//
//  WebsiteViewController.m
//  ResidentApp
//
//  Created by TheAppGuruz on 10/07/15.
//  Copyright (c) 2015 TheAppGuruz-New-6. All rights reserved.
//

#import "WebsiteViewController.h"
#import "MBProgressHUD.h"
#import "ModelManager.h"
#import "Website.h"

@interface WebsiteViewController ()

@end

@implementation WebsiteViewController

#pragma mark - View LifeCycle Methods
- (void)viewDidLoad
{
    [super viewDidLoad];
    
    if(self.webURL)
    {
        [MBProgressHUD showHUDAddedTo:self.view animated:YES];
        [self.wbWebsite loadRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:self.webURL]]];
    }
    else
    {
        [MBProgressHUD showHUDAddedTo:self.view animated:YES];
        [self performSelector:@selector(getWebsiteData) withObject:nil afterDelay:0];
    }
}

-(void)getWebsiteData
{
    [[ModelManager getInstance] listWebsite:self.userLogin.condo_id WithCallback:^(NSError *err, id response) {
        if (response != nil) {
            NSMutableArray *marrWebsite = [[NSMutableArray alloc] initWithArray:[NSJSONSerialization JSONObjectWithData:response options:0 error:nil]];
            if ([marrWebsite count] > 0) {
                Website *website = [[Website alloc] init];
                [website parseResponse:[marrWebsite objectAtIndex:0]];
                [self.wbWebsite loadRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:website.website]]];
            } else {
                [MBProgressHUD hideHUDForView:self.view animated:YES];
            }
        } else {
            [MBProgressHUD hideHUDForView:self.view animated:YES];
        }
    }];
}

#pragma mark - Webview Delegate Methods
-(void)webViewDidFinishLoad:(UIWebView *)webView
{
    [MBProgressHUD hideHUDForView:self.view animated:YES];
}

-(void)webView:(UIWebView *)webView didFailLoadWithError:(NSError *)error
{
    [MBProgressHUD hideHUDForView:self.view animated:YES];
}

@end