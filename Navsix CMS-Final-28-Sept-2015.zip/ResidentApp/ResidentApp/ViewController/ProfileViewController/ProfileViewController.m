//
//  ProfileViewController.m
//  ResidentApp
//
//  Created by TheAppGuruz-New-6 on 07/07/15.
//  Copyright (c) 2015 TheAppGuruz-New-6. All rights reserved.
//

#import "ProfileViewController.h"
#import "MBProgressHUD.h"
#import "ModelManager.h"
#import "Booking.h"
#import "ProfileBookingCell.h"

@interface ProfileViewController ()

@end

@implementation ProfileViewController

#pragma mark - View LifeCycle Methods
- (void)viewDidLoad
{
    [super viewDidLoad];
    [self setUserDetailData];
}

-(void)setUserDetailData
{
    [self.txtTitle setBorderStyle:UITextBorderStyleRoundedRect];
    [self.txtFirstName setBorderStyle:UITextBorderStyleRoundedRect];
    [self.txtLastName setBorderStyle:UITextBorderStyleRoundedRect];
    [self.txtMobileNo setBorderStyle:UITextBorderStyleRoundedRect];
    [self.txtEmail setBorderStyle:UITextBorderStyleRoundedRect];
    [self.txtCurrentPassword setBorderStyle:UITextBorderStyleRoundedRect];
    [self.txtNewPassword setBorderStyle:UITextBorderStyleRoundedRect];
    [self.txtConfirmPassword setBorderStyle:UITextBorderStyleRoundedRect];
    
    self.lblName.text = self.userLogin.condo_name;
    self.lblResidentName.text = [NSString stringWithFormat:@"Name : %@ %@ %@",self.userLogin.title, self.userLogin.first_name, self.userLogin.last_name];
    self.lblBlockNo.text = [NSString stringWithFormat:@"Block No. : %@",self.userLogin.block_name];
    self.lblUnitNo.text = [NSString stringWithFormat:@"Unit No. : %@",self.userLogin.unit_name];
    self.lblEmail.text = [NSString stringWithFormat:@"Email : %@",self.userLogin.email];
    self.lblContactNo.text = [NSString stringWithFormat:@"Contact No. : %@", self.userLogin.mobile_no];
    [Util setViewDesign:self.lblBack BorderColor:[UIColor whiteColor] BorderWidth:1 CornerRadious:30];
}

#pragma mark - Action Methods
-(IBAction)btnDetailPress:(id)sender
{
    [self.btnDetail setBackgroundColor:[UIColor colorWithRed:24.0f/255.0f
                                                       green:118.0f/255.0f
                                                        blue:224.0f/255.0f
                                                       alpha:1.0f]];
    [self.btnChangePassword setBackgroundColor:[UIColor colorWithRed:11.0f/255.0f
                                                               green:86.0f/255.0f
                                                                blue:145.0f/255.0f
                                                               alpha:1.0f]];
    self.vwDetail.hidden = NO;
    self.vwChangePassword.hidden = YES;
}
- (IBAction)btnEditProfileClicked:(id)sender
{
    self.txtTitle.text = self.userLogin.title;
    self.txtFirstName.text = self.userLogin.first_name;
    self.txtLastName.text = self.userLogin.last_name;
    self.txtMobileNo.text = self.userLogin.mobile_no;
    self.txtEmail.text = self.userLogin.email;

    self.vwDetail.hidden = YES;
    self.vwChangePassword.hidden = YES;
    self.vwProfileEdit.hidden = NO;
    self.btnDetail.hidden = YES;
    self.btnChangePassword.hidden = YES;
    
}

-(IBAction)btnChangePasswordPress:(id)sender
{
    [self.btnChangePassword setBackgroundColor:[UIColor colorWithRed:24.0f/255.0f
                                                               green:118.0f/255.0f
                                                                blue:224.0f/255.0f
                                                               alpha:1.0f]];
    [self.btnDetail setBackgroundColor:[UIColor colorWithRed:11.0f/255.0f
                                                       green:86.0f/255.0f
                                                        blue:145.0f/255.0f
                                                       alpha:1.0f]];
    self.vwDetail.hidden = YES;
    self.vwChangePassword.hidden = NO;
}
- (IBAction)btnSaveProfileClicked:(id)sender
{
    [self updateUserProfileData];
}

- (IBAction)btnUpdateTapped:(id)sender
{
    if ([Util checkIsEmpty:self.txtCurrentPassword.text]) {
        [Util invokeAlertMethod:@"Warning" Body:@"Current password sholud not be Empty." Delegate:nil];
    } else if ([Util checkIsEmpty:self.txtNewPassword.text]) {
        [Util invokeAlertMethod:@"Warning" Body:@"New password sholud not be Empty." Delegate:nil];
    } else if ([Util checkIsEmpty:self.txtConfirmPassword.text]) {
        [Util invokeAlertMethod:@"Warning" Body:@"Confirm password sholud not be Empty." Delegate:nil];
    } else if (![self.txtNewPassword.text isEqualToString:self.txtConfirmPassword.text]) {
        [Util invokeAlertMethod:@"Warning" Body:@"New password & Confirm password must be Same." Delegate:nil];
    } else {
        [MBProgressHUD showHUDAddedTo:self.view animated:YES];
        [[ModelManager getInstance] changePassword:self.userLogin.res_id old_password:self.txtCurrentPassword.text new_password:self.txtNewPassword.text WithCallback:^(NSError *err, id response)
         {
             [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
             if (response != nil) {
                 if ([[[NSString alloc] initWithData:response encoding:NSUTF8StringEncoding] isEqualToString:@"-1"]) {
                     [Util invokeAlertMethod:@"Warning" Body:@"Your current password is Incorrect." Delegate:self];
                 } else if ([[[NSString alloc] initWithData:response encoding:NSUTF8StringEncoding] isEqualToString:@"0"]) {
                     [Util invokeAlertMethod:@"Warning" Body:@"Failed to change Password. Please try again." Delegate:nil];
                 } else if ([[[NSString alloc] initWithData:response encoding:NSUTF8StringEncoding] isEqualToString:@"1"]) {
                     [self.txtCurrentPassword setText:@""];
                     [self.txtNewPassword setText:@""];
                     [self.txtConfirmPassword setText:@""];
                     [Util invokeAlertMethod:@"Success" Body:@"Your Password changed successfully." Delegate:nil];
                 }
             }
         }];
    }
    
}

-(void)updateUserProfileData
{
    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    if ([Util checkIsEmpty:self.txtTitle.text]) {
        [Util invokeAlertMethod:@"Warning" Body:@"Title sholud not be Empty." Delegate:nil];
    } else if ([Util checkIsEmpty:self.txtFirstName.text]) {
        [Util invokeAlertMethod:@"Warning" Body:@"First name sholud not be Empty." Delegate:nil];
    } else if ([Util checkIsEmpty:self.txtLastName.text]) {
        [Util invokeAlertMethod:@"Warning" Body:@"Last name sholud not be Empty." Delegate:nil];
    } else if ([Util checkIsEmpty:self.txtMobileNo.text]) {
        [Util invokeAlertMethod:@"Warning" Body:@"Mobile number sholud not be Empty." Delegate:nil];
    } else if ([Util checkIsEmpty:self.txtEmail.text]) {
        [Util invokeAlertMethod:@"Warning" Body:@"Email sholud not be Empty." Delegate:nil];
    } else {
        NSNumber *titleNo;
        
        if ([self.txtTitle.text isEqualToString:@"Mr"]) {
            titleNo = [NSNumber numberWithInt:1];
        } else if ([self.txtTitle.text isEqualToString:@"Mrs"]) {
            titleNo = [NSNumber numberWithInt:2];
        } else if ([self.txtTitle.text isEqualToString:@"Ms"]) {
            titleNo = [NSNumber numberWithInt:3];
        } else if ([self.txtTitle.text isEqualToString:@"Miss"]) {
            titleNo = [NSNumber numberWithInt:4];
        } else {
            titleNo = [NSNumber numberWithInt:0];
        }
        
        [[ModelManager getInstance] updateProfile:self.userLogin.res_id titleNo:titleNo first_name:self.txtFirstName.text last_name:self.txtLastName.text mobile_no:self.txtMobileNo.text email:self.txtEmail.text WithCallback:^(NSError *err, id response) {
            
            [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
            if (response != nil) {
                if ([[[NSString alloc] initWithData:response encoding:NSUTF8StringEncoding] isEqualToString:@"1"]) {
                    [Util invokeAlertMethod:@"Success" Body:@"Your Profile updated successfully." Delegate:self];
                } else if ([[[NSString alloc] initWithData:response encoding:NSUTF8StringEncoding] isEqualToString:@"0"]) {
                    [Util invokeAlertMethod:@"Warning" Body:@"Failed to update Profile. Please try again." Delegate:nil];
                } else if ([[[NSString alloc] initWithData:response encoding:NSUTF8StringEncoding] isEqualToString:@"2"]) {
                    [Util invokeAlertMethod:@"Warning" Body:@"Please enter valid email address" Delegate:nil];
                } else if ([[[NSString alloc] initWithData:response encoding:NSUTF8StringEncoding] isEqualToString:@"3"]) {
                    [Util invokeAlertMethod:@"Warning" Body:@"Email already exist" Delegate:nil];
                }
            }
        }];
    }
}

#pragma mark - UIAlertView Delegate methods

-(void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    self.userLogin.title = self.txtTitle.text;
    self.userLogin.first_name = self.txtFirstName.text;
    self.userLogin.last_name = self.txtLastName.text;
    self.userLogin.mobile_no = self.txtMobileNo.text;
    self.userLogin.email = self.txtEmail.text;
    
    [self saveUserLoginObject];
    
    self.lblName.text = self.userLogin.condo_name;
    self.lblResidentName.text = [NSString stringWithFormat:@"Name : %@ %@ %@",self.userLogin.title, self.userLogin.first_name, self.userLogin.last_name];
    self.lblBlockNo.text = [NSString stringWithFormat:@"Block No. : %@",self.userLogin.block_name];
    self.lblUnitNo.text = [NSString stringWithFormat:@"Unit No. : %@",self.userLogin.unit_name];
    self.lblEmail.text = [NSString stringWithFormat:@"Email : %@",self.userLogin.email];
    self.lblContactNo.text = [NSString stringWithFormat:@"Contact No. : %@", self.userLogin.mobile_no];
    
    self.vwDetail.hidden = NO;
    self.vwChangePassword.hidden = YES;
    self.vwProfileEdit.hidden = YES;
    self.btnDetail.hidden = NO;
    self.btnChangePassword.hidden = NO;
}

#pragma mark - UITextField Delegate methods

-(BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    return YES;
}

- (void)textFieldDidBeginEditing:(UITextField *)textField
{
    [UIView animateWithDuration:0.5 animations:^{
        if(IS_IPHONE_4_OR_LESS || IS_IPHONE_5)
            self.scrollView.contentOffset = CGPointMake(0,textField.frame.origin.y);
    }];
}

-(void)textFieldDidEndEditing:(UITextField *)textField
{
    [UIView animateWithDuration:0.5 animations:^{
        self.scrollView.contentOffset = CGPointMake(0,0);
    }];
}


- (void)saveUserLoginObject
{
    NSData *encodedObject = [NSKeyedArchiver archivedDataWithRootObject:self.userLogin];
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    [defaults setObject:encodedObject forKey:@"UserLoginData"];
    [defaults synchronize];
}

- (IBAction)btnTitleTapped:(id)sender
{
    UIActionSheet *actionSheet = [[UIActionSheet alloc] initWithTitle:@"Choose one" delegate:self cancelButtonTitle:@"Cancel" destructiveButtonTitle:nil otherButtonTitles:@"Mr", @"Mrs", @"Ms", @"Miss", nil];
    [actionSheet showInView:self.view];
}

- (void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if (buttonIndex == 0) {
        [self.txtTitle setText:@"Mr"];
    } else if (buttonIndex == 1) {
        [self.txtTitle setText:@"Mrs"];
    } else if (buttonIndex == 2) {
        [self.txtTitle setText:@"Ms"];
    } else if (buttonIndex == 3) {
        [self.txtTitle setText:@"Miss"];
    }
}




@end