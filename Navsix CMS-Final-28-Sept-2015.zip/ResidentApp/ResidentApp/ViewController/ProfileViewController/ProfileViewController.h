//
//  ProfileViewController.h
//  ResidentApp
//
//  Created by TheAppGuruz-New-6 on 07/07/15.
//  Copyright (c) 2015 TheAppGuruz-New-6. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SlidingViewController.h"
#import "AddBookingViewController.h"

@interface ProfileViewController : SlidingViewController<UIAlertViewDelegate,UIAlertViewDelegate,UITextFieldDelegate,UIActionSheetDelegate,UITextFieldDelegate>
{
    NSMutableArray *marrBooking;
    UIButton *btnCancel;
    UIButton *btnChange;
}

@property (nonatomic, strong) IBOutlet UIButton *btnDetail;
@property (nonatomic, strong) IBOutlet UIButton *btnChangePassword;
@property (nonatomic, strong) IBOutlet UIView *vwDetail;
@property (nonatomic, strong) IBOutlet UILabel *lblName;
@property (nonatomic, strong) IBOutlet UILabel *lblBack;
@property (nonatomic, strong) IBOutlet UIView *vwChangePassword;
@property (nonatomic, strong) IBOutlet UILabel *lblBlockNo;
@property (nonatomic, strong) IBOutlet UILabel *lblUnitNo;
@property (nonatomic, strong) IBOutlet UILabel *lblResidentName;
@property (weak, nonatomic) IBOutlet UIView *vwProfileEdit;
@property (nonatomic, strong) IBOutlet UILabel *lblContactNo;
@property (nonatomic, strong) IBOutlet UILabel *lblEmail;
@property (nonatomic, strong) IBOutlet UITextField *txtTitle;
@property (nonatomic, strong) IBOutlet UITextField *txtFirstName;
@property (nonatomic, strong) IBOutlet UITextField *txtLastName;
@property (nonatomic, strong) IBOutlet UITextField *txtMobileNo;
@property (nonatomic, strong) IBOutlet UITextField *txtEmail;
@property (nonatomic, strong) IBOutlet UITextField *txtCurrentPassword;
@property (nonatomic, strong) IBOutlet UITextField *txtNewPassword;
@property (nonatomic, strong) IBOutlet UITextField *txtConfirmPassword;
@property (weak, nonatomic) IBOutlet UIScrollView *scrollView;
@end