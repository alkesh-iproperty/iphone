//
//  ManagementViewController.m
//  ResidentApp
//
//  Created by TheAppGuruz-New-6 on 07/07/15.
//  Copyright (c) 2015 TheAppGuruz-New-6. All rights reserved.
//

#import "ManagementViewController.h"
#import "MBProgressHUD.h"
#import "ModelManager.h"
#import "Management.h"
#import "UIImageView+WebCache.h"
#import "ManagementCell.h"
#import "ManagementDetailViewController.h"

#define Management_Base_Url @"http://www.condomanagementsystem.com/upload/management/"

@interface ManagementViewController ()

@end

@implementation ManagementViewController

#pragma mark - View LifeCycle Methods
- (void)viewDidLoad
{
    [super viewDidLoad];
    
    intPageNumber = 1;
    marrManagement = [[NSMutableArray alloc] init];
    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    [self performSelector:@selector(getManagementData) withObject:nil afterDelay:0];
}

-(void)getManagementData
{
    [[ModelManager getInstance] listManagement:self.userLogin.condo_id pageNo:[NSNumber numberWithInt:intPageNumber] WithCallback:^(NSError *err, id response) {
        if (response != nil) {
            if ([Util checkIsEmpty:[NSJSONSerialization JSONObjectWithData:response options:0 error:nil]]) {
                intPageNumber = -1;
                return;
            }
            marrManagementTemp = [[NSMutableArray alloc] initWithArray:[NSJSONSerialization JSONObjectWithData:response options:0 error:nil]];
            
            for (int i = 0; i < [marrManagementTemp count]; i++) {
                Management *management = [[Management alloc] init];
                [management parseResponse:[marrManagementTemp objectAtIndex:i]];
                [marrManagementTemp replaceObjectAtIndex:i withObject:management];
            }
            for(int i = 0 ;i < marrManagementTemp.count ;i++)
            {
                [marrManagement addObject:[marrManagementTemp objectAtIndex:i]] ;
            }
            [self.tbManagement reloadData];
        }
        [MBProgressHUD hideHUDForView:self.view animated:YES];
    }];
}

#pragma mark - UITableView Delegate Methods
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if (tableView == self.tbManagement) {
        return [marrManagement count];
    } else {
        return [super tableView:tableView numberOfRowsInSection:section];
    }
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (tableView == self.tbManagement) {
        ManagementCell *cell = [tableView dequeueReusableCellWithIdentifier:@"ManagementCell"];
        
        Management *management = [marrManagement objectAtIndex:indexPath.row];
        
        cell.lblDesignation.text = management.designation;
        cell.lblName.text = [NSString stringWithFormat:@"%@ : %@", management.name, management.mobile_number];
        
        [cell.ivIcon sd_setImageWithURL:[NSURL URLWithString:[[NSString stringWithFormat:@"%@%@", Management_Base_Url, management.photo] stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]] placeholderImage:[UIImage imageNamed:@""]];
        
        return cell;
    } else {
        return [super tableView:tableView cellForRowAtIndexPath:indexPath];
    }
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (tableView == self.tbManagement)
    {
        UIStoryboard *storyBoard = [UIStoryboard storyboardWithName:@"Main" bundle:[NSBundle mainBundle]];
        ManagementDetailViewController *managementDescriptionViewController = [storyBoard instantiateViewControllerWithIdentifier:@"ManagementDetailViewController"];
        managementDescriptionViewController.userLogin = self.userLogin;
        managementDescriptionViewController.management = [marrManagement objectAtIndex:indexPath.row];
        [self.navigationController pushViewController:managementDescriptionViewController animated:NO];

    } else {
        [super tableView:tableView didSelectRowAtIndexPath:indexPath];
    }
}

- (void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath
{
    if(tableView == self.tbManagement)
    {
        if (indexPath.row == marrManagement.count-1 && intPageNumber > 0) {
            intPageNumber++;
            [self performSelector:@selector(getManagementData) withObject:nil afterDelay:0];
        }
    }
}

@end