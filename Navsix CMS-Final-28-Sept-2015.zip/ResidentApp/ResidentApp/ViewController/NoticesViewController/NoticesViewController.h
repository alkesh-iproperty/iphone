//
//  NoticesViewController.h
//  ResidentApp
//
//  Created by TheAppGuruz-New-6 on 07/07/15.
//  Copyright (c) 2015 TheAppGuruz-New-6. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SlidingViewController.h"

@interface NoticesViewController : SlidingViewController
{
    NSMutableArray *marrNotices,*marrNoticesTemp;
    int selectedRow;
    int intPageNumber;
}

@property (nonatomic, strong) IBOutlet UITableView *tbNotices;

@end
