//
//  NoticesViewController.m
//  ResidentApp
//
//  Created by TheAppGuruz-New-6 on 07/07/15.
//  Copyright (c) 2015 TheAppGuruz-New-6. All rights reserved.
//

#import "NoticesViewController.h"
#import "MBProgressHUD.h"
#import "ModelManager.h"
#import "Notice.h"
#import "UIImageView+WebCache.h"
#import "NoticeCell.h"
#import "NoticesDetailViewController.h"

#define Notice_Base_Url @"http://www.condomanagementsystem.com/upload/notice/"

@interface NoticesViewController ()

@end

@implementation NoticesViewController


#pragma mark - View LifeCycle Methods
- (void)viewDidLoad
{
    [super viewDidLoad];
}

-(void)viewWillAppear:(BOOL)animated
{
    intPageNumber = 1;
    marrNotices = [[NSMutableArray alloc] init];
    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    [self performSelector:@selector(getNoticesData) withObject:nil afterDelay:0];
}

-(void)getNoticesData
{
    [[ModelManager getInstance] listNotices:self.userLogin.condo_id res_id:self.userLogin.res_id pageNo:[NSNumber numberWithInt:intPageNumber] WithCallback:^(NSError *err, id response) {
        if (response != nil) {
            
            if ([Util checkIsEmpty:[NSJSONSerialization JSONObjectWithData:response options:0 error:nil]]) {
                intPageNumber = -1;
                return;
            }
            marrNoticesTemp = [[NSMutableArray alloc] initWithArray:[NSJSONSerialization JSONObjectWithData:response options:0 error:nil]];
            
            
            for (int i = 0; i < [marrNoticesTemp count]; i++) {
                Notice *notice = [[Notice alloc] init];
                [notice parseResponse:[marrNoticesTemp objectAtIndex:i]];
                [marrNoticesTemp replaceObjectAtIndex:i withObject:notice];
            }
            for(int i = 0 ;i < marrNoticesTemp.count ;i++)
            {
                [marrNotices addObject:[marrNoticesTemp objectAtIndex:i]] ;
            }
            [self.tbNotices reloadData];
        }
        [MBProgressHUD hideHUDForView:self.view animated:YES];
    }];
}

-(void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    Notice *notice = [marrNotices objectAtIndex:selectedRow];
    NoticesDetailViewController *noticesDetailViewController = [segue destinationViewController];
    noticesDetailViewController.strTitle = notice.name;
    noticesDetailViewController.filePath = [[NSString stringWithFormat:@"%@%@", Notice_Base_Url, notice.file_name] stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    noticesDetailViewController.userLogin = self.userLogin;
    
}

#pragma mark - UITableView Delegate Methods
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if (tableView == self.tbNotices) {
        return [marrNotices count];
    } else {
        return [super tableView:tableView numberOfRowsInSection:section];
    }
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (tableView == self.tbNotices) {
        NoticeCell *cell = [tableView dequeueReusableCellWithIdentifier:@"NoticeCell"];
        
        Notice *notice = [marrNotices objectAtIndex:indexPath.row];
        
        cell.lblName.text = notice.name;
        
        if ([[notice.file_name pathExtension] isEqualToString:@"txt"]) {
            [cell.ivIcon setImage:[UIImage imageNamed:@"TxtFileIcon.png"]];
        } else if ([[notice.file_name pathExtension] isEqualToString:@"csv"]) {
            [cell.ivIcon setImage:[UIImage imageNamed:@"CsvFileIcon.png"]];
        } else if ([[notice.file_name pathExtension] isEqualToString:@"pdf"]) {
            [cell.ivIcon setImage:[UIImage imageNamed:@"PdfFileIcon.png"]];
        }else if ([[notice.file_name pathExtension] isEqualToString:@"xlsx"] || [[notice.file_name pathExtension] isEqualToString:@"xls"]) {
            [cell.ivIcon setImage:[UIImage imageNamed:@"XSLX.png"]];
        } else {
            [cell.ivIcon sd_setImageWithURL:[NSURL URLWithString:[[NSString stringWithFormat:@"%@%@", Notice_Base_Url, notice.file_name] stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]] placeholderImage:[UIImage imageNamed:@""]];
        }
        if([notice.read isEqualToString:@"1"])
            [cell setBackgroundColor:[UIColor colorWithRed:11.0f/255.0f
                                                     green:86.0f/255.0f
                                                      blue:145.0f/255.0f
                                                     alpha:0.3f]];
        else
            [cell setBackgroundColor:[UIColor clearColor]];
        
        return cell;
    } else {
        return [super tableView:tableView cellForRowAtIndexPath:indexPath];
    }
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (tableView == self.tbNotices) {
        Notice *notice = [marrNotices objectAtIndex:indexPath.row];
        selectedRow = (int)indexPath.row;
        [tableView deselectRowAtIndexPath:indexPath animated:YES];
        if([notice.read isEqualToString:@"1"])
        {
            [MBProgressHUD showHUDAddedTo:self.view animated:YES];
            [[ModelManager getInstance] readUpdateNotice:notice.id WithCallback:^(NSError *err, id response) {
                if(response != nil)
                {
                    response = [[NSString alloc] initWithData:response encoding:NSUTF8StringEncoding];
                    if([response isEqualToString:@"1"])
                    {
                        int count = [[[NSUserDefaults standardUserDefaults] valueForKey:@"NoticeCount"] intValue] - 1;
                        [[NSUserDefaults standardUserDefaults] setValue:[NSString stringWithFormat:@"%d",count] forKey:@"NoticeCount"];
                        [self.tbList reloadData];
                        [self performSegueWithIdentifier:@"OpenNoticesDetailView" sender:nil];
                    }
                    else
                        [Util invokeAlertMethod:@"Warning" Body:@"There is a problem while loading. Please try again." Delegate:nil];
                }
                else
                    [Util invokeAlertMethod:@"Warning" Body:@"There is a problem while loading. Please try again." Delegate:nil];
                [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
            }];

        }
        else
        {
            [self performSegueWithIdentifier:@"OpenNoticesDetailView" sender:nil];
        }
    } else {
        [super tableView:tableView didSelectRowAtIndexPath:indexPath];
    }
}

- (void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath
{
    if(tableView == self.tbNotices)
    {
    if (indexPath.row == marrNotices.count-1 && intPageNumber > 0) {
        intPageNumber++;
        [self performSelector:@selector(getNoticesData) withObject:nil afterDelay:0];
    }
    }
}

@end