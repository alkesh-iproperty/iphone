//
//  LoginViewController.m
//  ResidentApp
//
//  Created by TheAppGuruz-New-6 on 07/07/15.
//  Copyright (c) 2015 TheAppGuruz-New-6. All rights reserved.
//

#import "LoginViewController.h"
#import "Util.h"
#import "MBProgressHUD.h"
#import "ModelManager.h"
#import "HomeScreenViewController.h"


#define Slider_Image_Base_Url @"http://www.condomanagementsystem.com/upload/sliderhome/"

@interface LoginViewController ()

@end

@implementation LoginViewController

#pragma mark - View LifeCycle Methods
- (void)viewDidLoad
{
    [super viewDidLoad];
    
    [self loadUserLoginObject];
    
    if (userLogin)
    {
        UIStoryboard *storyBoard = [UIStoryboard storyboardWithName:@"Main" bundle:[NSBundle mainBundle]];
        HomeScreenViewController *homeScreenViewController = [storyBoard instantiateViewControllerWithIdentifier:@"HomeScreenViewController"];
        homeScreenViewController.userLogin = userLogin;
        [self.navigationController pushViewController:homeScreenViewController animated:NO];
    }

//    self.txtUsername.text = @"res466";
//    self.txtPassword.text = @"swati";
    
    [self designAllView];
}

-(void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    HomeScreenViewController *homeScreenViewController = (HomeScreenViewController *)[segue destinationViewController];
    homeScreenViewController.userLogin = userLogin;
}

#pragma mark - View Design Methods

-(void)designAllView
{
    [Util setViewDesign:self.btnLogin BorderColor:self.btnLogin.backgroundColor BorderWidth:1 CornerRadious:10];
    
    UIVisualEffect *blurEffect;
    blurEffect = [UIBlurEffect effectWithStyle:UIBlurEffectStyleLight];
    
    UIVisualEffectView *visualEffectView;
    visualEffectView = [[UIVisualEffectView alloc] initWithEffect:blurEffect];
    visualEffectView.frame = CGRectMake(0, 0, [UIScreen mainScreen].bounds.size.width+10, [UIScreen mainScreen].bounds.size.height);
    
    [self.vwMain addSubview:visualEffectView];
    [self.vwMain sendSubviewToBack:visualEffectView];
}

- (NSUInteger)supportedInterfaceOrientations
{
    return UIInterfaceOrientationMaskPortrait;
}

#pragma mark - Action Methods

-(IBAction)btnLoginPress:(id)sender
{
    if ([Util checkIsEmpty:self.txtUsername.text]) {
        [Util invokeAlertMethod:nil Body:@"Please enter Username" Delegate:nil];
    } else if ([Util checkIsEmpty:self.txtPassword.text]) {
        [Util invokeAlertMethod:nil Body:@"Please enter Password" Delegate:nil];
    } else {
        [MBProgressHUD showHUDAddedTo:self.view animated:YES];
        [[ModelManager getInstance] getUserLogin:self.txtUsername.text Password:self.txtPassword.text WithCallback:^(NSError *err, id response) {
            if (response != nil) {
                NSLog(@"response loginn %@ %@",response,[NSJSONSerialization JSONObjectWithData:response options:0 error:nil]);
                response = [NSJSONSerialization JSONObjectWithData:response options:0 error:nil];
                if (response) {
                    userLogin = [[UserLogin alloc] init];
                    [userLogin parseResponse:response];
                    
                    if ([[NSFileManager defaultManager] fileExistsAtPath:[FILEPATH_Documents stringByAppendingPathComponent:@"SliderImages"]]) {
                        [[NSFileManager defaultManager] removeItemAtPath:[FILEPATH_Documents stringByAppendingPathComponent:@"SliderImages"] error:nil];
                    }
                    [[NSFileManager defaultManager] createDirectoryAtPath:[FILEPATH_Documents stringByAppendingPathComponent:@"SliderImages"] withIntermediateDirectories:NO attributes:nil error:nil];
                    NSLog(@"file pathhh %@",FILEPATH_Documents);
                    for (int i = 0; i < [userLogin.slider_images count]; i++) {
                        NSData *imageData = [NSData dataWithContentsOfURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@%@", Slider_Image_Base_Url, [userLogin.slider_images objectAtIndex:i]]]];
                        [imageData writeToFile:[[FILEPATH_Documents stringByAppendingPathComponent:@"SliderImages"] stringByAppendingPathComponent:[userLogin.slider_images objectAtIndex:i]] atomically:YES];
                    }
                    
                    [[ModelManager getInstance] registerDeviceId:userLogin.condo_id res_id:userLogin.res_id device_id:[[NSUserDefaults standardUserDefaults] valueForKey:@"deviceToken"] WithCallback:^(NSError *err, id response) {
                        NSLog(@"response %@",[[NSString alloc] initWithData:response encoding:NSUTF8StringEncoding]);
                        if (err != nil) {
                            [Util invokeAlertMethod:nil Body:@"Error while registering your device token." Delegate:nil];
                        }
                    }];
                    
                    if ([[response valueForKey:@"otp"] isEqualToString:@"1"])
                    {
                        [self changeOTP];
                    }
                    else
                    {
                        [self saveUserLoginObject];
                        [self performSegueWithIdentifier:@"OpenHomeView" sender:nil];
                    }
                } else {
                    [Util invokeAlertMethod:nil Body:@"Incorrect Username or Password." Delegate:nil];
                }
            }
            [MBProgressHUD hideHUDForView:self.view animated:YES];
        }];
    }
}

#pragma mark - UITextField Delegate Methods
- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    return YES;
}

- (void)textFieldDidBeginEditing:(UITextField *)textField
{
    [UIView animateWithDuration:0.5 animations:^{
        if(IS_IPHONE_4_OR_LESS)
            self.scrollView.contentOffset = CGPointMake(0,textField.frame.origin.y + 150);
        else
            self.scrollView.contentOffset = CGPointMake(0,textField.frame.origin.y + 80);
    }];
}

-(void)textFieldDidEndEditing:(UITextField *)textField
{
    [UIView animateWithDuration:0.5 animations:^{
       self.scrollView.contentOffset = CGPointMake(0,0);
        }];
}

-(void)changeOTP
{
    UIAlertView *alertOTP =[[UIAlertView alloc]initWithTitle:@"Please change your OTP" message:nil delegate:self cancelButtonTitle:nil otherButtonTitles:@"Change", nil];
    
    UIView *vwAlert = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 250, 100)];
    UILabel *lblPassword=[[UILabel alloc]initWithFrame:CGRectMake(10,10, 100, 30)];
    [lblPassword setTextColor:[UIColor colorWithRed:11.0f/255.0f
                                             green:86.0f/255.0f
                                              blue:145.0f/255.0f
                                              alpha:1.0f]];
    [lblPassword setFont:[UIFont boldSystemFontOfSize:14]];
    lblPassword.text=@"Password :";
    [vwAlert addSubview:lblPassword];
    
    UILabel *lblConfirmPassword=[[UILabel alloc]initWithFrame:CGRectMake(10,50, 100, 35)];
    [lblConfirmPassword setTextColor:[UIColor colorWithRed:11.0f/255.0f
                                              green:86.0f/255.0f
                                               blue:145.0f/255.0f
                                              alpha:1.0f]];
    [lblConfirmPassword setFont:[UIFont boldSystemFontOfSize:14]];
    [lblConfirmPassword setNumberOfLines:2];
    lblConfirmPassword.text=@"Confirm Password:";
    [vwAlert addSubview:lblConfirmPassword];
    
    txtOTPPassword=[[UITextField alloc]initWithFrame:CGRectMake(100, 10, 160, 30)];
    [txtOTPPassword setSecureTextEntry:YES];
    [txtOTPPassword setBorderStyle:UITextBorderStyleRoundedRect];
    [vwAlert addSubview:txtOTPPassword];
    
    txtOTPConfirmPassword=[[UITextField alloc]initWithFrame:CGRectMake(100, 55, 160, 30)];
    [txtOTPConfirmPassword setSecureTextEntry:YES];
    [txtOTPConfirmPassword setBorderStyle:UITextBorderStyleRoundedRect];
    [vwAlert addSubview:txtOTPConfirmPassword];
    
    [alertOTP setValue:vwAlert forKey:@"accessoryView"];
    alertOTP.tag = 20;
    [alertOTP show];
}
#pragma mark - UIAlertView delegate methods

-(void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if(alertView.tag == 20)
    {
        if([txtOTPPassword.text isEqualToString:@""])
        {
            [Util invokeAlertMethod:@"Warning" Body:@"Please enter your new passwod." Delegate:self];
            [self changeOTP];
        }
        else if(![txtOTPPassword.text isEqualToString:txtOTPConfirmPassword.text])
        {
            [Util invokeAlertMethod:@"Warning" Body:@"Your Password and Confirm Passowrd are not same. Plase try again." Delegate:self];
            [self changeOTP];
        }
        else
        {
            [[ModelManager getInstance] changeOTP:userLogin.res_id Password:txtOTPPassword.text WithCallback:^(NSError *err, id response) {
                if(response != nil)
                {
                    response = [[NSString alloc] initWithData:response encoding:NSUTF8StringEncoding];
                    if([response isEqualToString:@"1"])
                    {
                        [self saveUserLoginObject];
                        [Util invokeAlertMethod:@"Success" Body:@"Your OTP is changed successfully." Delegate:nil];
                        [self performSegueWithIdentifier:@"OpenHomeView" sender:nil];
                    }
                    else
                    {
                        [Util invokeAlertMethod:@"Failure" Body:@"There is a problem while changing your OTP." Delegate:nil];
                        [self changeOTP];
                    }
                }
                else
                {
                    [Util invokeAlertMethod:nil Body:@"Error while changing your OTP." Delegate:nil];
                    [self changeOTP];
                }

            }];
        }
    }
}


- (void)saveUserLoginObject
{
    NSData *encodedObject = [NSKeyedArchiver archivedDataWithRootObject:userLogin];
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    [defaults setObject:encodedObject forKey:@"UserLoginData"];
    [defaults synchronize];
}

- (void)loadUserLoginObject
{
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    NSData *encodedObject = [defaults objectForKey:@"UserLoginData"];
    userLogin = [NSKeyedUnarchiver unarchiveObjectWithData:encodedObject];
}
@end