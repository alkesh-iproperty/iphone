//
//  ImportantNumberViewController.h
//  ResidentApp
//
//  Created by TheAppGuruz-New-6 on 07/07/15.
//  Copyright (c) 2015 TheAppGuruz-New-6. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SlidingViewController.h"

@interface ImportantNumberViewController : SlidingViewController
{
    NSMutableArray *marrEmergencyNo;
}

@property (nonatomic, strong) IBOutlet UIView *vwBack;
@property (nonatomic, strong) IBOutlet UITableView *tbEmergencyNo;

@end
