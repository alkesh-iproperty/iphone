//
//  ImportantNumberViewController.m
//  ResidentApp
//
//  Created by TheAppGuruz-New-6 on 07/07/15.
//  Copyright (c) 2015 TheAppGuruz-New-6. All rights reserved.
//

#import "ImportantNumberViewController.h"
#import "MBProgressHUD.h"
#import "ModelManager.h"
#import "EmergencyNo.h"
#import "ImportantNoCell.h"

@interface ImportantNumberViewController ()

@end

@implementation ImportantNumberViewController

#pragma mark - View LifeCycle Methods
- (void)viewDidLoad
{
    [super viewDidLoad];
    
    [Util setViewDesign:self.vwBack BorderColor:[UIColor whiteColor] BorderWidth:1 CornerRadious:20];
    
    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    [self performSelector:@selector(getImportantNoData) withObject:nil afterDelay:0];
    
    [self.vwBack.superview sendSubviewToBack:self.vwBack];
}

-(void)getImportantNoData
{
    [[ModelManager getInstance] listEmergencyNo:self.userLogin.condo_id WithCallback:^(NSError *err, id response) {
        if (response != nil) {
            marrEmergencyNo = [[NSMutableArray alloc] initWithArray:[NSJSONSerialization JSONObjectWithData:response options:0 error:nil]];
            
            for (int i = 0; i < [marrEmergencyNo count]; i++) {
                EmergencyNo *emergencyNo = [[EmergencyNo alloc] init];
                [emergencyNo parseResponse:[marrEmergencyNo objectAtIndex:i]];
                [marrEmergencyNo replaceObjectAtIndex:i withObject:emergencyNo];
            }
            
            [self.tbEmergencyNo reloadData];
        }
        [MBProgressHUD hideHUDForView:self.view animated:YES];
    }];
}

-(void)btnCallPress:(id)sender
{
    UIButton *btnCall = (UIButton *)sender;
    EmergencyNo *emergencyNo = [marrEmergencyNo objectAtIndex:btnCall.tag];
    
    if([[UIApplication sharedApplication] canOpenURL:[NSURL URLWithString:@"tel://"]])
    {
        [[UIApplication sharedApplication] openURL:[NSURL URLWithString:[NSString stringWithFormat:@"tel://%@", emergencyNo.number]]];
    }
    else
    {
        [Util invokeAlertMethod:@"Warning" Body:@"Phone call is not supported in device." Delegate:self];
    }
}

#pragma mark - UITableView Delegate Methods
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if (tableView == self.tbEmergencyNo) {
        return [marrEmergencyNo count];
    } else {
        return [super tableView:tableView numberOfRowsInSection:section];
    }
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (tableView == self.tbEmergencyNo) {
        ImportantNoCell *cell = [tableView dequeueReusableCellWithIdentifier:@"ImportantNoCell"];
        
        EmergencyNo *emergencyNo = [marrEmergencyNo objectAtIndex:indexPath.row];
        
        cell.lblTitle.text = emergencyNo.name;
        
        [Util setViewDesign:cell.btnCall BorderColor:[cell.btnCall backgroundColor] BorderWidth:1 CornerRadious:15];
        cell.btnCall.tag = indexPath.row;
        [cell.btnCall addTarget:self action:@selector(btnCallPress:) forControlEvents:UIControlEventTouchUpInside];
        
        return cell;
    } else {
        return [super tableView:tableView cellForRowAtIndexPath:indexPath];
    }
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (tableView == self.tbEmergencyNo) {
        
    } else {
        [super tableView:tableView didSelectRowAtIndexPath:indexPath];
    }
}

@end