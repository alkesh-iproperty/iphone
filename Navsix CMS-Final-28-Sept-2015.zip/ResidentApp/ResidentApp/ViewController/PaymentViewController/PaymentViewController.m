//
//  PaymentViewController.m
//  ResidentApp
//
//  Created by TheAppGuruz-New-6 on 18/08/15.
//  Copyright (c) 2015 TheAppGuruz-New-6. All rights reserved.
//

#import "PaymentViewController.h"

@interface PaymentViewController ()

@end

@implementation PaymentViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    marrPayment = [[NSMutableArray alloc] init];
    
    if([[NSUserDefaults standardUserDefaults] valueForKey:@"Maintenance"])
        [marrPayment addObject:[NSDictionary dictionaryWithObjectsAndKeys:@"Maintenance", @"TitleName", @"MaintenanceViewController", @"ViewControllerName",@"0",@"Updates" , nil]];
    if([[NSUserDefaults standardUserDefaults] valueForKey:@"Quit Rent"])
        [marrPayment addObject:[NSDictionary dictionaryWithObjectsAndKeys:@"Quit Rent", @"TitleName", @"QuitRentViewController", @"ViewControllerName",@"0",@"Updates" , nil]];
    if([[NSUserDefaults standardUserDefaults] valueForKey:@"Fire Insurance"])
        [marrPayment addObject:[NSDictionary dictionaryWithObjectsAndKeys:@"Fire Insurance", @"TitleName", @"FireInsuranceViewController", @"ViewControllerName",@"0",@"Updates" , nil]];
    if([[NSUserDefaults standardUserDefaults] valueForKey:@"Sinking Fund"])
        [marrPayment addObject:[NSDictionary dictionaryWithObjectsAndKeys:@"Sinking Fund", @"TitleName", @"SinkingFundViewController", @"ViewControllerName",@"0",@"Updates" , nil]];

    [self.tbPayment reloadData];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - UITableView Delegate methods

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if(tableView == self.tbPayment)
    {
        return marrPayment.count;
    }
    else
    {
        return [super tableView:tableView numberOfRowsInSection:section];
    }
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if(tableView == self.tbPayment)
    {
        UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
        [cell.textLabel setFont:[UIFont boldSystemFontOfSize:18]];
        [cell.textLabel setTextColor:[UIColor darkGrayColor]];
        cell.textLabel.text = [[marrPayment objectAtIndex:indexPath.row] valueForKey:@"TitleName"];
        return cell;
    }
    else
    {
        return [super tableView:tableView cellForRowAtIndexPath:indexPath];
    }
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if(tableView == self.tbPayment)
    {
        UIStoryboard *storyBoard = [UIStoryboard storyboardWithName:@"Main" bundle:[NSBundle mainBundle]];
        SlidingViewController *viewController = [storyBoard instantiateViewControllerWithIdentifier:[[marrPayment objectAtIndex:indexPath.row] valueForKey:@"ViewControllerName"]];
        viewController.userLogin = self.userLogin;
        [self.navigationController pushViewController:viewController animated:YES];
        [tableView deselectRowAtIndexPath:indexPath animated:YES];
    }
    else
    {
        return [super tableView:tableView didSelectRowAtIndexPath:indexPath];
    }
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
