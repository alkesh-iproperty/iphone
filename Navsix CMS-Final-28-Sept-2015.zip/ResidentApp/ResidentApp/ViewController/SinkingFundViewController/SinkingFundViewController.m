//
//  SinkingFundViewController.m
//  ResidentApp
//
//  Created by TheAppGuruz-New-6 on 18/08/15.
//  Copyright (c) 2015 TheAppGuruz-New-6. All rights reserved.
//

#import "SinkingFundViewController.h"
#import "MaintenanceCell.h"
#import "ReceiptViewController.h"

// for Live trasaction use PayPalEnvironmentProduction
//#define kPayPalEnvironment PayPalEnvironmentSandbox
#define kPayPalEnvironment PayPalEnvironmentProduction
@interface SinkingFundViewController ()

@end

@implementation SinkingFundViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    [self getFund];

    // Do any additional setup after loading the view.
}

-(void)getFund
{
    [[ModelManager getInstance] sinkingFundAmount:self.userLogin.res_id condoID:self.userLogin.condo_id WithCallback:^(NSError *err, id response) {
        if (response != nil) {
            response = [NSJSONSerialization JSONObjectWithData:response options:0 error:nil];
            if (response) {
                NSLog(@"response amount %@",response);
                marrSinkingFund = [[NSMutableArray alloc] initWithArray:[response valueForKey:@"hisory"]];
                [self.tblHistory reloadData];
                if([[response valueForKey:@"can_pay"] isEqualToString:@"no"])
                {
                    [self.lblPayment setText:[NSString stringWithFormat:@"You have already paid fund for current month.\n\n Your next month fund is due on %@/%@.",[response valueForKey:@"next_payment_month"],[response valueForKey:@"next_payment_year"]]];
                    [self.btnPayPal setHidden:YES];
                }
                else
                {
                    fundAmount = [NSString stringWithFormat:@"%d",[[response valueForKey:@"amount"] intValue]];
                    fundPenalty = [NSString stringWithFormat:@"%d",[[response valueForKey:@"penalty_amount"] intValue]];
                    totalAmount = [NSString stringWithFormat:@"%d",[[response valueForKey:@"total_amount"] intValue]];
                    payDate = [response valueForKey:@"pay_date"];
                    
                    if([fundPenalty intValue] > 0)
                    {
                        [self.lblPayment setText:[NSString stringWithFormat:@"You have to pay %@ %@ with penalty of %@ %@",self.userLogin.currency_code,fundAmount,self.userLogin.currency_code,fundPenalty]];
                    }
                    else
                    {
                        [self.lblPayment setText:[NSString stringWithFormat:@"You have to pay %@ %@",self.userLogin.currency_code,fundAmount]];
                    }
                    if([[self.userLogin.payment_gateway valueForKey:@"account_type"] isEqualToString:@"1"])
                    {
                        if([[self.userLogin.payment_gateway valueForKey:@"mode"] isEqualToString:@"1"])
                            [PayPalMobile initializeWithClientIdsForEnvironments:@{PayPalEnvironmentProduction : [self.userLogin.payment_gateway valueForKey:@"live_url"], PayPalEnvironmentSandbox : @""}];
                        else
                            [PayPalMobile initializeWithClientIdsForEnvironments:@{PayPalEnvironmentProduction : @"", PayPalEnvironmentSandbox : [self.userLogin.payment_gateway valueForKey:@"sandbox_url"]}];
                        [self configurePaypal];
                    }
                    else
                    {
                        paymentsdk = [[Ipay alloc] init];
                        paymentsdk.delegate = self;
                        IpayPayment *payment = [[IpayPayment alloc] init];
                        [payment setPaymentId:@""];
                        [payment setMerchantKey:[self.userLogin.payment_gateway valueForKey:@"merchant_key"]];
                        [payment setMerchantCode:[self.userLogin.payment_gateway valueForKey:@"merchant_code"]];
                        [payment setRefNo:@"test"];
                        [payment setAmount:@"1.00"];// have to set
                        [payment setCurrency:@"MYR"];// have to set
                        [payment setProdDesc:@"testing"];
                        [payment setUserName:@"Tester Swati"];
                        [payment setUserEmail:self.userLogin.email];
                        [payment setUserContact:self.userLogin.mobile_no];
                        [payment setRemark:@"Testing SDK"];
                        [payment setLang:@"ISO-8859-1"];
                        [payment setCountry:@"MY"];
                        paymentView = [paymentsdk checkout:payment];
                    }

                    [self.btnPayPal setHidden:NO];
                }
            }
        }
        [MBProgressHUD hideHUDForView:self.view animated:YES];
    }];
}

-(void)configurePaypal
{
    _payPalConfig = [[PayPalConfiguration alloc] init];
    _payPalConfig.acceptCreditCards = YES;
    _payPalConfig.merchantName = @"Navsix Residents";
    _payPalConfig.merchantPrivacyPolicyURL = [NSURL URLWithString:@"https://www.paypal.com/webapps/mpp/ua/privacy-full"];
    _payPalConfig.merchantUserAgreementURL = [NSURL URLWithString:@"https://www.paypal.com/webapps/mpp/ua/useragreement-full"];
    _payPalConfig.languageOrLocale = [NSLocale preferredLanguages][0];
    _payPalConfig.payPalShippingAddressOption = PayPalShippingAddressOptionNone;
    self.environment = kPayPalEnvironment;
    [self setPayPalEnvironment:self.environment];
}

- (void)setPayPalEnvironment:(NSString *)environment
{
    self.environment = environment;
    [PayPalMobile preconnectWithEnvironment:environment];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma maek - UIButton Action methods

- (IBAction)btnBackClicked:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}

- (IBAction)btnPaymentsTapped:(id)sender
{
    [self.vwPayment setHidden:NO];
    [self.vwHistory setHidden:YES];
}

- (IBAction)btnHistoryTapped:(id)sender
{
    [self.vwPayment setHidden:YES];
    [self.vwHistory setHidden:NO];
}

- (IBAction)btnPaypalTapped:(id)sender
{
    if([[self.userLogin.payment_gateway valueForKey:@"account_type"] isEqualToString:@"1"])
    {
        PayPalPayment *payment = [[PayPalPayment alloc] init];
        payment.amount =  [NSDecimalNumber decimalNumberWithString:[NSString stringWithFormat:@"%@",totalAmount]];
        payment.currencyCode = self.userLogin.currency_code;
        payment.shortDescription = @"Sinking Fund";
        payment.items = nil;
        
        PayPalPaymentDetails *paymentDetails = [PayPalPaymentDetails paymentDetailsWithSubtotal:payment.amount withShipping:nil withTax:nil];
        payment.paymentDetails = paymentDetails;
        self.payPalConfig.acceptCreditCards = YES;
        PayPalPaymentViewController *paymentViewController = [[PayPalPaymentViewController alloc] initWithPayment:payment configuration:self.payPalConfig delegate:self];
        
        [self presentViewController:paymentViewController animated:YES completion:nil];
    }
    else
    {
        [self.view addSubview:paymentView];
    }
}

#pragma mark - iPay88 delegate methods

- (void)paymentSuccess:(NSString *)refNo withTransId:(NSString *)transId withAmount:(NSString *)amount withRemark:(NSString *)remark withAuthCode:(NSString *)authCode
{
    strTransactionID = transId;
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Pay Successfully"
                                                    message:[NSString stringWithFormat:@"Your have paid maintenance successfully with transection id : %@ .", strTransactionID]
                                                   delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
    alert.tag = 10;
    [alert show];
    [paymentView removeFromSuperview];
}

- (void)paymentFailed:(NSString *)refNo withTransId:(NSString *)transId withAmount:(NSString *)amount withRemark:(NSString *)remark withErrDesc:(NSString *)errDesc
{
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Payment Failed"
                                                    message:@"Touch \"Pay with PayPal\" to try again."
                                                   delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
    alert.tag = 30;
    [alert show];
    [paymentView removeFromSuperview];
}

- (void)paymentCancelled:(NSString *)refNo withTransId:(NSString *)transId withAmount:(NSString *)amount withRemark:(NSString *)remark withErrDesc:(NSString *)errDesc
{
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Order canceled"
                                                    message:@"You canceled your order. Touch \"Pay with PayPal\" to try again."
                                                   delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
    alert.tag = 30;
    [alert show];
    [paymentView removeFromSuperview];
}

-(void)requeryFailed:(NSString *)refNo withMerchantCode:(NSString *)merchantCode withAmount:(NSString *)amount withErrDesc:(NSString *)errDesc{}

-(void)requerySuccess:(NSString *)refNo withMerchantCode:(NSString *)merchantCode withAmount:(NSString *)amount withResult:(NSString *)result{}


#pragma mark PayPalPaymentDelegate methods

- (void)payPalPaymentViewController:(PayPalPaymentViewController *)paymentViewController didCompletePayment:(PayPalPayment *)completedPayment {
    NSLog(@"PayPal Payment Success!");
    strTransactionID = [[completedPayment.confirmation valueForKey:@"response"] valueForKey:@"id"];
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Pay Successfully"
                                                    message:[NSString stringWithFormat:@"Your have sink fund successfully with transection id : %@ .", strTransactionID]
                                                   delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
    alert.tag = 10;
    [alert show];
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (void)payPalPaymentDidCancel:(PayPalPaymentViewController *)paymentViewController {
    NSLog(@"PayPal Payment Canceled");
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Order canceled"
                                                    message:@"You canceled your order. Click \"Pay\" to try again."
                                                   delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
    alert.tag = 30;
    [alert show];
    [self dismissViewControllerAnimated:YES completion:nil];
}

#pragma mark Proof of payment validation

-(void)paymentCompleted: (int)transection_status
{
    [[ModelManager getInstance] payFund:self.userLogin.condo_id res_id:self.userLogin.res_id payDate:payDate fund_amount:fundAmount fund_penalty:fundPenalty totalAmount:totalAmount transectionID:strTransactionID transectionStatus:[NSNumber numberWithInt:transection_status] WithCallback:^(NSError *err, id response) {
        if (response != nil)
        {
            response = [NSJSONSerialization JSONObjectWithData:response options:0 error:nil];
            if (response)
            {
                [self getFund];
            }
        }
        [MBProgressHUD hideHUDForView:self.view animated:YES];
    }];
}


#pragma mark - UITableView Delegate Methods

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}


-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if(tableView == self.tblHistory)
    {
        return [marrSinkingFund count];
    }
    else
    {
        return [super tableView:tableView numberOfRowsInSection:section];
    }
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (tableView == self.tblHistory) {
        MaintenanceCell *cell = [tableView dequeueReusableCellWithIdentifier:@"paymentHistoryCell" forIndexPath:indexPath];
        NSString *strDisplay = [NSString stringWithFormat:@"Amount : %@ %@ (%@)",self.userLogin.currency_code, [[marrSinkingFund objectAtIndex:indexPath.row] valueForKey:@"amount"],[[marrSinkingFund objectAtIndex:indexPath.row] valueForKey:@"paid_by"]];
        [cell.lblMaintenanceDetail setText:strDisplay];
        [cell.lblMaintenanceDate setText:[[marrSinkingFund objectAtIndex:indexPath.row] valueForKey:@"pay_date"]];
        return cell;
    } else {
        return [super tableView:tableView cellForRowAtIndexPath:indexPath];
    }
    
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (tableView == self.tblHistory) {
        UIStoryboard *storyBoard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
        ReceiptViewController *objReceiptViewController = [storyBoard instantiateViewControllerWithIdentifier:@"ReceiptViewController"];
        
        [objReceiptViewController setStrPayDate:[[marrSinkingFund objectAtIndex:indexPath.row] valueForKey:@"pay_date"]];
        [objReceiptViewController setStrPayAmount:[NSString stringWithFormat:@"%@ %@",self.userLogin.currency_code, [[marrSinkingFund objectAtIndex:indexPath.row] valueForKey:@"amount"]]];
        [objReceiptViewController setStrTransactionID:[[marrSinkingFund objectAtIndex:indexPath.row] valueForKey:@"transaction_id"]];
        [objReceiptViewController setStrResidentName:[NSString stringWithFormat:@"%@ %@", self.userLogin.first_name, self.userLogin.last_name]];
        objReceiptViewController.userLogin = self.userLogin;
        [self.navigationController pushViewController:objReceiptViewController animated:YES];    } else {
            [super tableView:tableView didSelectRowAtIndexPath:indexPath];
        }
}

#pragma mark - UIAlertViewDelegate methods

-(void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    if(alertView.tag == 10)
    {
        [self.btnPayPal setHidden:YES];
        [self paymentCompleted:1];
    }
    if(alertView.tag == 20)
    {
        [self paymentCompleted:2];
    }
    if(alertView.tag == 30)
    {
        [self paymentCompleted:0];
    }
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
