//
//  SinkingFundViewController.h
//  ResidentApp
//
//  Created by TheAppGuruz-New-6 on 18/08/15.
//  Copyright (c) 2015 TheAppGuruz-New-6. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Ipay.h"
#import "IpayPayment.h"
#import "PayPalMobile.h"
#import "SlidingViewController.h"


@interface SinkingFundViewController : SlidingViewController<UIAlertViewDelegate, PayPalPaymentDelegate,PaymentResultDelegate>
{
    Ipay *paymentsdk;
    UIView *paymentView;
    NSString *strTransactionID;
    NSMutableArray *marrSinkingFund;
    NSString *fundAmount,*fundPenalty,*totalAmount,*payDate;
}

@property(nonatomic, strong, readwrite) NSString *environment;
@property(nonatomic, strong, readwrite) PayPalConfiguration *payPalConfig;
@property (strong, nonatomic) IBOutlet UIView *vwBody;
@property (weak, nonatomic) IBOutlet UILabel *lblPayment;
@property (strong, nonatomic) IBOutlet UIButton *btnPayPal;
@property (weak, nonatomic) IBOutlet UIView *vwHistory;
@property (weak, nonatomic) IBOutlet UIView *vwPayment;
@property (strong, nonatomic) IBOutlet UITableView *tblHistory;

@end
