//
//  UpdateViewController.h
//  ResidentApp
//
//  Created by TheAppGuruz-iOS-103 on 21/07/15.
//  Copyright (c) 2015 TheAppGuruz-New-6. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SlidingViewController.h"

@interface UpdateViewController : SlidingViewController<UIAlertViewDelegate>
{
    NSMutableArray *marrUpdate,*marrUpdateTemp;
    int intPageNumber;
}

@property (strong, nonatomic) IBOutlet UITableView *tblUpdate;

@end
