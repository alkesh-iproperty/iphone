//
//  UpdateViewController.m
//  ResidentApp
//
//  Created by TheAppGuruz-iOS-103 on 21/07/15.
//  Copyright (c) 2015 TheAppGuruz-New-6. All rights reserved.
//

#import "UpdateViewController.h"
#import "ModelManager.h"
#import "Util.h"
#import "UpdateNotificaitonList.h"
#import "MBProgressHUD.h"
#import "NotificationCell.h"
#import "WebsiteViewController.h"

@interface UpdateViewController () <UITableViewDataSource, UITableViewDelegate>

@end

@implementation UpdateViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    intPageNumber = 1;
    marrUpdate = [[NSMutableArray alloc] init];
    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    [self performSelector:@selector(getUpdatedNotificationData) withObject:nil afterDelay:0];
}

- (void)getUpdatedNotificationData
{
    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    [[ModelManager getInstance] updateNotificationData:self.userLogin.res_id pageNo:[NSNumber numberWithInt:intPageNumber] WithCallback:^(NSError *err, id response) {
        if(response != nil)
        {
            if ([Util checkIsEmpty:[NSJSONSerialization JSONObjectWithData:response options:0 error:nil]]) {
                intPageNumber = -1;
                [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
                return;
            }
            marrUpdateTemp = [[NSMutableArray alloc] initWithArray:[NSJSONSerialization JSONObjectWithData:response options:0 error:nil]];
            for (int i = 0; i < [marrUpdateTemp count]; i++) {
                UpdateNotificaitonList *updateNotification = [[UpdateNotificaitonList alloc] init];
                [updateNotification parseResponse:[marrUpdateTemp objectAtIndex:i]];
                [marrUpdateTemp replaceObjectAtIndex:i withObject:updateNotification];
            }
            for(int i = 0 ;i < marrUpdateTemp.count ;i++)
            {
                [marrUpdate addObject:[marrUpdateTemp objectAtIndex:i]] ;
            }

            [self.tblUpdate reloadData];
            [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
        }
        else
        {
            [Util invokeAlertMethod:nil Body:@"Error while Update your Notifications Data." Delegate:nil];
            [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
        }
        
    }];
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [marrUpdate count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    NotificationCell *cell = [tableView dequeueReusableCellWithIdentifier:@"updateCell" forIndexPath:indexPath];

    UpdateNotificaitonList *updateNotification = [marrUpdate objectAtIndex:indexPath.row];
    cell.lblNotificationName.text = updateNotification.message_title;
    cell.lblNotificationDate.text = updateNotification.datetime;
    
    if ([updateNotification.read isEqualToString:@"1"]) {
        [cell setBackgroundColor:[UIColor colorWithRed:11.0f/255.0f
                                                 green:86.0f/255.0f
                                                  blue:145.0f/255.0f
                                                 alpha:0.3f]];
    } else {
        [cell setBackgroundColor:[UIColor clearColor]];
    }
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    UpdateNotificaitonList *updateNotification = [marrUpdate objectAtIndex:indexPath.row];
    NSLog(@"objectttt %@ %@",updateNotification.content_type,updateNotification.content_type_data);
    NSString *strDisplay = [NSString stringWithFormat:@"Message : %@\nDate : %@", updateNotification.message_title, updateNotification.datetime];
    
    UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:@"Notification" message:strDisplay delegate:self cancelButtonTitle:@"Cancel" otherButtonTitles:@"Go", nil];
    alertView.tag = 10;
    [alertView show];
    if ([updateNotification.read isEqualToString:@"1"])
    {
        [MBProgressHUD showHUDAddedTo:self.view animated:YES];
        [[ModelManager getInstance] readUpdateNotification:updateNotification.not_id WithCallback:^(NSError *err, id response) {
            if(response != nil)
            {
                response = [[NSString alloc] initWithData:response encoding:NSUTF8StringEncoding];
                if([response isEqualToString:@"1"])
                {
                    int count = [[[NSUserDefaults standardUserDefaults] valueForKey:@"NotificationCount"] intValue] - 1;
                    if(count > 0)
                        [[NSUserDefaults standardUserDefaults] setValue:[NSString stringWithFormat:@"%d",count] forKey:@"NotificationCount"];
                    else
                        [[NSUserDefaults standardUserDefaults] setValue:nil forKey:@"NotificationCount"];
                    intPageNumber = 1;
                    marrUpdate = [[NSMutableArray alloc] init];
                    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
                    [self performSelector:@selector(getUpdatedNotificationData) withObject:nil afterDelay:0];
                }
                else
                    [Util invokeAlertMethod:@"Warning" Body:@"There is a problem while loading. Please try again." Delegate:nil];
            }
            else
                [Util invokeAlertMethod:@"Warning" Body:@"There is a problem while loading. Please try again." Delegate:nil];
            
            [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
        }];
    }
}

- (void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath
{
    if(tableView == self.tblUpdate)
    {
        if (indexPath.row == marrUpdate.count-1 && intPageNumber > 0) {
            intPageNumber++;
            [self performSelector:@selector(getUpdatedNotificationData) withObject:nil afterDelay:0];
        }
    }
}

#pragma mark -UIButton Action methods

- (IBAction)btnBackTapped:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}

#pragma mark -UIAlertView delegate methods

-(void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if(alertView.tag == 10)
    {
        if(buttonIndex == 1)
        {
            UpdateNotificaitonList *updateNotification = [marrUpdate objectAtIndex:[self.tblUpdate indexPathForSelectedRow].row];
            UIStoryboard *storyBoard = [UIStoryboard storyboardWithName:@"Main" bundle:[NSBundle mainBundle]];
            if([updateNotification.content_type intValue] == 2)
            {
                WebsiteViewController *websiteViewController = [storyBoard instantiateViewControllerWithIdentifier:@"WebsiteViewController"];
                websiteViewController.userLogin = self.userLogin;
                NSString *url = updateNotification.content_type_data;
                if ([url rangeOfString:@"http://"].location == NSNotFound) {
                    url = [@"http://" stringByAppendingString:updateNotification.content_type_data];
                }
                websiteViewController.webURL = url;
                [self.navigationController popViewControllerAnimated:YES];
                [self.navigationController pushViewController:websiteViewController animated:NO];
            }
            if([updateNotification.content_type intValue] == 3)
            {
                SlidingViewController *viewController;
                if([updateNotification.content_type_data isEqualToString:@"facility"])
                {
                    viewController = [storyBoard instantiateViewControllerWithIdentifier:@"BookingViewController"];
                }
                else if([updateNotification.content_type_data isEqualToString:@"fault_reporting"])
                {
                    viewController = [storyBoard instantiateViewControllerWithIdentifier:@"FaultReportingViewController"];
                }
                else if([updateNotification.content_type_data isEqualToString:@"emergency_no"])
                {
                    viewController = [storyBoard instantiateViewControllerWithIdentifier:@"ImportantNumberViewController"];
                }
                else if([updateNotification.content_type_data isEqualToString:@"notice"])
                {
                    viewController = [storyBoard instantiateViewControllerWithIdentifier:@"NoticesViewController"];
                }
                else if([updateNotification.content_type_data isEqualToString:@"management"])
                {
                    viewController = [storyBoard instantiateViewControllerWithIdentifier:@"ManagementViewController"];
                }
                else if([updateNotification.content_type_data isEqualToString:@"event"])
                {
                    viewController = [storyBoard instantiateViewControllerWithIdentifier:@"EventsViewController"];
                }
                else if([updateNotification.content_type_data isEqualToString:@"gallery"])
                {
                    viewController = [storyBoard instantiateViewControllerWithIdentifier:@"GalleryViewController"];
                }
                else if([updateNotification.content_type_data isEqualToString:@"website"])
                {
                    viewController = [storyBoard instantiateViewControllerWithIdentifier:@"WebsiteViewController"];
                }
                else if([updateNotification.content_type_data isEqualToString:@"guest_list_request"])
                {
                    viewController = [storyBoard instantiateViewControllerWithIdentifier:@"GuestViewController"];
                }
                else if([updateNotification.content_type_data isEqualToString:@"maintenance"])
                {
                    viewController = [storyBoard instantiateViewControllerWithIdentifier:@"MaintenanceViewController"];
                }
                viewController.userLogin = self.userLogin;
                [self.navigationController popViewControllerAnimated:YES];
                [self.navigationController pushViewController:viewController animated:NO];
            }
        }
    }
}

@end
