//
//  HomeScreenViewController.h
//  ResidentApp
//
//  Created by TheAppGuruz-New-6 on 07/07/15.
//  Copyright (c) 2015 TheAppGuruz-New-6. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SlidingViewController.h"
#import "BookingViewController.h"
#import <CoreLocation/CoreLocation.h>

@interface HomeScreenViewController : SlidingViewController
{
    CLLocationManager *locationManager;
    double latSource, lonSource, latDestination, lonDestination;
}

@property (weak, nonatomic) IBOutlet UIButton *btnSlider;
@property (weak, nonatomic) IBOutlet UIImageView *ivHome;


@end
