//
//  HomeScreenViewController.m
//  ResidentApp
//
//  Created by TheAppGuruz-New-6 on 07/07/15.
//  Copyright (c) 2015 TheAppGuruz-New-6. All rights reserved.
//

#import "HomeScreenViewController.h"
#import "UIImageView+WebCache.h"
#import "UpdateViewController.h"
#import "WebsiteViewController.h"

@interface HomeScreenViewController () <CLLocationManagerDelegate>

@end

@implementation HomeScreenViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    if([[NSUserDefaults standardUserDefaults] objectForKey:@"NotificationObject"] != nil)
    {
        NSDictionary *userInfo = [[NSUserDefaults standardUserDefaults] objectForKey:@"NotificationObject"];
        UIStoryboard *storyBoard = [UIStoryboard storyboardWithName:@"Main" bundle:[NSBundle mainBundle]];
        if([[userInfo valueForKey:@"content_type"] isEqualToString:@"2"])
        {
            WebsiteViewController *websiteViewController = [storyBoard instantiateViewControllerWithIdentifier:@"WebsiteViewController"];
            websiteViewController.userLogin = self.userLogin;
            NSString *url = [userInfo valueForKey:@"content_type_data"];
            if ([url rangeOfString:@"http://"].location == NSNotFound) {
                url = [@"http://" stringByAppendingString:[userInfo valueForKey:@"content_type_data"]];
            }
            websiteViewController.webURL = url;
            [self.navigationController pushViewController:websiteViewController animated:NO];
        }
        if([[userInfo valueForKey:@"content_type"] isEqualToString:@"3"])
        {
            UIStoryboard *storyBoard = [UIStoryboard storyboardWithName:@"Main" bundle:[NSBundle mainBundle]];
            SlidingViewController *viewController;
            if([[userInfo valueForKey:@"content_type_data"] isEqualToString:@"facility"])
            {
                viewController = [storyBoard instantiateViewControllerWithIdentifier:@"BookingViewController"];
            }
            else if([[userInfo valueForKey:@"content_type_data"] isEqualToString:@"fault_reporting"])
            {
                viewController = [storyBoard instantiateViewControllerWithIdentifier:@"FaultReportingViewController"];
            }
            else if([[userInfo valueForKey:@"content_type_data"] isEqualToString:@"emergency_no"])
            {
                viewController = [storyBoard instantiateViewControllerWithIdentifier:@"ImportantNumberViewController"];
            }
            else if([[userInfo valueForKey:@"content_type_data"] isEqualToString:@"notice"])
            {
                viewController = [storyBoard instantiateViewControllerWithIdentifier:@"NoticesViewController"];
            }
            else if([[userInfo valueForKey:@"content_type_data"] isEqualToString:@"management"])
            {
                viewController = [storyBoard instantiateViewControllerWithIdentifier:@"ManagementViewController"];
            }
            else if([[userInfo valueForKey:@"content_type_data"] isEqualToString:@"event"])
            {
                viewController = [storyBoard instantiateViewControllerWithIdentifier:@"EventsViewController"];
            }
            else if([[userInfo valueForKey:@"content_type_data"] isEqualToString:@"gallery"])
            {
                viewController = [storyBoard instantiateViewControllerWithIdentifier:@"GalleryViewController"];
            }
            else if([[userInfo valueForKey:@"content_type_data"] isEqualToString:@"website"])
            {
                viewController = [storyBoard instantiateViewControllerWithIdentifier:@"WebsiteViewController"];
            }
            else if([[userInfo valueForKey:@"content_type_data"] isEqualToString:@"guest_list_request"])
            {
                viewController = [storyBoard instantiateViewControllerWithIdentifier:@"GuestViewController"];
            }
            else if([[userInfo valueForKey:@"content_type_data"] isEqualToString:@"maintenance"])
            {
                viewController = [storyBoard instantiateViewControllerWithIdentifier:@"MaintenanceViewController"];
            }
            viewController.userLogin = self.userLogin;
            [self.navigationController pushViewController:viewController animated:NO];
        }
    }
}

-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    if([[NSUserDefaults standardUserDefaults] valueForKey:@"NotificationCount"])
    {
        [self.lblUpdateCount setText:[[NSUserDefaults standardUserDefaults] valueForKey:@"NotificationCount"]];
        [self.lblUpdateCount setHidden:NO];
    }
    else
        [self.lblUpdateCount setHidden:YES];
    [self changeImage];
    [self createLocationObject];
}

-(void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    [NSObject cancelPreviousPerformRequestsWithTarget:self];
}

-(void)createLocationObject
{
    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    locationManager = [[CLLocationManager alloc] init];
    locationManager.delegate = self;
    locationManager.distanceFilter = kCLDistanceFilterNone; // whenever we move
    locationManager.desiredAccuracy = kCLLocationAccuracyHundredMeters; // 100 m
    [locationManager requestWhenInUseAuthorization];
    [locationManager requestAlwaysAuthorization];
    if ([locationManager respondsToSelector:@selector(requestWhenInUseAuthorization)]) {
        [locationManager requestWhenInUseAuthorization];
    }
    [locationManager startUpdatingLocation];
}

- (void)locationManager:(CLLocationManager *)manager
     didUpdateLocations:(NSArray *)locations __OSX_AVAILABLE_STARTING(__MAC_NA,__IPHONE_6_0)
{
    CLLocation *newLocation = [locations objectAtIndex:0];
    latSource = newLocation.coordinate.latitude;
    lonSource = newLocation.coordinate.longitude;
    latDestination = [self.userLogin.latitude doubleValue];
    lonDestination = [self.userLogin.longitude doubleValue];
    [locationManager stopUpdatingLocation];
    [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
}

- (void)locationManager:(CLLocationManager *)manager
       didFailWithError:(NSError *)error
{
    [locationManager stopUpdatingLocation];
    [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
}

-(void)changeImage
{
    [UIView animateWithDuration:2.0f
                          delay:0.0
                        options:UIViewAnimationOptionCurveEaseInOut
                     animations:^{
                         if(self.userLogin.slider_images.count > 0)
                         {
                             [self.ivHome setImage:[UIImage imageWithContentsOfFile:[[FILEPATH_Documents stringByAppendingPathComponent:@"SliderImages"] stringByAppendingPathComponent:[self.userLogin.slider_images objectAtIndex:self.ivHome.tag]]]];
                         }
                     }
                     completion:^(BOOL finished) {
                         if ((self.ivHome.tag + 1) == self.userLogin.slider_images.count) {
                             self.ivHome.tag = 0;
                         } else {
                             self.ivHome.tag = self.ivHome.tag + 1;
                         }
                         [self performSelector:@selector(changeImage) withObject:nil afterDelay:5];
                     }];
}

- (IBAction)btnCallUsTapped:(id)sender
{
    if([[UIApplication sharedApplication] canOpenURL:[NSURL URLWithString:@"tel://"]])
    {
        [[UIApplication sharedApplication] openURL:[NSURL URLWithString:[NSString stringWithFormat:@"tel://%@", self.userLogin.mobile_no]]];
    }
    else
    {
        [Util invokeAlertMethod:@"Warning" Body:@"Phone call is not supported in device." Delegate:self];
    }

}

- (IBAction)btnGetDirectionTapped:(id)sender
{
    UIApplication *app = [UIApplication sharedApplication];
    
    NSString *coordinates = [NSString stringWithFormat: @"http://maps.apple.com/maps?saddr=%f,%f&daddr=%f,%f", latSource, lonSource, latDestination, lonDestination];
    
    [app openURL:[NSURL URLWithString: coordinates]];
}

-(void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    if([segue.identifier isEqualToString:@"OpenUpdatesView"])
    {
        UpdateViewController *viewController = [segue destinationViewController];
        viewController.userLogin = self.userLogin;
    }
        
}

@end