//
//  EventDetailViewController.m
//  ResidentApp
//
//  Created by TheAppGuruz on 10/07/15.
//  Copyright (c) 2015 TheAppGuruz-New-6. All rights reserved.
//

#import "EventDetailViewController.h"
#import "UIImageView+WebCache.h"
#import "MBProgressHUD.h"

#define Image_Base_Url @"http://www.condomanagementsystem.com/upload/event/"

@interface EventDetailViewController ()

@end

@implementation EventDetailViewController

#pragma mark - View LifeCycle Methods
- (void)viewDidLoad
{
    [super viewDidLoad];
    
    [self setEventData];
}

-(void)setEventData
{
    if(IS_IPHONE_4_OR_LESS)
       [self.scrollView setContentSize:CGSizeMake(0, self.view.bounds.size.height + 100)];
    self.lblTitle.text = self.event.event_name;
    self.lblStartTime.text = [NSString stringWithFormat:@" Start Time : %@", self.event.start_time];
    self.lblEndTime.text = [NSString stringWithFormat:@" End Time : %@", self.event.end_time];
    if([self.event.total_person intValue] == 0)
        self.lblNoOfPeople.text=@" Nobody still joined this event.";
    else
        self.lblNoOfPeople.text=[NSString stringWithFormat:@" %@ people joined this event.",self.event.total_person];
    self.tvDesc.text = [NSString stringWithFormat:@"Description : %@", self.event.event_desc];
    [self.ivEventImages sd_setImageWithURL:[NSURL URLWithString:[[NSString stringWithFormat:@"%@%@", Image_Base_Url, self.event.event_img] stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]] placeholderImage:[UIImage imageNamed:@"imgNotFound.png"]];
    if([self.event.event_type intValue] == 1)
    {
        [self.btnJoin setHidden:YES];
        [self.btnLeave setHidden:YES];
    }
    
}

#pragma mark - Action Methods
-(IBAction)btnBackPress:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}
- (IBAction)btnJoinClicked:(id)sender
{
    [self joinEvent];
}
- (IBAction)btnLeaveClicked:(id)sender
{
    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    [self actionOnEvent:1 noOfPeople:0];

}

#pragma mark - Other methods

-(void)joinEvent
{
    UIAlertView *alertEvent =[[UIAlertView alloc]initWithTitle:[NSString stringWithFormat:@"%@",self.event.event_name] message:nil delegate:self cancelButtonTitle:@"Cancel" otherButtonTitles:@"Join", nil];
    
    UIView *vwAlert = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 250, 100)];
    UILabel *lblConfirmPassword=[[UILabel alloc]initWithFrame:CGRectMake(10,0, 100, 35)];
    [lblConfirmPassword setTextColor:[UIColor colorWithRed:11.0f/255.0f
                                                     green:86.0f/255.0f
                                                      blue:145.0f/255.0f
                                                     alpha:1.0f]];
    [lblConfirmPassword setFont:[UIFont boldSystemFontOfSize:14]];
    [lblConfirmPassword setNumberOfLines:2];
    lblConfirmPassword.text=@"No. of people:";
    [vwAlert addSubview:lblConfirmPassword];
    
    txtNoOfPeople=[[UITextField alloc]initWithFrame:CGRectMake(105,0, 160, 30)];
    txtNoOfPeople.delegate = self;
    [txtNoOfPeople setSecureTextEntry:YES];
    [txtNoOfPeople setBorderStyle:UITextBorderStyleRoundedRect];
    [vwAlert addSubview:txtNoOfPeople];
    
    [alertEvent setValue:vwAlert forKey:@"accessoryView"];
    alertEvent.tag = 20;
    [alertEvent show];
}

#pragma mark - UIAlertView Delegate methods

-(void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if(alertView.tag == 20)
    {
        if(buttonIndex == 1)
        {
            if([txtNoOfPeople.text isEqualToString:@""] || [txtNoOfPeople.text isEqualToString:@"0"])
            {
                [Util invokeAlertMethod:@"Warning" Body:@"Please enter no. of people" Delegate:nil];
                [self joinEvent];
            }
            else
            {
                [MBProgressHUD showHUDAddedTo:self.view animated:YES];
                [self actionOnEvent:1 noOfPeople:[[NSString stringWithFormat:@"%@",txtNoOfPeople.text] intValue]];
            }
        }
    }
}

#pragma mark - UITextField delegate methods

-(BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    return YES;
}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    if(textField == txtNoOfPeople) {
        NSCharacterSet *nonNumberSet = [[NSCharacterSet decimalDigitCharacterSet] invertedSet];
        return ([string stringByTrimmingCharactersInSet:nonNumberSet].length > 0) || [string isEqualToString:@""];
    }
    return YES;
}

#pragma mark - WS methods

-(void)actionOnEvent : (int)action noOfPeople:(int)no_of_people
{
    [[ModelManager getInstance] actionOnEvent:self.userLogin.condo_id res_id:self.userLogin.res_id event_id:self.event.event_id action:[NSNumber numberWithInt:action] no_of_person:[NSNumber numberWithInt:no_of_people] WithCallback:^(NSError *err, id response) {
        if(response != nil)
        {
            response = [[NSString alloc] initWithData:response encoding:NSUTF8StringEncoding];
            if([response isEqualToString:@"0"])
                [Util invokeAlertMethod:@"Warning" Body:@"Event not found." Delegate:nil];
            else if([response isEqualToString:@"1"])
                [Util invokeAlertMethod:@"Warning" Body:@"Event type is not valid." Delegate:nil];
            else if([response isEqualToString:@"2"])
                [Util invokeAlertMethod:@"Warning" Body:@"Event invitation can not save." Delegate:nil];
            else if([response isEqualToString:@"3"])
                [Util invokeAlertMethod:@"Warning" Body:@"Event invitation already accepted or declined." Delegate:nil];
            else
                [Util invokeAlertMethod:@"Success" Body:@"Your request submitted successfully." Delegate:nil];
        }
        [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
    }];
}

@end