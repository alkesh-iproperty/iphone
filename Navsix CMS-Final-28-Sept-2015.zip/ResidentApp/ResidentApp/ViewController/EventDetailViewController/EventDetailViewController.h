//
//  EventDetailViewController.h
//  ResidentApp
//
//  Created by TheAppGuruz on 10/07/15.
//  Copyright (c) 2015 TheAppGuruz-New-6. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Event.h"
#import "SlidingViewController.h"

@interface EventDetailViewController : SlidingViewController<UIAlertViewDelegate,UITextFieldDelegate>
{
    UITextField *txtNoOfPeople;
}
@property (nonatomic, strong) IBOutlet UILabel *lblTitle;
@property (nonatomic, strong) IBOutlet UILabel *lblStartTime;
@property (nonatomic, strong) IBOutlet UILabel *lblEndTime;
@property (nonatomic, strong) IBOutlet UITextView *tvDesc;
@property (nonatomic, strong) Event *event;
@property (weak, nonatomic) IBOutlet UIImageView *ivEventImages;
@property (weak, nonatomic) IBOutlet UIButton *btnJoin;
@property (weak, nonatomic) IBOutlet UIButton *btnLeave;
@property (weak, nonatomic) IBOutlet UILabel *lblNoOfPeople;
@property (weak, nonatomic) IBOutlet UIScrollView *scrollView;

@end
