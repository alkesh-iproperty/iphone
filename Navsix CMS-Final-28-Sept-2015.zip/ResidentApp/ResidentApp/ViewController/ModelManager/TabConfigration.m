//
//  TabPayment.m
//  ResidentApp
//
//  Created by TheAppGuruz on 07/07/15.
//  Copyright (c) 2015 TheAppGuruz-New-6. All rights reserved.
//

#import "TabConfigration.h"

@implementation TabConfigration

-(int)parseResponse:(NSDictionary *)dictionary
{
    self.facility = [dictionary valueForKey:@"facility"];
    self.fault_reporting = [dictionary valueForKey:@"fault_reporting"];
    self.emergency_no = [dictionary valueForKey:@"emergency_no"];
    self.notice = [dictionary valueForKey:@"notice"];
    self.management = [dictionary valueForKey:@"management"];
    self.event = [dictionary valueForKey:@"event"];
    self.gallery = [dictionary valueForKey:@"gallery"];
    self.website = [dictionary valueForKey:@"website"];
    self.guest_list_request = [dictionary valueForKey:@"guest_list_request"];
    self.maintenance = [dictionary valueForKey:@"maintenance"];
    
    return 0;
}

@end