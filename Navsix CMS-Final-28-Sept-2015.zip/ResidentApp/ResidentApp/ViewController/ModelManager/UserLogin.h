//
//  UserLogin.h
//  ResidentApp
//
//  Created by TheAppGuruz on 07/07/15.
//  Copyright (c) 2015 TheAppGuruz-New-6. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface UserLogin : NSObject

@property (nonatomic, strong) NSNumber *res_id;
@property (nonatomic, strong) NSNumber *condo_id;
@property (nonatomic, strong) NSString *first_name;
@property (nonatomic, strong) NSString *last_name;
@property (nonatomic, strong) NSString *resident_id;
@property (nonatomic, strong) NSString *email;
@property (nonatomic, strong) NSString *app_login;
@property (nonatomic, strong) NSString *block_id;
@property (nonatomic, strong) NSString *block_name;
@property (nonatomic, strong) NSString *unit_id;
@property (nonatomic, strong) NSString *unit_name;
@property (nonatomic, strong) NSString *mobile_no;
@property (nonatomic, strong) NSString *maintance_amount;
@property (nonatomic, strong) NSMutableArray *slider_images;

-(int)parseResponse:(NSDictionary *)dictionary;

@end
