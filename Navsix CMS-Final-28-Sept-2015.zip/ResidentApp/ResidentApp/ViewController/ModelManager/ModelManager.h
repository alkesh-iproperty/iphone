//
//  ModelManager.h
//  ResidentApp
//
//  Created by TheAppGuruz-New-6 on 07/07/15.
//  Copyright (c) 2015 TheAppGuruz-New-6. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface ModelManager : NSObject

typedef void (^callbackBlock)(NSError* err, id response);

+ (ModelManager *)getInstance;

-(void)getUserLogin:(NSString *)securityId Password:(NSString *)password WithCallback:(callbackBlock)callback;
-(void)registerDeviceId:(NSNumber *)condo_id res_id:(NSNumber *)res_id device_id:(NSString *)device_id WithCallback:(callbackBlock)callback;
-(void)addFault:(NSNumber *)condo_id res_id:(NSNumber *)res_id fault_name:(NSString *)fault_name fault_desc:(NSString *)fault_desc UploadImage:(UIImage *)uploadImage WithCallback:(callbackBlock)callback;
-(void)listFaultPhoto:(NSNumber *)condo_id res_id:(NSNumber *)res_id WithCallback:(callbackBlock)callback;
-(void)listEmergencyNo:(NSNumber *)condo_id WithCallback:(callbackBlock)callback;
-(void)listNotices:(NSNumber *)condo_id WithCallback:(callbackBlock)callback;
-(void)listManagement:(NSNumber *)condo_id WithCallback:(callbackBlock)callback;
-(void)listEvents:(NSNumber *)condo_id WithCallback:(callbackBlock)callback;
-(void)actionOnEvent:(NSNumber *)condo_id res_id:(NSNumber *)res_id event_id:(NSNumber *)event_id action:(NSNumber *)action WithCallback:(callbackBlock)callback;
-(void)listGallery:(NSNumber *)condo_id WithCallback:(callbackBlock)callback;
-(void)listGalleryItem:(NSNumber *)condo_id g_id:(NSNumber *)g_id WithCallback:(callbackBlock)callback;
-(void)listWebsite:(NSNumber *)condo_id WithCallback:(callbackBlock)callback;
-(void)maintenanceAmount:(NSNumber *)res_id WithCallback:(callbackBlock)callback;
-(void)payMaintenance:(NSNumber *)condo_id res_id:(NSNumber *)res_id maintenance_amount:(NSString *)maintenance_amount pay_date:(NSString *)pay_date WithCallback:(callbackBlock)callback;
-(void)paymentConfiguration:(NSNumber *)condo_id WithCallback:(callbackBlock)callback;
-(void)tabConfigration:(NSNumber *)condo_id WithCallback:(callbackBlock)callback;
-(void)listMasterFacility:(NSNumber *)condo_id WithCallback:(callbackBlock)callback;
-(void)listChildFacility:(NSNumber *)condo_id res_id:(NSNumber *)res_id fm_id:(NSNumber *)fm_id change_bk:(NSNumber *)change_bk date:(NSString *)date WithCallback:(callbackBlock)callback;
-(void)addBooking:(NSNumber *)res_id ft_id:(NSNumber *)ft_id change_bk:(NSNumber *)change_bk date:(NSString *)date WithCallback:(callbackBlock)callback;
-(void)listBookingForResident:(NSNumber *)condo_id res_id:(NSNumber *)res_id upcoming:(NSNumber *)upcoming WithCallback:(callbackBlock)callback;
-(void)changeBooking:(NSNumber *)res_id ft_id:(NSNumber *)ft_id change_bk:(NSNumber *)change_bk date:(NSString *)date WithCallback:(callbackBlock)callback;
-(void)cancelBooking:(NSNumber *)res_id fb_id:(NSNumber *)fb_id WithCallback:(callbackBlock)callback;

@end