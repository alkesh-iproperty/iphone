//
//  TabPayment.h
//  ResidentApp
//
//  Created by TheAppGuruz on 07/07/15.
//  Copyright (c) 2015 TheAppGuruz-New-6. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface TabConfigration : NSObject

@property (nonatomic, strong) NSNumber *facility;
@property (nonatomic, strong) NSNumber *fault_reporting;
@property (nonatomic, strong) NSNumber *emergency_no;
@property (nonatomic, strong) NSNumber *notice;
@property (nonatomic, strong) NSNumber *management;
@property (nonatomic, strong) NSNumber *event;
@property (nonatomic, strong) NSNumber *gallery;
@property (nonatomic, strong) NSNumber *website;
@property (nonatomic, strong) NSNumber *guest_list_request;
@property (nonatomic, strong) NSNumber *maintenance;

-(int)parseResponse:(NSDictionary *)dictionary;

@end