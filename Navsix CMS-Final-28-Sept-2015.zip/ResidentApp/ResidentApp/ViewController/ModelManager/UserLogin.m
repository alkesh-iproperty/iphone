//
//  UserLogin.m
//  ResidentApp
//
//  Created by TheAppGuruz on 07/07/15.
//  Copyright (c) 2015 TheAppGuruz-New-6. All rights reserved.
//

#import "UserLogin.h"

@implementation UserLogin

-(int)parseResponse:(NSDictionary *)dictionary
{
    self.res_id = [dictionary valueForKey:@"res_id"];
    self.condo_id = [dictionary valueForKey:@"condo_id"];
    self.first_name = [dictionary valueForKey:@"first_name"];
    self.last_name = [dictionary valueForKey:@"last_name"];
    self.resident_id = [dictionary valueForKey:@"resident_id"];
    self.email = [dictionary valueForKey:@"email"];
    self.app_login = [dictionary valueForKey:@"app_login"];
    self.block_id = [dictionary valueForKey:@"block_id"];
    self.block_name = [dictionary valueForKey:@"block_name"];
    self.unit_id = [dictionary valueForKey:@"unit_id"];
    self.unit_name = [dictionary valueForKey:@"unit_name"];
    self.mobile_no = [dictionary valueForKey:@"mobile_no"];
    self.maintance_amount = [dictionary valueForKey:@"maintance_amount"];
    self.slider_images = [NSMutableArray arrayWithArray:[dictionary valueForKey:@"slider_images"]];
    
    return 0;
}

@end