//
//  Notice.h
//  ResidentApp
//
//  Created by TheAppGuruz on 07/07/15.
//  Copyright (c) 2015 TheAppGuruz-New-6. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Notice : NSObject

@property (nonatomic, strong) NSNumber *notice_id;
@property (nonatomic, strong) NSString *name;
@property (nonatomic, strong) NSString *file_name;

-(int)parseResponse:(NSDictionary *)dictionary;

@end