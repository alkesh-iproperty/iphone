//
//  Util.h
//  ResidentApp
//
//  Created by TheAppGuruz-New-6 on 07/07/15.
//  Copyright (c) 2015 TheAppGuruz-New-6. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface Util : NSObject

+(BOOL)checkIsEmpty:(NSString *)string;
+(void)invokeAlertMethod:(NSString *)strTitle Body:(NSString *)strBody Delegate:(id)delegate;
+(UIImage*)rotateImage:(UIImage*)img byOrientationFlag:(UIImageOrientation)orient;
+(UIImage *)resizeImage:(UIImage *)anImage width:(int)widthI height:(int)heightI;
+(UIImage *)rotateImageby90:(UIImage *)image;
+(UIImage *)rotateImage:(UIImage *)imgRotate byDegree:(CGFloat)ftDegree;
+(void)setViewDesign:(UIView *)vwCurrent BorderColor:(UIColor *)borderColor BorderWidth:(int)width CornerRadious:(float)cornerRadious;

@end
