//
//  Booking.h
//  ResidentApp
//
//  Created by TheAppGuruz on 08/07/15.
//  Copyright (c) 2015 TheAppGuruz-New-6. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Booking : NSObject

@property (nonatomic, strong) NSNumber *approve;
@property (nonatomic, strong) NSNumber *booking_cancelled;
@property (nonatomic, strong) NSNumber *booking_changed;
@property (nonatomic, strong) NSString *expiration_datetime;
@property (nonatomic, strong) NSNumber *fb_id;
@property (nonatomic, strong) NSNumber *fc_id;
@property (nonatomic, strong) NSString *fc_name;
@property (nonatomic, strong) NSNumber *fm_id;
@property (nonatomic, strong) NSNumber *status;
@property (nonatomic, strong) NSString *time_slot_end;
@property (nonatomic, strong) NSString *time_slot_start;

-(int)parseResponse:(NSDictionary *)dictionary;

@end