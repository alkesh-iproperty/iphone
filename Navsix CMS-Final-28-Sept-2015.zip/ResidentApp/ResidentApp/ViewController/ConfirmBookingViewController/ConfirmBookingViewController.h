//
//  ConfirmBookingViewController.h
//  ResidentApp
//
//  Created by TheAppGuruz on 09/07/15.
//  Copyright (c) 2015 TheAppGuruz-New-6. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SlidingViewController.h"
#import "PayPalMobile.h"
#import "BookingHistoryViewController.h"

@interface ConfirmBookingViewController : SlidingViewController<PayPalPaymentDelegate>
{
    NSDictionary *dictCurrentBooking;
    NSString *strTransactionID;
    NSNumber *bookingID;
    NSArray *arrResponse;
}

@property(nonatomic, strong, readwrite) NSString *environment;
@property(nonatomic, strong, readwrite) PayPalConfiguration *payPalConfig;
@property (nonatomic, strong) IBOutlet UILabel *lblTitle;
@property (nonatomic, strong) IBOutlet UITableView *tbBooking;
@property (weak, nonatomic) IBOutlet UIImageView *ivBackgroundConfirm;
@property (nonatomic, strong) NSNumber *res_id;
@property (nonatomic, strong) NSString *titleLabel;
@property (nonatomic, strong) NSMutableArray *marrBookingData;
@property (nonatomic, strong) NSString *paymentType;
@property (nonatomic, strong) NSString *selectedDate;
@property (nonatomic, strong) NSString *mode;
@property (nonatomic, strong) NSString *liveURL;
@property (nonatomic, strong) NSString *sandBoxURL;
@property (nonatomic, strong) NSNumber *changeBookingFbID;

@property BOOL isEdit;
@end
