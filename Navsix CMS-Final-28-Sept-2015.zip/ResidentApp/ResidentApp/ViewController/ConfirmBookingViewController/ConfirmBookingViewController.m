//
//  ConfirmBookingViewController.m
//  ResidentApp
//
//  Created by TheAppGuruz on 09/07/15.
//  Copyright (c) 2015 TheAppGuruz-New-6. All rights reserved.
//

#import "ConfirmBookingViewController.h"
#import "BookingCell.h"
#import "MBProgressHUD.h"
#import "ModelManager.h"
#import "Util.h"

// for Live trasaction use PayPalEnvironmentProduction
//#define kPayPalEnvironment PayPalEnvironmentSandbox
#define kPayPalEnvironment PayPalEnvironmentProduction
@interface ConfirmBookingViewController ()

@end

@implementation ConfirmBookingViewController

#pragma mark - View LifeCycle Methods
- (void)viewDidLoad
{
    [super viewDidLoad];
    self.lblTitle.text = self.titleLabel;
}

-(void)configurePaypal
{
    _payPalConfig = [[PayPalConfiguration alloc] init];
    _payPalConfig.acceptCreditCards = YES;
    _payPalConfig.merchantName = @"Navsix Residents";
    _payPalConfig.merchantPrivacyPolicyURL = [NSURL URLWithString:@"https://www.paypal.com/webapps/mpp/ua/privacy-full"];
    _payPalConfig.merchantUserAgreementURL = [NSURL URLWithString:@"https://www.paypal.com/webapps/mpp/ua/useragreement-full"];
    _payPalConfig.languageOrLocale = [NSLocale preferredLanguages][0];
    _payPalConfig.payPalShippingAddressOption = PayPalShippingAddressOptionNone;
    self.environment = kPayPalEnvironment;
    [self setPayPalEnvironment:self.environment];
}

- (void)setPayPalEnvironment:(NSString *)environment
{
    self.environment = environment;
    [PayPalMobile preconnectWithEnvironment:environment];
}


#pragma mark - Action Methods
-(IBAction)btnBackPress:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}

-(void)btnBookPress:(id)sender
{
    UIButton *btnBook = (UIButton *)sender;
    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    dictCurrentBooking = [self.marrBookingData objectAtIndex:btnBook.tag];
    if(self.isEdit)
        [self performSelector:@selector(changeBookingData:) withObject:[self.marrBookingData objectAtIndex:btnBook.tag] afterDelay:0];
    else
        [self performSelector:@selector(addBookingData:) withObject:[self.marrBookingData objectAtIndex:btnBook.tag] afterDelay:0];
}

#pragma mark PayPalPaymentDelegate methods

- (void)payPalPaymentViewController:(PayPalPaymentViewController *)paymentViewController didCompletePayment:(PayPalPayment *)completedPayment {
    NSLog(@"PayPal Payment Success!");
    strTransactionID = [[completedPayment.confirmation valueForKey:@"response"] valueForKey:@"id"];
    [self updateBooking:1];
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (void)payPalPaymentDidCancel:(PayPalPaymentViewController *)paymentViewController {
    NSLog(@"PayPal Payment Canceled");
    [self updateBooking:0];
    [self dismissViewControllerAnimated:YES completion:nil];
}

#pragma mark Proof of payment validation

-(void)updateBooking: (int)transection_status
{
    if(strTransactionID != nil)
    {
        [[ModelManager getInstance] updateBooking:self.userLogin.res_id fb_id:bookingID transectionID:strTransactionID transectionStatus:[NSNumber numberWithInt:transection_status] WithCallback:^(NSError *err, id response) {
            if (response != nil)
            {
                response = [[NSString alloc] initWithData:response encoding:NSUTF8StringEncoding];
                if([self.paymentType isEqualToString:@"2"])
                {
                    if ([response isEqualToString:@"1"])
                        [Util invokeAlertMethod:@"Suceess" Body:[NSString stringWithFormat:@"Your have booked successfully with transection id : %@ .", strTransactionID] Delegate:self];
                    else
                        [Util invokeAlertMethod:@"Warning" Body:@"Booking Failed. Please Try Later" Delegate:self];
                }
                else
                {
                    if (arrResponse.count == 1)
                    {
                        [Util invokeAlertMethod:@"Success" Body:@"Your event booked successfully"  Delegate:self];
                    }
                    else
                    {
                        if(arrResponse.count == 2 && [[arrResponse objectAtIndex:0] isEqualToString:@"pay_deposit"])
                            [Util invokeAlertMethod:@"Warning" Body:[NSString stringWithFormat:@"This slot has been only blocked for you due to Insufficient deposit. Please submit deposit cheque of %@ now to management office to confirm your booking",[arrResponse objectAtIndex:1]]  Delegate:self];
                        else
                            [Util invokeAlertMethod:@"Warning" Body:[NSString stringWithFormat:@"This slot has been only blocked for you due to Insufficient deposit. Please submit deposit cheque of %@ within %@ day to management office to confirm your booking",[arrResponse objectAtIndex:1],[arrResponse objectAtIndex:2]]  Delegate:self];;
                    }

//                    if([[arrResponse objectAtIndex:2] isEqualToString:@"-1"])
//                    {
//                        [Util invokeAlertMethod:@"Warning" Body:[NSString stringWithFormat:@"Your event booked successfully.Insufficient deposit. Please pay deposit cheque of $%@ to management office to book facility now.",[arrResponse objectAtIndex:1]]  Delegate:self];
//                    }
//                    else
//                    {
//                        [Util invokeAlertMethod:@"Warning" Body:[NSString stringWithFormat:@"Your event is booked.  Please pay deposit cheque of $%@ to management office within %@ day to confirm your booking.",[arrResponse objectAtIndex:1],[arrResponse objectAtIndex:2]]  Delegate:self];
//                    }
                }
                
            }
            [MBProgressHUD hideHUDForView:self.view animated:YES];
        }];
    }
    else
    {
        [[ModelManager getInstance] updateBooking:self.userLogin.res_id fb_id:bookingID transectionID:@"" transectionStatus:[NSNumber numberWithInt:transection_status] WithCallback:^(NSError *err, id response) {
            if (response != nil)
            {
                response = [[NSString alloc] initWithData:response encoding:NSUTF8StringEncoding];
                if([response isEqualToString:@"1"])
                {
                    [Util invokeAlertMethod:@"Warning" Body:@"Your transection is cancelled." Delegate:self];
                }
            }
            [MBProgressHUD hideHUDForView:self.view animated:YES];
        }];
    }
}

#pragma mark - UIAlertViewDelegate methods

-(void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if(self.isEdit)
    {
        for (id controller in [self.navigationController viewControllers])
        {
            if ([controller isKindOfClass:[BookingHistoryViewController class]])
            {
                [self.navigationController popToViewController:controller animated:YES];
                break;
            }
        }
    }
    else
        
    {
        [self.navigationController popViewControllerAnimated:YES];
    }
}

-(void)changeBookingData:(NSDictionary *)bookingData
{
    [[ModelManager getInstance] addBooking:self.res_id ft_id:[bookingData valueForKey:@"ft_id"] change_bk:self.changeBookingFbID date:self.selectedDate WithCallback:^(NSError *err, id response) {
        [MBProgressHUD hideHUDForView:self.view animated:YES];
        if(response != nil)
        {
            NSString *responseBookedFacility = [[NSString alloc] initWithData:response encoding:NSUTF8StringEncoding];
            if([responseBookedFacility isEqualToString:@"0"])
                [Util invokeAlertMethod:@"Warning" Body:@"Your booking is not changed yet. Please try later." Delegate:self];
            else
                [Util invokeAlertMethod:@"Warning" Body:@"Your booking is changed successfully." Delegate:self];
            NSLog(@"response booked facility %@",responseBookedFacility);
        }
    }];
}


-(void)addBookingData:(NSDictionary *)bookingData
{
    [[ModelManager getInstance] addBooking:self.res_id ft_id:[bookingData valueForKey:@"ft_id"] change_bk:[NSNumber numberWithInt:0] date:self.selectedDate WithCallback:^(NSError *err, id response) {
        [MBProgressHUD hideHUDForView:self.view animated:YES];
        if(response != nil)
        {
            NSString *responseBookedFacility = [[NSString alloc] initWithData:response encoding:NSUTF8StringEncoding];
            if ([self.mode isEqualToString:@"1"]) {
                [PayPalMobile initializeWithClientIdsForEnvironments:@{PayPalEnvironmentProduction : self.liveURL, PayPalEnvironmentSandbox : @""}];}
            else{
                [PayPalMobile initializeWithClientIdsForEnvironments:@{PayPalEnvironmentProduction : @"", PayPalEnvironmentSandbox : self.sandBoxURL}];}
            [self configurePaypal];
            if([self.paymentType isEqualToString:@"2"])
            {
                bookingID = [NSNumber numberWithInt:[responseBookedFacility intValue]];
                PayPalPayment *payment = [[PayPalPayment alloc] init];
                //payment.amount =  [NSDecimalNumber decimalNumberWithString:@"5"];
                payment.amount =  [NSDecimalNumber decimalNumberWithString:[NSString stringWithFormat:@"%@",[bookingData valueForKey:@"amount"]]];
                PayPalPaymentDetails *paymentDetails = [PayPalPaymentDetails paymentDetailsWithSubtotal:payment.amount withShipping:nil withTax:nil];
                payment.paymentDetails = paymentDetails;
                payment.currencyCode = @"SGD";
                payment.shortDescription = @"Book Facility";
                payment.items = nil;
                self.payPalConfig.acceptCreditCards = YES;
                
                PayPalPaymentViewController *paymentViewController = [[PayPalPaymentViewController alloc] initWithPayment:payment configuration:self.payPalConfig delegate:self];
                
                [self presentViewController:paymentViewController animated:YES completion:nil];
            }
            else if([self.paymentType isEqualToString:@"3"])
            {
                arrResponse = [responseBookedFacility componentsSeparatedByString:@"||"];
                if (arrResponse.count == 1)
                {
                    [Util invokeAlertMethod:@"Success" Body:@"Your event booked successfully"  Delegate:self];
                }
                else
                {
                    if(arrResponse.count == 2 && [[arrResponse objectAtIndex:0] isEqualToString:@"pay_deposit"])
                        [Util invokeAlertMethod:@"Warning" Body:[NSString stringWithFormat:@"This slot has been only blocked for you due to Insufficient deposit. Please submit deposit cheque of %@ %@ now to management office to confirm your booking",self.userLogin.currency_code,[arrResponse objectAtIndex:1]]  Delegate:self];
                    else
                    {
                        if([[arrResponse objectAtIndex:2] isEqualToString:@"-1"])
                            [Util invokeAlertMethod:@"Warning" Body:[NSString stringWithFormat:@"This slot has been only blocked for you due to Insufficient deposit. Please submit deposit cheque of %@ %@ now to management office to confirm your booking",self.userLogin.currency_code,[arrResponse objectAtIndex:1]]  Delegate:self];
                        else
                            [Util invokeAlertMethod:@"Warning" Body:[NSString stringWithFormat:@"This slot has been only blocked for you due to Insufficient deposit. Please submit deposit cheque of %@ %@ within %@ day to management office to confirm your booking",self.userLogin.currency_code,[arrResponse objectAtIndex:1],[arrResponse objectAtIndex:2]]  Delegate:self];
                    }
                }
            }
            else
            {
                arrResponse = [responseBookedFacility componentsSeparatedByString:@"||"];
                bookingID = [NSNumber numberWithInt:[[arrResponse objectAtIndex:0] intValue]];
                PayPalPayment *payment = [[PayPalPayment alloc] init];
                payment.amount =  [NSDecimalNumber decimalNumberWithString:[NSString stringWithFormat:@"%@",[bookingData valueForKey:@"amount"]]];
                PayPalPaymentDetails *paymentDetails = [PayPalPaymentDetails paymentDetailsWithSubtotal:payment.amount withShipping:nil withTax:nil];
                payment.paymentDetails = paymentDetails;
                payment.currencyCode = @"SGD";
                payment.shortDescription = @"Book Facility";
                payment.items = nil;
                self.payPalConfig.acceptCreditCards = YES;
                
                PayPalPaymentViewController *paymentViewController = [[PayPalPaymentViewController alloc] initWithPayment:payment configuration:self.payPalConfig delegate:self];
                
                [self presentViewController:paymentViewController animated:YES completion:nil];
            }
            NSLog(@"response booked facility %@",responseBookedFacility);
        }
    }];
}


#pragma mark - UITableView Delegate
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    NSLog(@"booking data %@",self.marrBookingData);
    return [self.marrBookingData count];
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    BookingCell *cell = (BookingCell *)[tableView dequeueReusableCellWithIdentifier:@"BookingCell"];
    
    cell.lblTitle.text = [[self.marrBookingData objectAtIndex:indexPath.row] valueForKey:@"fc_name"];
    
    NSLog(@"marrbooking %@",self.marrBookingData);
    
    if([self.paymentType isEqualToString:@"2"])
    {
        cell.lblAmount.text = [NSString stringWithFormat:@"Fees : %@ %@",self.userLogin.currency_code,[[self.marrBookingData objectAtIndex:indexPath.row] valueForKey:@"amount"]];
    }
    else if([self.paymentType isEqualToString:@"3"])
    {
        cell.lblAmount.text = [NSString stringWithFormat:@"Deposit : %@ %@",self.userLogin.currency_code,[[self.marrBookingData objectAtIndex:indexPath.row] valueForKey:@"deposit_amount"]];
    }
    else
    {
        cell.lblAmount.text = [NSString stringWithFormat:@"Fees : %@%@ Deposit : %@%@",self.userLogin.currency_code,[[self.marrBookingData objectAtIndex:indexPath.row] valueForKey:@"amount"],self.userLogin.currency_code,[[self.marrBookingData objectAtIndex:indexPath.row] valueForKey:@"deposit_amount"]];
    }
    
    [Util setViewDesign:cell.btnBook BorderColor:[cell.btnBook backgroundColor] BorderWidth:1 CornerRadious:15];
    cell.btnBook.tag = indexPath.row;
    [cell.btnBook addTarget:self action:@selector(btnBookPress:) forControlEvents:UIControlEventTouchUpInside];
    NSLog(@"dataaa %@",[self.marrBookingData objectAtIndex:indexPath.row]);
    if ([[[self.marrBookingData objectAtIndex:indexPath.row] valueForKey:@"booked"] isEqualToString:@"Yes"])
    {
        [cell.btnBook setHidden:YES];
        [cell.lblBooked setText:@"Booked"];
    }
    else if ([[[self.marrBookingData objectAtIndex:indexPath.row] valueForKey:@"booked"] isEqualToString:@"No"])
        [cell.btnBook setHidden:NO];
    else
    {
        [cell.btnBook setHidden:YES];
        [cell.lblBooked setText:@"Blocked"];
    }
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    return cell;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
}



@end