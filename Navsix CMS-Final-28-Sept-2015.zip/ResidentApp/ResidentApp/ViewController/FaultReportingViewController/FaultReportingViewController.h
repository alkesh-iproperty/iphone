//
//  FaultReportingViewController.h
//  ResidentApp
//
//  Created by TheAppGuruz-New-6 on 07/07/15.
//  Copyright (c) 2015 TheAppGuruz-New-6. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SlidingViewController.h"

@interface FaultReportingViewController : SlidingViewController<UINavigationControllerDelegate,UIImagePickerControllerDelegate,UITextFieldDelegate,UITextViewDelegate>
{
    UIImagePickerController *imgPicker;
    UIImage *imagePhoto;
    NSMutableArray *marrPhoto;
}

@property (nonatomic, strong) IBOutlet UICollectionView *cvPhotos;
@property (nonatomic, strong) IBOutlet UIView *vwData;
@property (nonatomic, strong) IBOutlet UIImageView *ivFaultPhoto;
@property (nonatomic, strong) IBOutlet UITextField *txtTitle;
@property (nonatomic, strong) IBOutlet UITextView *tvDesc;
@property (nonatomic, strong) IBOutlet UIButton *btnSubmit;
@property (nonatomic, strong) IBOutlet UIButton *btnCancel;
@property (weak, nonatomic) IBOutlet UIScrollView *svDetail;

@end