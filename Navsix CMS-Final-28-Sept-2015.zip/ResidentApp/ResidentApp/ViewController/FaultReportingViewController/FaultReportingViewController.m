//
//  FaultReportingViewController.m
//  ResidentApp
//
//  Created by TheAppGuruz-New-6 on 07/07/15.
//  Copyright (c) 2015 TheAppGuruz-New-6. All rights reserved.
//

#import "FaultReportingViewController.h"
#import "GalleryCollectionViewCell.h"
#import "FaultPhoto.h"
#import "UIImageView+WebCache.h"
#import "GalleryItemDescriptionViewController.h"

#define Fault_Base_Url @"http://www.condomanagementsystem.com/upload/fault/"

@interface FaultReportingViewController ()

@end

@implementation FaultReportingViewController

#pragma mark - View LifeCycle Methods
- (void)viewDidLoad
{
    [super viewDidLoad];
    
    [Util setViewDesign:self.txtTitle BorderColor:[UIColor darkGrayColor] BorderWidth:1 CornerRadious:5];
    self.txtTitle.borderStyle = UITextBorderStyleRoundedRect;
    [Util setViewDesign:self.tvDesc BorderColor:[UIColor darkGrayColor] BorderWidth:1 CornerRadious:5];
    
    [Util setViewDesign:self.btnSubmit BorderColor:[self.btnSubmit backgroundColor] BorderWidth:1 CornerRadious:5];
    [Util setViewDesign:self.btnCancel BorderColor:[self.btnSubmit backgroundColor] BorderWidth:1 CornerRadious:5];
    
    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    [self performSelector:@selector(getFaultPhotoListData) withObject:nil afterDelay:0];
}

-(void)getFaultPhotoListData
{
    [[ModelManager getInstance] listFaultPhoto:self.userLogin.condo_id res_id:self.userLogin.res_id WithCallback:^(NSError *err, id response) {
        if (response != nil) {
            marrPhoto = [[NSMutableArray alloc] initWithArray:[NSJSONSerialization JSONObjectWithData:response options:0 error:nil]];
            for (int i = 0; i < [marrPhoto count]; i++) {
                FaultPhoto *faultPhoto = [[FaultPhoto alloc] init];
                [faultPhoto parseResponse:[marrPhoto objectAtIndex:i]];
                [marrPhoto replaceObjectAtIndex:i withObject:faultPhoto];
            }
            [self.cvPhotos reloadData];
        }
        [MBProgressHUD hideHUDForView:self.view animated:YES];
    }];
}

-(void)uploadFaultReportingPhoto
{
    [[ModelManager getInstance] addFault:self.userLogin.condo_id res_id:self.userLogin.res_id fault_name:self.txtTitle.text fault_desc:self.tvDesc.text UploadImage:imagePhoto WithCallback:^(NSError *err, id response) {
        if (response != nil) {
            if (![[[NSString alloc] initWithData:response encoding:NSUTF8StringEncoding] isEqualToString:@"0"]) {
                [Util invokeAlertMethod:nil Body:@"Fault added successfully." Delegate:self];
            } else {
                [Util invokeAlertMethod:nil Body:@"Failed to Add Fault. Please try again." Delegate:nil];
            }
        }
        self.ivFaultPhoto.image = nil;
        self.txtTitle.text = @"";
        self.tvDesc.text = @"";
        self.vwData.hidden = YES;
        [MBProgressHUD hideHUDForView:self.view animated:YES];
    }];
}

#pragma mark - UIAlertView Delegate Methods
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    [self performSelector:@selector(getFaultPhotoListData) withObject:nil afterDelay:0];
}

#pragma mark - UICollectionView delegate methods
-(UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    GalleryCollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"GalleryCell" forIndexPath:indexPath];
    
    FaultPhoto *faultPhoto = [marrPhoto objectAtIndex:indexPath.row];
    
    [cell.ivGallery sd_setImageWithURL:[NSURL URLWithString:[[NSString stringWithFormat:@"%@%@", Fault_Base_Url, faultPhoto.fault_photo] stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]] placeholderImage:[UIImage imageNamed:@""]];
    
    return cell;
}

-(NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    return [marrPhoto count];
}

-(void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
    UIStoryboard *storyBoard = [UIStoryboard storyboardWithName:@"Main" bundle:[NSBundle mainBundle]];
    GalleryItemDescriptionViewController *galleryItemDescriptionViewController = [storyBoard instantiateViewControllerWithIdentifier:@"GalleryItemDescriptionViewController"];
    galleryItemDescriptionViewController.userLogin = self.userLogin;
    galleryItemDescriptionViewController.marrGalleryItems = marrPhoto;
    galleryItemDescriptionViewController.selectedIndex = (int)indexPath.row;
    galleryItemDescriptionViewController.isFaultReporting = YES;
    [self.navigationController pushViewController:galleryItemDescriptionViewController animated:NO];
}

- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath
{
    return CGSizeMake(([[UIScreen mainScreen] bounds].size.width - 60) / 3, (([[UIScreen mainScreen] bounds].size.width - 60) / 3));
}

- (UIEdgeInsets)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout insetForSectionAtIndex:(NSInteger)section
{
    return UIEdgeInsetsMake(10, 10, 10, 10);
}

#pragma mark - Action Method
- (IBAction)btnTakePictureClicked:(id)sender
{
    if (!imgPicker) {
        imgPicker = [[UIImagePickerController alloc] init];
        [imgPicker setDelegate:self];
        imgPicker.sourceType = UIImagePickerControllerSourceTypeCamera;
    }
    if (![UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera]) {
        [Util invokeAlertMethod:nil Body:@"Device has no camera." Delegate:nil];
    } else {
        [self presentViewController:imgPicker animated:YES completion:nil];
    }
}

-(IBAction)btnSendUsPicturePress:(id)sender
{
//    imagePhoto = [UIImage imageNamed:@"Logo_Small.png"];
    if (imagePhoto) {
        self.ivFaultPhoto.image = imagePhoto;
        self.vwData.hidden = NO;
    } else {
        [Util invokeAlertMethod:nil Body:@"Please capture photo first." Delegate:nil];
    }
}

-(IBAction)btnBackPress:(id)sender
{
    [self.txtTitle resignFirstResponder];
    [self.tvDesc resignFirstResponder];
}

-(IBAction)btnSubmitPress:(id)sender
{
    if ([Util checkIsEmpty:self.txtTitle.text]) {
        [Util invokeAlertMethod:nil Body:@"Please enter title" Delegate:nil];
    } else if ([Util checkIsEmpty:self.tvDesc.text]) {
        [Util invokeAlertMethod:nil Body:@"Please enter description" Delegate:nil];
    } else {
        [MBProgressHUD showHUDAddedTo:self.view animated:YES];
        [self performSelector:@selector(uploadFaultReportingPhoto) withObject:nil afterDelay:0];
    }
}

-(IBAction)btnCancelPress:(id)sender
{
    self.vwData.hidden = YES;
}

#pragma mark - image Picker delegate
- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info
{
    imagePhoto = [info objectForKey:UIImagePickerControllerOriginalImage];
    imagePhoto = [Util rotateImage:imagePhoto byOrientationFlag:imagePhoto.imageOrientation];
    imagePhoto = [Util resizeImage:imagePhoto width:500 height:500];
    
    [picker dismissViewControllerAnimated:YES completion:NULL];
}

- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker
{
    [picker dismissViewControllerAnimated:YES completion:NULL];
}

#pragma mark - UITextField Delegate methods

-(BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    return YES;
}

- (void)textFieldDidBeginEditing:(UITextField *)textField
{
    [UIView animateWithDuration:0.5 animations:^{
        self.svDetail.contentOffset = CGPointMake(0,textField.frame.origin.y - 140);
    }];
}

-(void)textFieldDidEndEditing:(UITextField *)textField
{
    [UIView animateWithDuration:0.5 animations:^{
        self.svDetail.contentOffset = CGPointMake(0,0);
    }];
}

#pragma mark - UITextView delegate methods

-(void)textViewDidBeginEditing:(UITextView *)textView
{
    [UIView animateWithDuration:0.5 animations:^{
        self.svDetail.contentOffset = CGPointMake(0,textView.frame.origin.y - 80);
    }];
}

-(void)textViewDidEndEditing:(UITextView *)textView
{
    [UIView animateWithDuration:0.5 animations:^{
        self.svDetail.contentOffset = CGPointMake(0,0);
    }];
}
@end