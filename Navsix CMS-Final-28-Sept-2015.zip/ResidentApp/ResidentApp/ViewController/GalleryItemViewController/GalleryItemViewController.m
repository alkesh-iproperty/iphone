//
//  GalleryItemViewController.m
//  ResidentApp
//
//  Created by TheAppGuruz-iOS-103 on 08/07/15.
//  Copyright (c) 2015 TheAppGuruz-New-6. All rights reserved.
//

#import "GalleryItemViewController.h"
#import "GalleryItemCollectionViewCell.h"
#import "ModelManager.h"
#import "MBProgressHUD.h"
#import "GalleryItem.h"
#import "UIImageView+WebCache.h"
#import "Util.h"
#import "GalleryItemDescriptionViewController.h"

#define Image_Base_Url @"http://www.condomanagementsystem.com/upload/galleryitem/"

@interface GalleryItemViewController () <UICollectionViewDataSource, UICollectionViewDelegate>

@end

@implementation GalleryItemViewController

#pragma mark - View LifeCycle Methods
- (void)viewDidLoad
{
    [super viewDidLoad];
    
    [self loadGalleryItemData];
    
    //configure carousel
    self.carousel.type = iCarouselTypeCoverFlow;
    
    //scroll to fixed offset
    [self.carousel scrollToItemAtIndex:0 animated:NO];
    
    

}

#pragma mark - iCaroseal delegate methods

-(NSInteger)numberOfItemsInCarousel:(iCarousel *)carousel
{
    return marrGalleryItems.count;
}


-(UIView *)carousel:(iCarousel *)carousel viewForItemAtIndex:(NSInteger)index reusingView:(UIView *)view
{
    //create a numbered view
    GalleryItem *objGalleryItem = [marrGalleryItems objectAtIndex:index];
    view = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, 250.0f, 250.0f)];
    view.backgroundColor = [UIColor darkGrayColor];
    UIImageView *iv=[[UIImageView alloc]initWithFrame:CGRectMake(0, 0, 250.0f, 250.0f)];
    [iv sd_setImageWithURL:[NSURL URLWithString:[[NSString stringWithFormat:@"%@%@", Image_Base_Url, objGalleryItem.photo_name] stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]] placeholderImage:[UIImage imageNamed:@"imgNotFound.png"]];
    [view addSubview:iv];
    return view;
}

-(void)carousel:(iCarousel *)carousel didSelectItemAtIndex:(NSInteger)index
{
    UIStoryboard *storyBoard = [UIStoryboard storyboardWithName:@"Main" bundle:[NSBundle mainBundle]];
    GalleryItemDescriptionViewController *galleryItemDescriptionViewController = [storyBoard instantiateViewControllerWithIdentifier:@"GalleryItemDescriptionViewController"];
    galleryItemDescriptionViewController.userLogin = self.userLogin;
    galleryItemDescriptionViewController.marrGalleryItems = marrGalleryItems;
    galleryItemDescriptionViewController.selectedIndex = (int)index;
    [self.navigationController pushViewController:galleryItemDescriptionViewController animated:NO];
}

- (CGFloat)carousel:(iCarousel *)carousel valueForOption:(iCarouselOption)option withDefault:(CGFloat)value
{
    switch (option)
    {
        case iCarouselOptionWrap:
        {
            return YES;
        }
        default:
        {
            return value;
        }
    }
}

#pragma mark - Action Methods
- (IBAction)btnBackTapped:(id)sender
{
    [self.navigationController popViewControllerAnimated:NO];
}

-(void) loadGalleryItemData
{
    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    [[ModelManager getInstance] listGalleryItem:self.condo_id g_id:self.gallery.g_id WithCallback:^(NSError *err, id response) {
        if (response != nil) {
            marrGalleryItems = [[NSMutableArray alloc] initWithArray:[NSJSONSerialization JSONObjectWithData:response options:0 error:nil]];
            for (int i = 0; i < [marrGalleryItems count]; i++) {
                GalleryItem *objGalleryItem = [[GalleryItem alloc] init];
                [objGalleryItem parseResponse:[marrGalleryItems objectAtIndex:i]];
                [marrGalleryItems replaceObjectAtIndex:i withObject:objGalleryItem];
                [self.lblTitleName setText:objGalleryItem.name];
            }
            [self.carousel reloadData];
        }
        [MBProgressHUD hideHUDForView:self.view animated:YES];
    }];
}

@end