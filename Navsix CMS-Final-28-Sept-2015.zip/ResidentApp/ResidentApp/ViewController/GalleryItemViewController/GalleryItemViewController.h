//
//  GalleryItemViewController.h
//  ResidentApp
//
//  Created by TheAppGuruz-iOS-103 on 08/07/15.
//  Copyright (c) 2015 TheAppGuruz-New-6. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Gallery.h"
#import "SlidingViewController.h"
#import "iCarousel.h"

@interface GalleryItemViewController : SlidingViewController<iCarouselDataSource, iCarouselDelegate>
{
    NSMutableArray *marrGalleryItems;
}

@property (strong, nonatomic) IBOutlet UILabel *lblTitleName;
@property (strong, nonatomic) Gallery *gallery;
@property (strong, nonatomic) NSNumber *condo_id;
@property (nonatomic, strong) IBOutlet iCarousel *carousel;
@end
