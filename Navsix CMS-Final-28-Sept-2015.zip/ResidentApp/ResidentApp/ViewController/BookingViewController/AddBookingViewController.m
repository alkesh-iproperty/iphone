//
//  AddBookingViewController.m
//  ResidentApp
//
//  Created by TheAppGuruz on 08/07/15.
//  Copyright (c) 2015 TheAppGuruz-New-6. All rights reserved.
//

#import "AddBookingViewController.h"
#import "MBProgressHUD.h"
#import "ModelManager.h"

@interface AddBookingViewController ()

@end

@implementation AddBookingViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
}

-(void)getChildListData
{
//    [[ModelManager getInstance] listChildFacility:self.userLogin.condo_id res_id:self.userLogin.res_id fm_id:self.masterFacility.fm_id change_bk:self.masterFacility. date:<#(NSString *)#> WithCallback:<#^(NSError *err, id response)callback#>]
}

@end