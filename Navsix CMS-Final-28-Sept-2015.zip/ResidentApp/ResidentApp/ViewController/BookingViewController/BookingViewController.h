//
//  BookingViewController.h
//  ResidentApp
//
//  Created by TheAppGuruz-New-6 on 07/07/15.
//  Copyright (c) 2015 TheAppGuruz-New-6. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SlidingViewController.h"

@interface BookingViewController : SlidingViewController
{
    NSMutableArray *marrBooking;
    int selectedIndex;
}

@property (nonatomic, strong) IBOutlet UICollectionView *cvBooking;

@end