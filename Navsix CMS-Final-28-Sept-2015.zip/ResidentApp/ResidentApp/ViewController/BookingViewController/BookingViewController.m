//
//  BookingViewController.m
//  ResidentApp
//
//  Created by TheAppGuruz-New-6 on 07/07/15.
//  Copyright (c) 2015 TheAppGuruz-New-6. All rights reserved.
//

#import "BookingViewController.h"
#import "MBProgressHUD.h"
#import "ModelManager.h"
#import "MasterFacility.h"
#import "BookingCollectionViewCell.h"
#import "UIImageView+WebCache.h"
#import "AddBookingViewController.h"
#import "BookingHistoryViewController.h"


#define Image_Base_Url @"http://www.condomanagementsystem.com/upload/icons/"

@interface BookingViewController ()

@end

@implementation BookingViewController

#pragma mark - View LifeCycle Methods
- (void)viewDidLoad
{
    [super viewDidLoad];

    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    [self performSelector:@selector(getListMasterFacilityData) withObject:nil afterDelay:0];
}

-(void)getListMasterFacilityData
{
    [[ModelManager getInstance] listMasterFacility:self.userLogin.condo_id WithCallback:^(NSError *err, id response) {
        if (response != nil) {
            marrBooking = [[NSMutableArray alloc] initWithArray:[NSJSONSerialization JSONObjectWithData:response options:0 error:nil]];
            for (int i = 0; i < [marrBooking count]; i++) {
                MasterFacility *masterFacility = [[MasterFacility alloc] init];
                [masterFacility parseResponse:[marrBooking objectAtIndex:i]];
                [marrBooking replaceObjectAtIndex:i withObject:masterFacility];
            }
            [self.cvBooking reloadData];
        }
        [MBProgressHUD hideHUDForView:self.view animated:YES];
    }];
}

-(void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    if([segue.identifier isEqualToString:@"OpenAddBooking"])
    {
        AddBookingViewController *addBookingViewController = (AddBookingViewController *)[segue destinationViewController];
        addBookingViewController.masterFacility = [marrBooking objectAtIndex:selectedIndex];
        addBookingViewController.userLogin = self.userLogin;
    }
    else
    {
        BookingHistoryViewController *bookingHistoryViewController = (BookingHistoryViewController *)[segue destinationViewController];
        if ([segue.identifier isEqualToString:@"OpenUpComingBooking"]) {
            bookingHistoryViewController.strControllerName = @"Upcoming Booking";
        } else {
            bookingHistoryViewController.strControllerName = @"Previous Booking";
        }
        bookingHistoryViewController.userLogin = self.userLogin;
    }
}

#pragma mark - UICollectionView Datasource
- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
    selectedIndex = (int)indexPath.row;
    [self performSegueWithIdentifier:@"OpenAddBooking" sender:nil];
}

- (NSInteger)collectionView:(UICollectionView *)view numberOfItemsInSection:(NSInteger)section
{
    return [marrBooking count];
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)cv cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    BookingCollectionViewCell *cell = [cv dequeueReusableCellWithReuseIdentifier:@"BookingCell" forIndexPath:indexPath];
    
    MasterFacility *masterFacility = [marrBooking objectAtIndex:indexPath.row];
    
    cell.lblTitle.text = masterFacility.fm_name;
    [cell.ivIcon sd_setImageWithURL:[NSURL URLWithString:[[NSString stringWithFormat:@"%@%@", Image_Base_Url, masterFacility.icon_image] stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]] placeholderImage:[UIImage imageNamed:@"imgNotFound.png"]];
    
    return cell;
}

- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath
{
    return CGSizeMake((collectionView.bounds.size.width - 80) / 2, (collectionView.bounds.size.width - 80) / 2);
}

- (UIEdgeInsets)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout insetForSectionAtIndex:(NSInteger)section
{
    return UIEdgeInsetsMake(20, 20, 20, 20);
}

@end