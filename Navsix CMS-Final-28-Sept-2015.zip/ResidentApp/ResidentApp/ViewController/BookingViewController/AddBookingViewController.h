//
//  AddBookingViewController.h
//  ResidentApp
//
//  Created by TheAppGuruz on 08/07/15.
//  Copyright (c) 2015 TheAppGuruz-New-6. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SlidingViewController.h"
#import "MasterFacility.h"

@interface AddBookingViewController : SlidingViewController

@property (nonatomic, strong) IBOutlet UIImageView *ivIocn;
@property (nonatomic, strong) IBOutlet UIButton *btnDate;
@property (nonatomic, strong) IBOutlet UITableView *tbTimeSlot;
@property (nonatomic, strong) MasterFacility *masterFacility;
@property (weak, nonatomic) IBOutlet UILabel *lblMasterDescription;

@end
