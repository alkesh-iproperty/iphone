//
//  GalleryItemDescriptionViewController.m
//  ResidentApp
//
//  Created by TheAppGuruz-New-6 on 20/07/15.
//  Copyright (c) 2015 TheAppGuruz-New-6. All rights reserved.
//

#import "GalleryItemDescriptionViewController.h"
#import "UIImageView+WebCache.h"

#define Image_Base_Url @"http://www.condomanagementsystem.com/upload/galleryitem/"
#define Fault_Base_Url @"http://www.condomanagementsystem.com/upload/fault/"

@interface GalleryItemDescriptionViewController ()

@end

@implementation GalleryItemDescriptionViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

-(void)viewWillAppear:(BOOL)animated
{
    if(self.isFaultReporting)
    {
        [self.lblNavigation setText:[NSString stringWithFormat:@"Fault Reports %d/%lu",self.selectedIndex+1,(unsigned long)self.marrGalleryItems.count]];
    }
    else
    {
        [self.lblNavigation setText:[NSString stringWithFormat:@"%@ %d/%lu",[[self.marrGalleryItems objectAtIndex:self.selectedIndex] valueForKey:@"name"],self.selectedIndex+1,(unsigned long)self.marrGalleryItems.count]];
    }
}

- (void)viewDidLayoutSubviews
{
    [self.cvGalleryItem scrollToItemAtIndexPath:[NSIndexPath indexPathForItem:self.selectedIndex inSection:0] atScrollPosition:UICollectionViewScrollPositionCenteredHorizontally animated:NO];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    return [self.marrGalleryItems count];
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    GalleryItemCollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"GalleryItemCell" forIndexPath:indexPath];

    if(self.isFaultReporting)
    {
        [cell.ivIcon sd_setImageWithURL:[NSURL URLWithString:[[NSString stringWithFormat:@"%@%@", Fault_Base_Url, [[self.marrGalleryItems objectAtIndex:indexPath.row] valueForKey:@"fault_photo"]] stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]] placeholderImage:[UIImage imageNamed:@"imgNotFound.png"]];
    }
    else
    {
        [cell.ivIcon sd_setImageWithURL:[NSURL URLWithString:[[NSString stringWithFormat:@"%@%@", Image_Base_Url, [[self.marrGalleryItems objectAtIndex:indexPath.row] valueForKey:@"photo_name"]] stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]] placeholderImage:[UIImage imageNamed:@"imgNotFound.png"]];
    }
    return cell;
}

- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView
{
    for (UICollectionViewCell *cell in [self.cvGalleryItem visibleCells]) {
        NSIndexPath *indexPath = [self.cvGalleryItem indexPathForCell:cell];
        self.selectedIndex = (int)indexPath.row;
        if(self.isFaultReporting)
        {
            [self.lblNavigation setText:[NSString stringWithFormat:@"Fault Reports %d/%lu",self.selectedIndex+1,(unsigned long)self.marrGalleryItems.count]];
        }
        else
        {
            [self.lblNavigation setText:[NSString stringWithFormat:@"%@ %d/%lu",[[self.marrGalleryItems objectAtIndex:self.selectedIndex] valueForKey:@"name"],self.selectedIndex+1,(unsigned long)self.marrGalleryItems.count]];
        }
    }
}

- (CGSize)collectionView:(UICollectionView *)collectionView
                  layout:(UICollectionViewLayout*)collectionViewLayout
  sizeForItemAtIndexPath:(NSIndexPath *)indexPath
{
    return CGSizeMake([UIScreen mainScreen].bounds.size.width+10, self.cvGalleryItem.frame.size.height);
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

#pragma mark - UIButton Action method

- (IBAction)btnBackClicked:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}

@end
