//
//  GalleryItemDescriptionViewController.h
//  ResidentApp
//
//  Created by TheAppGuruz-New-6 on 20/07/15.
//  Copyright (c) 2015 TheAppGuruz-New-6. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "GalleryItemCollectionViewCell.h"
#import "GalleryItem.h"
#import "SlidingViewController.h"

@interface GalleryItemDescriptionViewController : SlidingViewController

@property (nonatomic,strong) NSMutableArray *marrGalleryItems;
@property BOOL isFaultReporting;
@property int selectedIndex;
@property (weak, nonatomic) IBOutlet UICollectionView *cvGalleryItem;
@property (weak, nonatomic) IBOutlet UILabel *lblNavigation;

@end
