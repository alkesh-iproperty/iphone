//
//  ReceiptViewController.h
//  ResidentApp
//
//  Created by TheAppGuruz-New-6 on 17/07/15.
//  Copyright (c) 2015 TheAppGuruz-New-6. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <AssetsLibrary/AssetsLibrary.h>
#import "SlidingViewController.h"

@interface ReceiptViewController : SlidingViewController    

@property (nonatomic, strong) NSString *strPayDate;
@property (nonatomic, strong) NSString *strPayAmount;
@property (nonatomic, strong) NSString *strTransactionID;
@property (nonatomic, strong) NSString *strResidentName;
@property (strong, atomic) ALAssetsLibrary *library;

@property (strong, nonatomic) IBOutlet UIView *vwReceipt;
@property (strong, nonatomic) IBOutlet UILabel *lblPayDate;
@property (strong, nonatomic) IBOutlet UILabel *lblPayAmount;
@property (strong, nonatomic) IBOutlet UILabel *lblTransactionID;
@property (strong, nonatomic) IBOutlet UILabel *lblResidentName;

@end
