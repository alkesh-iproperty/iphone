//
//  ReceiptViewController.m
//  ResidentApp
//
//  Created by TheAppGuruz-New-6 on 17/07/15.
//  Copyright (c) 2015 TheAppGuruz-New-6. All rights reserved.
//

#import "ReceiptViewController.h"
#import "MBProgressHUD.h"
#import "ALAssetsLibrary+CustomPhotoAlbum.h"
#import "Util.h"

@interface ReceiptViewController ()

@end

@implementation ReceiptViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    [self.lblResidentName setText:[NSString stringWithFormat:@"Name : %@",self.strResidentName]];
    [self.lblPayDate setText:[NSString stringWithFormat:@"Payment Date : %@",self.strPayDate]];
    [self.lblPayAmount setText:[NSString stringWithFormat:@"Amount : %@ %@",self.userLogin.currency_code,self.strPayAmount]];
    [self.lblTransactionID setText:[NSString stringWithFormat:@"%@",self.strTransactionID]];
    self.library = [[ALAssetsLibrary alloc] init];
}

- (IBAction)btnBackTapped:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}

- (IBAction)btnDownloadTapped:(id)sender
{
    [self downloadImage:[self imageWithView:self.vwReceipt]];
}

-(void)downloadImage:(UIImage *)image
{
    if (image == nil) {
        return;
    }
    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    dispatch_async(dispatch_get_main_queue(), ^{
        [self.library saveImage:image toAlbum:@"Navsix Maintenance" completion:^(NSURL *assetURL, NSError *error)
         {
             [Util invokeAlertMethod:@"Receipt Download" Body:@"Check your receipt in Navsix Maintenance album of your Gallary." Delegate:nil];
             [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
         } failure:^(NSError *error) {
             NSLog(@"Error : %@", [error localizedDescription]);
             [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
         }];
    });
    
}

- (UIImage *) imageWithView:(UIView *)view
{
    UIGraphicsBeginImageContextWithOptions(view.bounds.size, view.opaque, 0.0);
    [view.layer renderInContext:UIGraphicsGetCurrentContext()];
    
    UIImage * img = UIGraphicsGetImageFromCurrentImageContext();
    
    UIGraphicsEndImageContext();
    
    return img;
}


@end
