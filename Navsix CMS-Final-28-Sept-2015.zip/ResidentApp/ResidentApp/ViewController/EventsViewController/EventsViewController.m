//
//  EventsViewController.m
//  ResidentApp
//
//  Created by TheAppGuruz-New-6 on 07/07/15.
//  Copyright (c) 2015 TheAppGuruz-New-6. All rights reserved.
//

#import "EventsViewController.h"
#import "MBProgressHUD.h"
#import "ModelManager.h"
#import "Event.h"
#import "EventDetailViewController.h"
#import "EventCell.h"

@interface EventsViewController ()

@end

@implementation EventsViewController


#pragma mark - View LifeCycle Methods
- (void)viewDidLoad
{
    [super viewDidLoad];
}

-(void)viewWillAppear:(BOOL)animated
{
    intPageNo = 1;
    marrEvent = [[NSMutableArray alloc] init];
    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    [self performSelector:@selector(getEventData) withObject:nil afterDelay:0];
}

-(void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    EventDetailViewController *eventDetailViewController = (EventDetailViewController *)[segue destinationViewController];
    eventDetailViewController.event = [[marrEvent objectAtIndex:selectedSection] objectAtIndex:selectedIndex];
    eventDetailViewController.userLogin = self.userLogin;
}

-(void)getEventData
{
    [[ModelManager getInstance] listEvents:self.userLogin.condo_id res_id:self.userLogin.res_id pageNo:[NSNumber numberWithInt:intPageNo] WithCallback:^(NSError *err, id response) {
        if (response != nil) {
            
            if ([Util checkIsEmpty:[NSJSONSerialization JSONObjectWithData:response options:0 error:nil]]) {
                intPageNo = -1;
                return;
            }
            
            marrEventTemp = [[NSMutableArray alloc] initWithArray:[NSJSONSerialization JSONObjectWithData:response options:0 error:nil]];

            NSSortDescriptor *firstDescriptor = [[NSSortDescriptor alloc] initWithKey:@"start_time" ascending:NO];
            NSArray *sortDescriptors = [NSArray arrayWithObjects:firstDescriptor, nil];
            NSArray *sortedArray = [marrEventTemp sortedArrayUsingDescriptors:sortDescriptors];
            marrEventTemp = [[NSMutableArray alloc] initWithArray:sortedArray];
            
            for (int i = 0; i < [marrEventTemp count]; i++) {
                Event *event = [[Event alloc] init];
                [event parseResponse:[marrEventTemp objectAtIndex:i]];
                [marrEventTemp replaceObjectAtIndex:i withObject:event];
            }
            
            NSString *strExpDate = @"";
            NSMutableArray *marrAllEvent = [[NSMutableArray alloc] initWithArray:marrEventTemp];
            NSMutableArray *marrAddEvent = [[NSMutableArray alloc] init];
            
            [marrEventTemp removeAllObjects];
            
            for (int i = 0; i < [marrAllEvent count]; i++) {
                
                Event *event = [marrAllEvent objectAtIndex:i];
                if (i == 0) {
                    strExpDate = [event.start_time substringToIndex:7];
                }
                if ([strExpDate isEqualToString:[event.start_time substringToIndex:7]])
                {
                    [marrAddEvent addObject:event];
                    if (i == ([marrAllEvent count] - 1))
                    {
                        [marrEventTemp addObject:[NSMutableArray arrayWithArray:marrAddEvent]];
                        [marrAddEvent removeAllObjects];
                    }
                } else {
                    strExpDate = [event.start_time substringToIndex:7];
                    [marrEventTemp addObject:[NSMutableArray arrayWithArray:marrAddEvent]];
                    [marrAddEvent removeAllObjects];
                    [marrAddEvent addObject:event];
                    if (i == [marrAllEvent count]-1) {
                        [marrEventTemp addObject:[NSMutableArray arrayWithArray:marrAddEvent]];
                    }
                }
            }
            for(int i = 0 ;i < marrEventTemp.count ;i++)
            {
                [marrEvent addObject:[marrEventTemp objectAtIndex:i]] ;
            }
            [self.tbEvent reloadData];
        }
        [MBProgressHUD hideHUDForView:self.view animated:YES];
    }];
}

#pragma mark - UITableView Delegate Methods
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    if (tableView == self.tbEvent) {
        return [marrEvent count];
    }
    return 1;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if (tableView == self.tbEvent) {
        
        return [[marrEvent objectAtIndex:section] count];
    } else {
        return [super tableView:tableView numberOfRowsInSection:section];
    }
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    if (tableView == self.tbEvent) {
        Event *event = [[marrEvent objectAtIndex:section] objectAtIndex:0];
        
        UIView* customView = [[UIView alloc] initWithFrame:CGRectMake(-5, 0, tableView.frame.size.width + 10, 30)];
        [customView setBackgroundColor:[UIColor clearColor]];
        
        UILabel *lblBack = [[UILabel alloc] initWithFrame:CGRectMake(-5, 0, tableView.frame.size.width + 10, 30)];
        lblBack.backgroundColor = [UIColor whiteColor];
        lblBack.alpha = .5;
        [customView addSubview:lblBack];
        
        UILabel *lblTopLine = [[UILabel alloc] initWithFrame:CGRectMake(-5, 0, tableView.frame.size.width + 10, 1)];
        lblTopLine.backgroundColor = [UIColor colorWithRed:11.0f/255.0f
                                                     green:86.0f/255.0f
                                                      blue:145.0f/255.0f
                                                     alpha:1.0f];
        [customView addSubview:lblTopLine];
        
        UILabel *lblTitle = [[UILabel alloc] initWithFrame:CGRectMake(5, 0, tableView.frame.size.width - 10, 30)];
        lblTitle.backgroundColor = [UIColor clearColor];
        lblTitle.textColor = [UIColor darkGrayColor];
        [lblTitle setFont:[UIFont boldSystemFontOfSize:15]];
        lblTitle.text = [NSString stringWithFormat:@"Event on Month : %@", [event.start_time substringToIndex:7]];
        [customView addSubview:lblTitle];
        
        UILabel *lblBottomLine = [[UILabel alloc] initWithFrame:CGRectMake(-5, 29, tableView.frame.size.width + 10, 1)];
        lblBottomLine.backgroundColor = [UIColor colorWithRed:11.0f/255.0f
                                                        green:86.0f/255.0f
                                                         blue:145.0f/255.0f
                                                        alpha:1.0f];
        [customView addSubview:lblBottomLine];
        
        return customView;
    }
    UIView* customView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 230, 1)];
    customView.backgroundColor = [UIColor clearColor];
    return customView;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (tableView == self.tbEvent) {
        EventCell *cell = [tableView dequeueReusableCellWithIdentifier:@"EventCell"];
        
        Event *event = [[marrEvent objectAtIndex:indexPath.section] objectAtIndex:indexPath.row];
        
        cell.lblEventDescription.text = [NSString stringWithFormat:@"%@", event.event_name];
        cell.lblEventDate.text = event.start_time;
        
        if([event.event_type intValue] == 1)
           [cell.ivEventIcon setImage:[UIImage imageNamed:@"announcement.png"]];
        else
           [cell.ivEventIcon setImage:[UIImage imageNamed:@"invitation.png"]];
        
        if([event.read isEqualToString:@"1"])
            [cell setBackgroundColor:[UIColor colorWithRed:11.0f/255.0f
                                                     green:86.0f/255.0f
                                                      blue:145.0f/255.0f
                                                     alpha:0.3f]];
        else
            [cell setBackgroundColor:[UIColor clearColor]];
        return cell;
    } else {
        return [super tableView:tableView cellForRowAtIndexPath:indexPath];
    }
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (tableView == self.tbEvent) {
        selectedSection = (int)indexPath.section;
        selectedIndex = (int)indexPath.row;
        Event *event = [[marrEvent objectAtIndex:selectedSection] objectAtIndex:selectedIndex];
        [tableView deselectRowAtIndexPath:indexPath animated:YES];
        if([event.read isEqualToString:@"1"])
        {
            [MBProgressHUD showHUDAddedTo:self.view animated:YES];
            [[ModelManager getInstance] updateUnReadEvent:event.id WithCallback:^(NSError *err, id response) {
                if(response != nil)
                {
                    response = [[NSString alloc] initWithData:response encoding:NSUTF8StringEncoding];
                    if([response isEqualToString:@"1"])
                    {
                        int count = [[[NSUserDefaults standardUserDefaults] valueForKey:@"EventCount"] intValue] - 1;
                        [[NSUserDefaults standardUserDefaults] setValue:[NSString stringWithFormat:@"%d",count] forKey:@"EventCount"];
                        [self.tbList reloadData];
                        [self performSegueWithIdentifier:@"OpenEventDetailView" sender:nil];
                    }
                    else
                        [Util invokeAlertMethod:@"Warning" Body:@"There is a problem while loading. Please try again." Delegate:nil];
                }
                else
                    [Util invokeAlertMethod:@"Warning" Body:@"There is a problem while loading. Please try again." Delegate:nil];
                [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
            }];
        }
        else
        {
            [self performSegueWithIdentifier:@"OpenEventDetailView" sender:nil];
        }
    } else {
        [super tableView:tableView didSelectRowAtIndexPath:indexPath];
    }
}

- (void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath
{
    if(tableView == self.tbEvent){
    NSInteger sectionsAmount = [tableView numberOfSections];
    NSInteger rowsAmount = [tableView numberOfRowsInSection:[indexPath section]];
    if ([indexPath section] == sectionsAmount - 1 && [indexPath row] == rowsAmount - 1  && intPageNo > 0) {
        intPageNo++;
        [self performSelector:@selector(getEventData) withObject:nil afterDelay:0];
    }}
}

@end