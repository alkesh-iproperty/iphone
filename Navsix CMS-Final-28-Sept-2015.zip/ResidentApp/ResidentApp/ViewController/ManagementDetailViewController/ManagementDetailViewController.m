//
//  ManagementDetailViewController.m
//  ResidentApp
//
//  Created by TheAppGuruz-New-6 on 20/07/15.
//  Copyright (c) 2015 TheAppGuruz-New-6. All rights reserved.
//

#import "ManagementDetailViewController.h"
#import "UIImageView+WebCache.h"

#define Management_Base_Url @"http://www.condomanagementsystem.com/upload/management/"

@interface ManagementDetailViewController ()

@end

@implementation ManagementDetailViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    [self.lblName setText:[NSString stringWithFormat:@"Name : %@",self.management.name]];
    [self.lblDesignation setText:[NSString stringWithFormat:@"Designation : %@",self.management.designation]];
    [self.lblContactNumber setText:[NSString stringWithFormat:@"Contact : %@",self.management.mobile_number]];
    [self.lblDetail setText:[NSString stringWithFormat:@"Details : %@",self.management.description]];
    [self.ivPhoto sd_setImageWithURL:[NSURL URLWithString:[[NSString stringWithFormat:@"%@%@", Management_Base_Url, self.management.photo] stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]] placeholderImage:[UIImage imageNamed:@""]];
    
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/
- (IBAction)btnBackClicked:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}


- (IBAction)btnCallClicked:(id)sender
{
    if([[UIApplication sharedApplication] canOpenURL:[NSURL URLWithString:@"tel://"]])
    {
        [[UIApplication sharedApplication] openURL:[NSURL URLWithString:[NSString stringWithFormat:@"tel://%@", self.management.mobile_number]]];
    }
    else
    {
        [Util invokeAlertMethod:@"Warning" Body:@"Phone call is not supported in device." Delegate:self];
    }
}

@end
