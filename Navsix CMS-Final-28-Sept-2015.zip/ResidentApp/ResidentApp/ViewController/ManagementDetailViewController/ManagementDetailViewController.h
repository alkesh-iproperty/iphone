//
//  ManagementDetailViewController.h
//  ResidentApp
//
//  Created by TheAppGuruz-New-6 on 20/07/15.
//  Copyright (c) 2015 TheAppGuruz-New-6. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SlidingViewController.h"
#import "Management.h"

@interface ManagementDetailViewController : SlidingViewController
@property (weak, nonatomic) IBOutlet UIImageView *ivPhoto;
@property (weak, nonatomic) IBOutlet UILabel *lblName;
@property (weak, nonatomic) IBOutlet UILabel *lblDesignation;
@property (weak, nonatomic) IBOutlet UILabel *lblContactNumber;
@property (nonatomic,strong) Management *management;
@property (weak, nonatomic) IBOutlet UILabel *lblDetail;
@end
