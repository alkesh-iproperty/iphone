//
//  GalleryViewController.m
//  ResidentApp
//
//  Created by TheAppGuruz-New-6 on 07/07/15.
//  Copyright (c) 2015 TheAppGuruz-New-6. All rights reserved.
//

#import "GalleryViewController.h"
#import "GalleryCollectionViewCell.h"
#import "ModelManager.h"
#import "MBProgressHUD.h"
#import "Gallery.h"
#import "UIImageView+WebCache.h"
#import "GalleryItemViewController.h"

#define Image_Base_Url @"http://www.condomanagementsystem.com/upload/gallery/"

@interface GalleryViewController () <UICollectionViewDataSource, UICollectionViewDelegate>

@end

@implementation GalleryViewController

#pragma mark - View LifeCycle Methods
- (void)viewDidLoad
{
    [super viewDidLoad];
    
    intPageNumber = 1;
    marrGallery = [[NSMutableArray alloc] init];
    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    [self performSelector:@selector(getGalleryData) withObject:nil afterDelay:0];

}

-(void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    GalleryItemViewController *galleryItemViewController = (GalleryItemViewController *)[segue destinationViewController];
    galleryItemViewController.gallery = [marrGallery objectAtIndex:selectedIndex];
    galleryItemViewController.condo_id = self.userLogin.condo_id;
    galleryItemViewController.userLogin = self.userLogin;
}

#pragma mark - UICollectionView Delegate Methods
- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    return [marrGallery count];
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    GalleryCollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"GalleryCell" forIndexPath:indexPath];
    Gallery *objGallery = [marrGallery objectAtIndex:indexPath.row];
    [cell.lblName setText:objGallery.name];
    [cell.ivGallery sd_setImageWithURL:[NSURL URLWithString:[[NSString stringWithFormat:@"%@%@", Image_Base_Url, objGallery.photo] stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]] placeholderImage:[UIImage imageNamed:@"imgNotFound.png"]];
    [cell setAccessibilityLabel:[NSString stringWithFormat:@"%@", objGallery.g_id]];
    return cell;
}

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
    selectedIndex = (int)indexPath.row;
    Gallery *objGallery = [marrGallery objectAtIndex:indexPath.row];
    if([objGallery.read isEqualToString:@"1"])
    {
        [MBProgressHUD showHUDAddedTo:self.view animated:YES];
        [[ModelManager getInstance] updateUnReadGallery:objGallery.id WithCallback:^(NSError *err, id response) {
            if(response != nil)
            {
                response = [[NSString alloc] initWithData:response encoding:NSUTF8StringEncoding];
                if([response isEqualToString:@"1"])
                {
                    int count = [[[NSUserDefaults standardUserDefaults] valueForKey:@"GalleryCount"] intValue] - 1;
                    [[NSUserDefaults standardUserDefaults] setValue:[NSString stringWithFormat:@"%d",count] forKey:@"GalleryCount"];
                    [self.tbList reloadData];
                    [self performSegueWithIdentifier:@"OpenGalleryItems" sender:nil];
                }
                else
                    [Util invokeAlertMethod:@"Warning" Body:@"There is a problem while loading. Please try again." Delegate:nil];
            }
            else
                [Util invokeAlertMethod:@"Warning" Body:@"There is a problem while loading. Please try again." Delegate:nil];
            [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
        }];
    }
    else
    {
        [self performSegueWithIdentifier:@"OpenGalleryItems" sender:nil];
    }
}

- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath
{
    return CGSizeMake((collectionView.bounds.size.width - 80) / 2, (collectionView.bounds.size.width - 80) / 2);
}

- (UIEdgeInsets)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout insetForSectionAtIndex:(NSInteger)section
{
    return UIEdgeInsetsMake(20, 20, 20, 20);
}

-(void)collectionView:(UICollectionView *)collectionView willDisplayCell:(UICollectionViewCell *)cell forItemAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.item == marrGallery.count-1 && intPageNumber > 0) {
        intPageNumber++;
        [self performSelector:@selector(getGalleryData) withObject:nil afterDelay:0];
    }
}

-(void) getGalleryData
{
    [[ModelManager getInstance] listGallery:self.userLogin.condo_id res_id:self.userLogin.res_id pageNo:[NSNumber numberWithInt:intPageNumber] WithCallback:^(NSError *err, id response) {
        if (response != nil) {
            if ([Util checkIsEmpty:[NSJSONSerialization JSONObjectWithData:response options:0 error:nil]]) {
                intPageNumber = -1;
                return;
            }
            marrGalleryTemp = [[NSMutableArray alloc] initWithArray:[NSJSONSerialization JSONObjectWithData:response options:0 error:nil]];
            for (int i = 0; i < [marrGalleryTemp count]; i++) {
                Gallery *gallery = [[Gallery alloc] init];
                [gallery parseResponse:[marrGalleryTemp objectAtIndex:i]];
                [marrGalleryTemp replaceObjectAtIndex:i withObject:gallery];
            }
            for(int i = 0 ;i < marrGalleryTemp.count ;i++)
            {
                [marrGallery addObject:[marrGalleryTemp objectAtIndex:i]] ;
            }
            [self.cvGallery reloadData];
        }
        [MBProgressHUD hideHUDForView:self.view animated:YES];
    }];
}

@end