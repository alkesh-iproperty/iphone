//
//  MaintenanceViewController.h
//  ResidentApp
//
//  Created by TheAppGuruz-New-6 on 09/07/15.
//  Copyright (c) 2015 TheAppGuruz-New-6. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Ipay.h"
#import "IpayPayment.h"
#import "PayPalMobile.h"
#import "SlidingViewController.h"

@interface MaintenanceViewController : SlidingViewController <UIAlertViewDelegate, PayPalPaymentDelegate,PaymentResultDelegate>
{
    NSString *strTransactionID;
    NSMutableArray *marrHistory;
    Ipay *paymentsdk;
    UIView *paymentView;
    NSString *maintenanceAmount,*maintenancePenalty,*totalAmount,*payDate;
}

@property(nonatomic, strong, readwrite) NSString *environment;
@property(nonatomic, strong, readwrite) PayPalConfiguration *payPalConfig;
@property (strong, nonatomic) IBOutlet UIView *vwBody;
@property (weak, nonatomic) IBOutlet UILabel *lblPayment;
@property (strong, nonatomic) IBOutlet UIButton *btnPayPal;
@property (weak, nonatomic) IBOutlet UIView *vwHistory;
@property (weak, nonatomic) IBOutlet UIView *vwPayment;
@property (strong, nonatomic) IBOutlet UITableView *tblHistory;

@end
