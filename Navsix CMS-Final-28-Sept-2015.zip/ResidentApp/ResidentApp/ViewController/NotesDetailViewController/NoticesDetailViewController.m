//
//  NoticesDetailViewController.m
//  ResidentApp
//
//  Created by TheAppGuruz on 13/07/15.
//  Copyright (c) 2015 TheAppGuruz-New-6. All rights reserved.
//

#import "NoticesDetailViewController.h"
#import "MBProgressHUD.h"

@interface NoticesDetailViewController ()

@end

@implementation NoticesDetailViewController

#pragma mark - View LifeCycle Methods
- (void)viewDidLoad
{
    [super viewDidLoad];
    
    self.lblTitle.text = self.strTitle;
    
    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    [self performSelector:@selector(loadFileData) withObject:nil afterDelay:0];
}

-(void)loadFileData
{
    NSURL *fileUrl = [NSURL URLWithString:self.filePath];
    NSURLRequest *req = [[NSURLRequest alloc] initWithURL:fileUrl];
    [self.wbFileData loadRequest:req];
}

#pragma mark - Action Methods
-(IBAction)btnBackPress:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}

#pragma mark - Webview Delegate Methods
-(void)webViewDidFinishLoad:(UIWebView *)webView
{
    [MBProgressHUD hideHUDForView:self.view animated:YES];
}

-(void)webView:(UIWebView *)webView didFailLoadWithError:(NSError *)error
{
    [MBProgressHUD hideHUDForView:self.view animated:YES];
}

@end