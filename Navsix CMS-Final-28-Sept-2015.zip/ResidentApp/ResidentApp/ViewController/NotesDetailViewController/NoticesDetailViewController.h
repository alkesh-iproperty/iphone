//
//  NoticesDetailViewController.h
//  ResidentApp
//
//  Created by TheAppGuruz on 13/07/15.
//  Copyright (c) 2015 TheAppGuruz-New-6. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SlidingViewController.h"

@interface NoticesDetailViewController : SlidingViewController

@property (nonatomic, strong) IBOutlet UILabel *lblTitle;
@property (nonatomic, strong) IBOutlet UIWebView *wbFileData;
@property (nonatomic, strong) NSString *strTitle;
@property (nonatomic, strong) NSString *filePath;

@end
