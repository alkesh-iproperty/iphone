//
//  BookingHistoryViewController.m
//  ResidentApp
//
//  Created by TheAppGuruz-New-6 on 18/07/15.
//  Copyright (c) 2015 TheAppGuruz-New-6. All rights reserved.
//

#import "BookingHistoryViewController.h"
#import "MBProgressHUD.h"
#import "ModelManager.h"
#import "Booking.h"
#import "ProfileBookingCell.h"
#import "AddBookingViewController.h"

@interface BookingHistoryViewController ()

@end

@implementation BookingHistoryViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self.lblNavigationTitle setText:self.strControllerName];
}

-(void)viewWillAppear:(BOOL)animated
{
    intPageNumber = 1;
    marrBooking = [[NSMutableArray alloc] init];
    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    [self performSelector:@selector(getBookingHistoryData) withObject:nil afterDelay:0];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Web Service Methods

-(void)getBookingHistoryData
{
    NSNumber *numberForUpcoming;
    if ([self.strControllerName isEqualToString:@"Upcoming Booking"]) {
        numberForUpcoming = [NSNumber numberWithInt:1];
    } else {
        numberForUpcoming = [NSNumber numberWithInt:0];
    }
    
    [[ModelManager getInstance] listBookingForResident:self.userLogin.condo_id res_id:self.userLogin.res_id upcoming:numberForUpcoming pageNo:[NSNumber numberWithInt:intPageNumber] WithCallback:^(NSError *err, id response) {
        if (response != nil) {
            
            if ([Util checkIsEmpty:[NSJSONSerialization JSONObjectWithData:response options:0 error:nil]]) {
                intPageNumber = -1;
                return;
            }
            
            marrBookingTemp = [[NSMutableArray alloc] initWithArray:[[NSMutableArray alloc] initWithArray:[NSJSONSerialization JSONObjectWithData:response options:0 error:nil]]];

            
            NSSortDescriptor *firstDescriptor = [[NSSortDescriptor alloc] initWithKey:@"time_slot_start" ascending:NO];
            NSArray *sortDescriptors = [NSArray arrayWithObjects:firstDescriptor, nil];
            NSArray *sortedArray = [marrBookingTemp sortedArrayUsingDescriptors:sortDescriptors];
            marrBookingTemp = [[NSMutableArray alloc] initWithArray:sortedArray];
            
            for (int i = 0; i < [marrBookingTemp count]; i++) {
                Booking *booking = [[Booking alloc] init];
                [booking parseResponse:[marrBookingTemp objectAtIndex:i]];
                [marrBookingTemp replaceObjectAtIndex:i withObject:booking];
            }
            
            NSString *strExpDate = @"";
            NSMutableArray *marrAllBooking = [[NSMutableArray alloc] initWithArray:marrBookingTemp];
            NSMutableArray *marrAddBooking = [[NSMutableArray alloc] init];
            
            [marrBookingTemp removeAllObjects];
            
            for (int i = 0; i < [marrAllBooking count]; i++) {
                
                Booking *booking = [marrAllBooking objectAtIndex:i];
                if (i == 0) {
                    strExpDate = booking.time_slot_start;
                }
                NSLog(@"strexpdate %@ timeslot %@",strExpDate,booking.time_slot_start);
                
                if ([strExpDate isEqualToString:booking.time_slot_start])
                {
                    NSLog(@"iff i %d",i);
                    [marrAddBooking addObject:booking];
                    if (i == ([marrAllBooking count] - 1))
                    {
                        [marrBookingTemp addObject:[NSMutableArray arrayWithArray:marrAddBooking]];
                        [marrAddBooking removeAllObjects];
                    }
                } else {
                    NSLog(@"elsee i %d",i);
                    strExpDate = booking.time_slot_start;
                    [marrBookingTemp addObject:[NSMutableArray arrayWithArray:marrAddBooking]];
                    [marrAddBooking removeAllObjects];
                    [marrAddBooking addObject:booking];
                    if (i == [marrAllBooking count]-1) {
                        [marrBookingTemp addObject:[NSMutableArray arrayWithArray:marrAddBooking]];
                    }
                }
            }
            for(int i = 0 ;i < marrBookingTemp.count ;i++)
            {
                [marrBooking addObject:[marrBookingTemp objectAtIndex:i]] ;
            }
            [self.tbBooking reloadData];
        }
        [MBProgressHUD hideHUDForView:self.view animated:YES];
    }];
}

-(void)cancelBooking:(Booking *)booking
{
    [[ModelManager getInstance] cancelBooking:self.userLogin.res_id fb_id:booking.fb_id WithCallback:^(NSError *err, id response) {
        [MBProgressHUD hideHUDForView:self.view animated:YES];
        if (response != nil) {
            if ([[[NSString alloc] initWithData:response encoding:NSUTF8StringEncoding] isEqualToString:@"1"]) {
                [Util invokeAlertMethod:@"Warning" Body:@"Your booking cancelled successfully." Delegate:self];
            } else {
                [Util invokeAlertMethod:@"Warning" Body:@"Failed to cancel booking. Please try again." Delegate:nil];
            }
        }
    }];
}

#pragma mark - UIAlertView Delegate Methods
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if(alertView.tag == 10)
    {
        if(buttonIndex == 1)
        {
            [MBProgressHUD showHUDAddedTo:self.view animated:YES];
            [self performSelector:@selector(cancelBooking:) withObject:[[marrBooking objectAtIndex:btnCancel.tag] objectAtIndex:btnCancel.accessibilityLabel.intValue] afterDelay:0];
        }
    }
    else
    {
        intPageNumber = 1;
        marrBooking = [[NSMutableArray alloc] init];
        [MBProgressHUD showHUDAddedTo:self.view animated:YES];
        [self performSelector:@selector(getBookingHistoryData) withObject:nil afterDelay:0];
    }
}
- (IBAction)btnBackClicked:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}

-(void)btnCancelPress:(id)sender
{
    btnCancel = (UIButton *)sender;
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Warning" message:@"Do you really want to cancel this booking?" delegate:self cancelButtonTitle:@"Cancel" otherButtonTitles:@"Yes", nil];
    alert.tag = 10;
    [alert show];
}

-(void)btnChangePress:(id)sender
{
    btnChange = (UIButton *)sender;
    Booking *booking = [[marrBooking objectAtIndex:btnChange.tag] objectAtIndex:btnCancel.accessibilityLabel.intValue];
    UIStoryboard *storyBoard = [UIStoryboard storyboardWithName:@"Main" bundle:[NSBundle mainBundle]];
    AddBookingViewController *addBookingViewController = [storyBoard instantiateViewControllerWithIdentifier:@"AddBookingViewController"];
    addBookingViewController.isEdit = YES;
    addBookingViewController.userLogin = self.userLogin;
    addBookingViewController.changeBookingFmID = booking.fm_id;
    addBookingViewController.changeBookingFbID = booking.fb_id;
    addBookingViewController.changeBookingFmName = @"name";
    [self.navigationController pushViewController:addBookingViewController animated:YES];
    addBookingViewController = nil;
}


#pragma mark - UITableView Delegate
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    if (tableView == self.tbBooking) {
        return [marrBooking count];
    }
    return 1;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if (tableView == self.tbBooking) {
        return [[marrBooking objectAtIndex:section] count];
    } else {
        return [super tableView:tableView numberOfRowsInSection:section];
    }
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (tableView == self.tbBooking) {
        ProfileBookingCell *cell = [tableView dequeueReusableCellWithIdentifier:@"ProfileBookingCell"];
        
        Booking *booking = [[marrBooking objectAtIndex:indexPath.section] objectAtIndex:indexPath.row];
        
        cell.lblTitle.text = booking.fc_name;
        
        [Util setViewDesign:cell.btnCancel BorderColor:[cell.btnCancel backgroundColor] BorderWidth:1 CornerRadious:15];
        [Util setViewDesign:cell.btnChange BorderColor:[cell.btnCancel backgroundColor] BorderWidth:1 CornerRadious:15];
        if ([booking.is_cancel_or_change isEqualToString:@"Yes"]) {
            cell.btnChange.hidden = NO;
            cell.btnCancel.hidden = NO;
        } else {
            cell.btnChange.hidden = YES;
            cell.btnCancel.hidden = YES;
        }
        
        if (booking.booking_cancelled.intValue == 1) {
            cell.lblCanceled.hidden = NO;
            cell.btnChange.hidden = YES;
            cell.btnCancel.hidden = YES;
        } else {
            cell.lblCanceled.hidden = YES;
            cell.btnChange.hidden = NO;
            cell.btnCancel.hidden = NO;
            
        }
        
        cell.btnCancel.tag = indexPath.section;
        cell.btnCancel.accessibilityLabel = [NSString stringWithFormat:@"%ld", (long)indexPath.row];
        [cell.btnCancel addTarget:self action:@selector(btnCancelPress:) forControlEvents:UIControlEventTouchUpInside];
        
        cell.btnChange.tag = indexPath.section;
        cell.btnChange.accessibilityLabel = [NSString stringWithFormat:@"%ld", (long)indexPath.row];
        [cell.btnChange addTarget:self action:@selector(btnChangePress:) forControlEvents:UIControlEventTouchUpInside];
        
        if (![self.strControllerName isEqualToString:@"Upcoming Booking"]) {
            [cell.lblCanceled setHidden:YES];
            [cell.btnCancel setHidden:YES];
            [cell.btnChange setHidden:YES];
        }
        
        return cell;
    } else {
        return [super tableView:tableView cellForRowAtIndexPath:indexPath];
    }
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    if (tableView == self.tbBooking)
    {
        Booking *booking = [[marrBooking objectAtIndex:section] objectAtIndex:0];
        
        UIView* customView = [[UIView alloc] initWithFrame:CGRectMake(-5, 0, tableView.frame.size.width + 10, 30)];
        [customView setBackgroundColor:[UIColor clearColor]];
        
        UILabel *lblBack = [[UILabel alloc] initWithFrame:CGRectMake(-5, 0, tableView.frame.size.width + 10, 30)];
        lblBack.backgroundColor = [UIColor whiteColor];
        lblBack.alpha = .5;
        [customView addSubview:lblBack];
        
        UILabel *lblTopLine = [[UILabel alloc] initWithFrame:CGRectMake(-5, 0, tableView.frame.size.width + 10, 1)];
        lblTopLine.backgroundColor = [UIColor colorWithRed:11.0f/255.0f
                                                     green:86.0f/255.0f
                                                      blue:145.0f/255.0f
                                                     alpha:1.0f];
        [customView addSubview:lblTopLine];
        
        UILabel *lblTitle = [[UILabel alloc] initWithFrame:CGRectMake(5, 0, tableView.frame.size.width - 10, 30)];
        lblTitle.backgroundColor = [UIColor clearColor];
        lblTitle.textColor = [UIColor darkGrayColor];
        [lblTitle setFont:[UIFont boldSystemFontOfSize:15]];
        lblTitle.text = [NSString stringWithFormat:@"Facility Booked On : %@",booking.time_slot_start];
        [customView addSubview:lblTitle];
        
        UILabel *lblBottomLine = [[UILabel alloc] initWithFrame:CGRectMake(-5, 29, tableView.frame.size.width + 10, 1)];
        lblBottomLine.backgroundColor = [UIColor colorWithRed:11.0f/255.0f
                                                        green:86.0f/255.0f
                                                         blue:145.0f/255.0f
                                                        alpha:1.0f];
        [customView addSubview:lblBottomLine];
        
        return customView;
    }
    UIView* customView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 230, 1)];
    customView.backgroundColor = [UIColor clearColor];
    return customView;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (tableView == self.tbBooking) {
        Booking *booking = [[marrBooking objectAtIndex:indexPath.section] objectAtIndex:indexPath.row];
        NSLog(@"urrlll http://www.condomanagementsystem.com/facilitychild/listfts?ws=condo&condo_id=%@&res_id=%@&fm_id=%@&change_bk=%@&date=%@",self.userLogin.condo_id,self.userLogin.res_id,booking.fm_id,booking.fb_id,[[booking.datetime componentsSeparatedByString:@" "] objectAtIndex:0]);
        
    } else {
        [super tableView:tableView didSelectRowAtIndexPath:indexPath];
    }
}

- (void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath
{
    if(tableView == self.tbBooking){
    NSInteger sectionsAmount = [tableView numberOfSections];
    NSInteger rowsAmount = [tableView numberOfRowsInSection:[indexPath section]];
    if ([indexPath section] == sectionsAmount - 1 && [indexPath row] == rowsAmount - 1  && intPageNumber > 0) {
        intPageNumber++;
        [self performSelector:@selector(getBookingHistoryData) withObject:nil afterDelay:0];
    }}
    
    
//    NSInteger lastSectionIndex = [tableView numberOfSections] - 1;
//    NSInteger totalRow = [tableView numberOfRowsInSection:lastSectionIndex];
//    
//    if (indexPath.row == totalRow -1 && intPageNumber > 0) {
//        intPageNumber++;
//        [self performSelector:@selector(getBookingHistoryData) withObject:nil afterDelay:0];    }
    
//    NSInteger lastSectionIndex = [tableView numberOfSections] - 1;
//    
//    if (indexPath.section == lastSectionIndex-1 && intPageNumber > 0) {
//        intPageNumber++;
//        [self performSelector:@selector(getBookingHistoryData) withObject:nil afterDelay:0];
//    }
}

/*
 #pragma mark - Navigation
 
 // In a storyboard-based application, you will often want to do a little preparation before navigation
 - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
 // Get the new view controller using [segue destinationViewController].
 // Pass the selected object to the new view controller.
 }
 */

@end
