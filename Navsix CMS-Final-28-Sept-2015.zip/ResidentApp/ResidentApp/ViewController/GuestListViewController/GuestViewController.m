//
//  GuestViewController.m
//  ResidentApp
//
//  Created by TheAppGuruz-New-6 on 07/07/15.
//  Copyright (c) 2015 TheAppGuruz-New-6. All rights reserved.
//

#import "GuestViewController.h"
#import "ActionSheetDatePicker.h"
#import "MBProgressHUD.h"
#import "GuestListCell.h"

@interface GuestViewController ()

@end

@implementation GuestViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    [self.txtName setBorderStyle:UITextBorderStyleRoundedRect];
    [self.txtExpectedPeople setBorderStyle:UITextBorderStyleRoundedRect];
    [self.txtStartTime setBorderStyle:UITextBorderStyleRoundedRect];
    
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
#pragma mark - UIButton Action methods

- (IBAction)btnStartTimeClicked:(id)sender
{
    [ActionSheetDatePicker showPickerWithTitle:@"" datePickerMode:UIDatePickerModeDateAndTime selectedDate:[NSDate date] target:self action:@selector(dateWasSelected:element:) origin:sender MaximumDate:nil MinimumDate:[NSDate date]];
}

- (IBAction)btnSubmitClicked:(id)sender
{
    [self.txtName resignFirstResponder];
    [self.txtExpectedPeople resignFirstResponder];
    if(isEdit)
    {
        [[ModelManager getInstance] updateGuestListRequest:self.txtName.text no_of_guest:[NSNumber numberWithInt:[self.txtExpectedPeople.text intValue]] visiting_date:self.txtStartTime.text glr_id:guestListEdit.glr_id WithCallback:^(NSError *err, id response) {
            if (response != nil) {
                response = [[NSString alloc] initWithData:response encoding:NSUTF8StringEncoding];
                if([response isEqualToString:@"1"])
                    [self btnRecentRequestClicked:nil];
                else
                    [Util invokeAlertMethod:@"Warning" Body:@"Guest list editing failed. Try again." Delegate:nil];
                [self.btnAddRequest setHidden:NO];
                [self.btnRecentRequest setHidden:NO];
                [self.vwRecentRequest setHidden:NO];
                [self.vwAddRequest setHidden:YES];
                [self.btnCancel setHidden:YES];
                self.txtName.text =  @"";
                self.txtExpectedPeople.text = @"";
                self.txtStartTime.text = @"";
                isEdit = NO;
            }
        }];
    }
    else
    {
        [self addGuestListRequest];
    }
}

- (IBAction)btnAddRequestClicked:(id)sender
{
    [self.txtName resignFirstResponder];
    [self.txtExpectedPeople resignFirstResponder];
    
    [self.vwAddRequest setHidden:NO];
    [self.vwRecentRequest setHidden:YES];
}

- (IBAction)btnRecentRequestClicked:(id)sender
{
    [self.txtName resignFirstResponder];
    [self.txtExpectedPeople resignFirstResponder];
    
    marrRecentGuestList = [[NSMutableArray alloc] init];
    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    [self getRecentGuestListRequest];
}

- (IBAction)btnCancelClicked:(id)sender
{
    [self.txtName resignFirstResponder];
    [self.txtExpectedPeople resignFirstResponder];
    
    [self.btnAddRequest setHidden:NO];
    [self.btnRecentRequest setHidden:NO];
    [self.vwRecentRequest setHidden:NO];
    [self.vwAddRequest setHidden:YES];
    [self.btnCancel setHidden:YES];
    self.txtName.text =  @"";
    self.txtExpectedPeople.text = @"";
    self.txtStartTime.text = @"";
    isEdit = NO;
}

#pragma mark - UIActionSheetPicker Delegate Methods

-(void)dateWasSelected:(NSDate *)pickedDate element:(id)element
{
    [self.txtName resignFirstResponder];
    [self.txtExpectedPeople resignFirstResponder];
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    [formatter setDateFormat:@"yyyy-MM-dd HH:mm:ss"];
    selectedDate = [formatter stringFromDate:pickedDate];
    [self.txtStartTime setText:selectedDate];
}


#pragma mark - UITextField Delegate methods

-(BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    return YES;
}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    if(textField == self.txtExpectedPeople) {
        NSCharacterSet *nonNumberSet = [[NSCharacterSet decimalDigitCharacterSet] invertedSet];
        return ([string stringByTrimmingCharactersInSet:nonNumberSet].length > 0) || [string isEqualToString:@""];
    }
    return YES;
}

#pragma mark - WS methods

-(void)addGuestListRequest
{
    if([self.txtName.text isEqualToString:@""])
        [Util invokeAlertMethod:@"Warning" Body:@"Please enter name." Delegate:nil];
    else if ([self.txtExpectedPeople.text isEqualToString:@""] || [self.txtExpectedPeople.text isEqualToString:@"0"])
        [Util invokeAlertMethod:@"Warning" Body:@"Please enter expected number of people." Delegate:nil];
    else if ([self.txtStartTime.text isEqualToString:@""])
        [Util invokeAlertMethod:@"Warning" Body:@"Please enter start time." Delegate:nil];
    else
    {
        [MBProgressHUD showHUDAddedTo:self.view animated:YES];
        [[ModelManager getInstance] addGuestListRequest:self.userLogin.condo_id block_id:self.userLogin.block_id unit_id:self.userLogin.unit_id name:self.txtName.text no_of_guest:[NSNumber numberWithInt:[self.txtExpectedPeople.text intValue]] visiting_date:selectedDate WithCallback:^(NSError *err, id response) {
            if (response != nil) {
                response = [NSJSONSerialization JSONObjectWithData:response options:0 error:nil];
                if(response)
                {
                    [self.txtName setText:@""];
                    [self.txtExpectedPeople setText:@""];
                    [self.txtStartTime setText:@""];
                    [Util invokeAlertMethod:@"Success" Body:@"Your guest list request submitted successfully" Delegate:nil];
                }
                else
                    [Util invokeAlertMethod:@"Success" Body:@"Your guest list request failed. Try Again" Delegate:nil];
            }
            [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
        }];
    }

}

-(void)getRecentGuestListRequest
{
    [[ModelManager getInstance] recentListRequest:self.userLogin.condo_id block_id:self.userLogin.block_id unit_id:self.userLogin.unit_id WithCallback:^(NSError *err, id response) {
        if (response != nil) {
            marrRecentGuestList = [[NSMutableArray alloc] initWithArray:[NSJSONSerialization JSONObjectWithData:response options:0 error:nil]];
            for (int i = 0; i < [marrRecentGuestList count]; i++) {
                GuestList *guestList = [[GuestList alloc] init];
                [guestList parseResponse:[marrRecentGuestList objectAtIndex:i]];
                [marrRecentGuestList replaceObjectAtIndex:i withObject:guestList];
            }
            [self.tvRecentGuestList reloadData];
        }
        [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
        [self.vwAddRequest setHidden:YES];
        [self.vwRecentRequest setHidden:NO];
    }];

}

#pragma mark - UITableView Delegate Methods

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}


-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if (tableView == self.tvRecentGuestList) {
        return marrRecentGuestList.count;
    } else {
        return [super tableView:tableView numberOfRowsInSection:section];
    }
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (tableView == self.tvRecentGuestList) {
    GuestListCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
    GuestList *guestList = [marrRecentGuestList objectAtIndex:indexPath.row];
    cell.lblListName.text = guestList.name;
    cell.lblNoOfPeople.text = [NSString stringWithFormat:@"%@",guestList.no_of_guest];
    cell.lblDate.text = [NSString stringWithFormat:@"%@",guestList.visiting_date];
    [cell setSelectionStyle:UITableViewCellSelectionStyleNone];
        return cell; }
    else{
        return [super tableView:tableView cellForRowAtIndexPath:indexPath];
    }
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (tableView == self.tvRecentGuestList) {
    GuestList *guestList = [marrRecentGuestList objectAtIndex:indexPath.row];
    UIActionSheet *actionSheet = [[UIActionSheet alloc] initWithTitle:guestList.name delegate:self cancelButtonTitle:@"Cancel" destructiveButtonTitle:@"Delete" otherButtonTitles:@"Edit", nil];
    actionSheet.tag = indexPath.row;
        [actionSheet showInView:self.view];}
    else
    {
        [super tableView:tableView didSelectRowAtIndexPath:indexPath];
    }
}

#pragma mark - UIActionSheet delegate

-(void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex
{
    guestListEdit = [marrRecentGuestList objectAtIndex:actionSheet.tag];
    if(buttonIndex == 0)
    {
        [[ModelManager getInstance] deleteGuestListRequest:guestListEdit.glr_id WithCallback:^(NSError *err, id response) {
            if (response != nil) {
                response = [[NSString alloc] initWithData:response encoding:NSUTF8StringEncoding];
                if([response isEqualToString:@"1"])
                    [self btnRecentRequestClicked:nil];
                else
                    [Util invokeAlertMethod:@"Warning" Body:@"Guest list deleting failed. Try again." Delegate:nil];
            }
        }];
    }
    if(buttonIndex == 1)
    {
        [self.btnAddRequest setHidden:YES];
        [self.btnRecentRequest setHidden:YES];
        [self.vwRecentRequest setHidden:YES];
        [self.vwAddRequest setHidden:NO];
        [self.btnCancel setHidden:NO];
        self.txtName.text =  guestListEdit.name;
        self.txtExpectedPeople.text = [NSString stringWithFormat:@"%@",guestListEdit.no_of_guest];
        self.txtStartTime.text = [NSString stringWithFormat:@"%@",guestListEdit.datetime];
        isEdit = YES;
    }
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
