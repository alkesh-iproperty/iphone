//
//  GuestViewController.h
//  ResidentApp
//
//  Created by TheAppGuruz-New-6 on 07/07/15.
//  Copyright (c) 2015 TheAppGuruz-New-6. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SlidingViewController.h"
#import "GuestList.h"

@interface GuestViewController : SlidingViewController<UITextFieldDelegate,UIActionSheetDelegate>
{
    NSString *selectedDate;
    NSMutableArray *marrRecentGuestList;
    BOOL isEdit;
    GuestList *guestListEdit;
}
@property (weak, nonatomic) IBOutlet UIView *vwRecentRequest;
@property (weak, nonatomic) IBOutlet UIView *vwAddRequest;
@property (weak, nonatomic) IBOutlet UITextField *txtName;
@property (weak, nonatomic) IBOutlet UITextField *txtExpectedPeople;
@property (weak, nonatomic) IBOutlet UITextField *txtStartTime;
@property (weak, nonatomic) IBOutlet UITableView *tvRecentGuestList;
@property (weak, nonatomic) IBOutlet UIButton *btnAddRequest;
@property (weak, nonatomic) IBOutlet UIButton *btnRecentRequest;
@property (weak, nonatomic) IBOutlet UIButton *btnCancel;

@end
