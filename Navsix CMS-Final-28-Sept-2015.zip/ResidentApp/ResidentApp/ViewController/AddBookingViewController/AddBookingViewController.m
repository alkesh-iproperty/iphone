//
//  AddBookingViewController.m
//  ResidentApp
//
//  Created by TheAppGuruz on 08/07/15.
//  Copyright (c) 2015 TheAppGuruz-New-6. All rights reserved.
//

#import "AddBookingViewController.h"
#import "MBProgressHUD.h"
#import "ModelManager.h"
#import "ActionSheetDatePicker.h"
#import "UIImageView+WebCache.h"
#import "ConfirmBookingViewController.h"

#define Icon_Base_Url @"http://www.condomanagementsystem.com/upload/facility/"

@interface AddBookingViewController ()

@end

@implementation AddBookingViewController

#pragma mark - View LifeCycle Methods
- (void)viewDidLoad
{
    [super viewDidLoad];
    
    if(self.isEdit)
        self.lblTitle.text = self.changeBookingFmName;
    else
        self.lblTitle.text = self.masterFacility.fm_name;
    
    if([self.masterFacility.payment_type intValue] == 1)
       [self.lblFreeFacilityDescription setText:self.masterFacility.details];
    
}

-(void)viewWillAppear:(BOOL)animated
{
    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    if(selectedDate != nil)
        [self performSelector:@selector(getChildListData:) withObject:selectedDate afterDelay:0];
    else
        [self performSelector:@selector(getChildListData:) withObject:[NSDate date] afterDelay:0];
}

-(void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    [NSObject cancelPreviousPerformRequestsWithTarget:self];
}

-(void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    ConfirmBookingViewController *confirmBookingViewController = (ConfirmBookingViewController *)[segue destinationViewController];
    confirmBookingViewController.res_id = self.userLogin.res_id;
    confirmBookingViewController.titleLabel = [marrTimeSlot objectAtIndex:selectedIndex];
    confirmBookingViewController.paymentType = [NSString stringWithFormat:@"%@",self.masterFacility.payment_type];
    confirmBookingViewController.mode = [[[marrChildListData objectAtIndex:0] valueForKey:@"paypal"] valueForKey:@"mode"];
    confirmBookingViewController.liveURL = [[[marrChildListData objectAtIndex:0] valueForKey:@"paypal"] valueForKey:@"live_url"];
    confirmBookingViewController.sandBoxURL = [[[marrChildListData objectAtIndex:0] valueForKey:@"paypal"] valueForKey:@"sandbox_url"];
    confirmBookingViewController.marrBookingData = [NSMutableArray arrayWithArray:[[marrChildListData objectAtIndex:1] valueForKey:[marrTimeSlot objectAtIndex:selectedIndex]]];
    confirmBookingViewController.selectedDate = [self.btnDate titleForState:UIControlStateNormal];
    confirmBookingViewController.userLogin = self.userLogin;
    confirmBookingViewController.isEdit = self.isEdit;
    confirmBookingViewController.changeBookingFbID = self.changeBookingFbID;
    
}

-(void)changeImage
{
    [UIView animateWithDuration:2.0f
                          delay:0.0
                        options:UIViewAnimationOptionCurveEaseInOut
                     animations:^{
                         if(marrImage.count > 0)
                         {
                             [self.ivIocn sd_setImageWithURL:[NSURL URLWithString:[[NSString stringWithFormat:@"%@%@", Icon_Base_Url, [marrImage objectAtIndex:self.ivIocn.tag]] stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]] placeholderImage:[UIImage imageNamed:@"imgNotFound.png"]];
                         }
                     }
                     completion:^(BOOL finished) {
                         if ((self.ivIocn.tag + 1) == marrImage.count) {
                             self.ivIocn.tag = 0;
                         } else {
                             self.ivIocn.tag = self.ivIocn.tag + 1;
                         }
                         [self performSelector:@selector(changeImage) withObject:nil afterDelay:5];
                     }];
}


-(void)getChildListData:(NSDate *)date
{
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    [formatter setDateFormat:@"yyyy-MM-dd"];
    NSNumber *mastrFacilityID;
    if(self.isEdit){
        mastrFacilityID = self.changeBookingFmID; }
    else{
        mastrFacilityID = self.masterFacility.fm_id; }
//    [self.btnDate setTitle:[formatter stringFromDate:date] forState:UIControlStateNormal];
    
    [[ModelManager getInstance] listChildFacility:self.userLogin.condo_id res_id:self.userLogin.res_id fm_id:mastrFacilityID change_bk:[NSNumber numberWithInt:0] date:[formatter stringFromDate:date] WithCallback:^(NSError *err, id response) {
        if (response != nil) {
            NSLog(@"response of child facility %@ %@ %@",response,[[NSString alloc] initWithData:response encoding:NSUTF8StringEncoding],[NSJSONSerialization JSONObjectWithData:response options:0 error:nil]);
            if([[NSString stringWithFormat:@"%@",[[NSJSONSerialization JSONObjectWithData:response options:0 error:nil] objectAtIndex:0]] isEqualToString:@"0"])
            {
                [Util invokeAlertMethod:@"Warning" Body:@"Master Facility Not Found" Delegate:self];
            }
            else if([[NSString stringWithFormat:@"%@",[[NSJSONSerialization JSONObjectWithData:response options:0 error:nil] objectAtIndex:0]] isEqualToString:@"1"])
            {
                [Util invokeAlertMethod:@"Warning" Body:@"No child facility found for selected master Facility" Delegate:self];
            }
            else if([[NSString stringWithFormat:@"%@",[[NSJSONSerialization JSONObjectWithData:response options:0 error:nil] objectAtIndex:0]] isEqualToString:@"3"])
            {
                [Util invokeAlertMethod:@"Warning" Body:@"Your account has been blocked by management. Please contact them for more clarification." Delegate:self];
            }
            else if([[NSString stringWithFormat:@"%@",[[NSJSONSerialization JSONObjectWithData:response options:0 error:nil] objectAtIndex:0]] isEqualToString:@"4"])
            {
                [Util invokeAlertMethod:@"Warning" Body:@"You have exceeded your monthly booking quota." Delegate:self];
            }
            else
            {
                marrChildListData = [[NSMutableArray alloc] initWithArray:[NSJSONSerialization JSONObjectWithData:response options:0 error:nil]];
                advanceBookingPeriod = [[[NSJSONSerialization JSONObjectWithData:response options:0 error:nil] objectAtIndex:0] valueForKey:@"advance_book_period"];
                advanceBookingPeriod_start = [[[NSJSONSerialization JSONObjectWithData:response options:0 error:nil] objectAtIndex:0] valueForKey:@"advance_book_period_start"];
                if(selectedDate)
                    [self.btnDate setTitle:[formatter stringFromDate:date] forState:UIControlStateNormal];
                else
                    [self.btnDate setTitle:[formatter stringFromDate:[date dateByAddingTimeInterval:+[advanceBookingPeriod_start intValue]*24*60*60]] forState:UIControlStateNormal];
                marrImage = [[NSMutableArray alloc] initWithArray:[[marrChildListData objectAtIndex:0] valueForKey:@"images"]];
                if ([marrImage count] > 0) {
                    [self.ivIocn sd_setImageWithURL:[NSURL URLWithString:[[NSString stringWithFormat:@"%@%@", Icon_Base_Url, [marrImage objectAtIndex:self.ivIocn.tag]] stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]] placeholderImage:[UIImage imageNamed:@""]];
                    [self changeImage];
                }
                if (marrChildListData.count >= 2) {
                    if ([[marrChildListData objectAtIndex:1] isKindOfClass:[NSDictionary class]]) {
                        self.lblFreeFacility.hidden = YES;
                        self.lblSelecteDate.hidden = NO;
                        self.btnDate.hidden = NO;
                        self.tbTimeSlot.hidden = NO;
                        marrTimeSlot = [[NSMutableArray alloc] initWithArray:[[marrChildListData objectAtIndex:1] allKeys]];
                    } else {
                        self.lblFreeFacility.hidden = NO;
                        self.lblSelecteDate.hidden = YES;
                        self.btnDate.hidden = YES;
                        self.tbTimeSlot.hidden = YES;
                        self.lblFreeFacility.text = @"There is no need to book this facility. It is free.";
                    }
                }
                [self.tbTimeSlot reloadData];
            }
        }
        [MBProgressHUD hideHUDForView:self.view animated:YES];
    }];
}

#pragma mark - Action Methods
-(IBAction)btnBackPress:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}

-(IBAction)btnSelectDatePress:(id)sender
{
    NSDate *now = [NSDate date];
    NSDate *sevenDaysAfter = [now dateByAddingTimeInterval:+[advanceBookingPeriod intValue]*24*60*60 + [advanceBookingPeriod_start intValue]*24*60*60];
    NSDate *currentDate = [now dateByAddingTimeInterval:+[advanceBookingPeriod_start intValue]*24*60*60];
    [ActionSheetDatePicker showPickerWithTitle:@"" datePickerMode:UIDatePickerModeDate selectedDate:currentDate target:self action:@selector(dateWasSelected:element:) origin:sender MaximumDate:sevenDaysAfter MinimumDate:currentDate];
}

-(void)dateWasSelected:(NSDate *)pickedDate element:(id)element
{
    selectedDate = pickedDate;
    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    [self performSelector:@selector(getChildListData:) withObject:selectedDate afterDelay:0];
}

#pragma mark - UITableView Delegate
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [marrTimeSlot count];
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"TimeSlotCell"];
    
    cell.textLabel.text = [marrTimeSlot objectAtIndex:indexPath.row];
    [cell.textLabel setTextColor:[UIColor darkGrayColor]];
    [cell.textLabel setFont:[UIFont boldSystemFontOfSize:16]];
    return cell;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    selectedIndex = (int)indexPath.row;
    [self performSegueWithIdentifier:@"OpenConfirmBookingView" sender:nil];
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
}

#pragma mark - UIAlertViewDelegate methods

-(void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    [self.navigationController popViewControllerAnimated:YES];
}

@end