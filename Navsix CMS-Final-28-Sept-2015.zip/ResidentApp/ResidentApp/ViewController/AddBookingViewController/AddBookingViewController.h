//
//  AddBookingViewController.h
//  ResidentApp
//
//  Created by TheAppGuruz on 08/07/15.
//  Copyright (c) 2015 TheAppGuruz-New-6. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SlidingViewController.h"
#import "MasterFacility.h"

@interface AddBookingViewController : SlidingViewController<UIAlertViewDelegate>
{
    NSMutableArray *marrChildListData, *marrTimeSlot, *marrImage;
    int selectedIndex;
    NSString *advanceBookingPeriod,*advanceBookingPeriod_start;
    NSDate *selectedDate;
}

@property (nonatomic, strong) IBOutlet UILabel *lblTitle;
@property (nonatomic, strong) IBOutlet UIImageView *ivIocn;
@property (nonatomic, strong) IBOutlet UILabel *lblSelecteDate;
@property (nonatomic, strong) IBOutlet UIButton *btnDate;
@property (nonatomic, strong) IBOutlet UITableView *tbTimeSlot;
@property (nonatomic, strong) IBOutlet UILabel *lblFreeFacility;
@property (weak, nonatomic) IBOutlet UILabel *lblFreeFacilityDescription;
@property (nonatomic, strong) MasterFacility *masterFacility;
@property (nonatomic, strong) NSNumber *changeBookingFmID;
@property (nonatomic, strong) NSNumber *changeBookingFbID;
@property (nonatomic, strong) NSString *changeBookingDate;
@property (nonatomic, strong) NSString *changeBookingFmName;

@property BOOL isEdit;
@end
