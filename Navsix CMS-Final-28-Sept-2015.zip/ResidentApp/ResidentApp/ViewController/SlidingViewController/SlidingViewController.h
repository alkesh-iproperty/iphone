//
//  SlidingViewController.h
//  ResidentApp
//
//  Created by TheAppGuruz-New-6 on 07/07/15.
//  Copyright (c) 2015 TheAppGuruz-New-6. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MBProgressHUD.h"
#import "ModelManager.h"
#import "SliderCell.h"
#import "UserLogin.h"
#import "Util.h"
#import "TabConfigration.h"

@interface SlidingViewController : UIViewController<UITableViewDataSource,UITableViewDelegate>
{
    TabConfigration *tabList;
    NSMutableArray *marrTabList;
    UINavigationController *objNavigationController;
}

@property (weak, nonatomic) IBOutlet UIImageView *ivBackground;
@property (weak, nonatomic) IBOutlet UIView *vwSlider;
@property (weak, nonatomic) IBOutlet UIView *vwSliderNavigation;
@property (weak, nonatomic) IBOutlet UIView *vwSliderBody;
@property (weak, nonatomic) IBOutlet UITableView *tbList;
@property (nonatomic, strong) UserLogin *userLogin;
@property (nonatomic, assign) int selectedTabIndex;
@property (weak, nonatomic) IBOutlet UILabel *lblUpdateCount;
@end
