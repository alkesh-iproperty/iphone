//
//  SlidingViewController.m
//  ResidentApp
//
//  Created by TheAppGuruz-New-6 on 07/07/15.
//  Copyright (c) 2015 TheAppGuruz-New-6. All rights reserved.
//

#import "SlidingViewController.h"
#import "HomeScreenViewController.h"
#import "FaultReportingViewController.h"
#import "EventsViewController.h"
#import "NoticesViewController.h"
#import "GalleryViewController.h"

@interface SlidingViewController ()

@end

@implementation SlidingViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    if ([self.userLogin.slider_images count] > 0) {
        self.ivBackground.image = [UIImage imageWithContentsOfFile:[[FILEPATH_Documents stringByAppendingPathComponent:@"SliderImages"] stringByAppendingPathComponent:[self.userLogin.slider_images objectAtIndex:0]]];
        
        UIVisualEffect *blurEffect;
        blurEffect = [UIBlurEffect effectWithStyle:UIBlurEffectStyleLight];
        
        UIVisualEffectView *visualEffectView;
        visualEffectView = [[UIVisualEffectView alloc] initWithEffect:blurEffect];
        
        visualEffectView.frame = CGRectMake(0, 0, [[UIScreen mainScreen] bounds].size.width, [[UIScreen mainScreen] bounds].size.height);
        [self.view addSubview:visualEffectView];
        
        [self.view sendSubviewToBack:visualEffectView];
        [self.view sendSubviewToBack:self.ivBackground];
    }
    
    if([self isKindOfClass:[HomeScreenViewController class]])
    {
        self.selectedTabIndex = -1;
        [self getAllTabData];
    }
    
    UISwipeGestureRecognizer * swipeleft = [[UISwipeGestureRecognizer alloc]initWithTarget:self action:@selector(swipeleft:)];
    swipeleft.direction = UISwipeGestureRecognizerDirectionLeft;
    [self.vwSlider addGestureRecognizer:swipeleft];
    
    UIVisualEffect *blurEffect;
    blurEffect = [UIBlurEffect effectWithStyle:UIBlurEffectStyleLight];
    
    UIVisualEffectView *visualEffectView;
    visualEffectView = [[UIVisualEffectView alloc] initWithEffect:blurEffect];
    
    visualEffectView.frame = CGRectMake(0, 0,230,[[UIScreen mainScreen] bounds].size.height);
    [self.vwSlider addSubview:visualEffectView];
    [self.vwSlider bringSubviewToFront:self.vwSliderNavigation];
    [self.vwSlider bringSubviewToFront:self.vwSliderBody];
}

-(void)viewWillAppear:(BOOL)animated
{
    [self.tbList reloadData];
}

#pragma mark - UITableView Delegate
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [[[NSUserDefaults standardUserDefaults] objectForKey:@"TabList"] count];
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    SliderCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
    [cell.lblTabName setFont:[UIFont boldSystemFontOfSize:16]];
    [cell.lblTabName setText:[[[[NSUserDefaults standardUserDefaults] objectForKey:@"TabList"] objectAtIndex:indexPath.row] valueForKey:@"TitleName"]];
    
    if([[[[[NSUserDefaults standardUserDefaults] objectForKey:@"TabList"] objectAtIndex:indexPath.row] valueForKey:@"TitleName"] isEqualToString:@"Notices"])
    {
        if([[[NSUserDefaults standardUserDefaults] valueForKey:@"NoticeCount"] isEqualToString:@"0"])
            [cell.lblUpdates setHidden:YES];
        else
        {
            [cell.lblUpdates setText:[[NSUserDefaults standardUserDefaults] valueForKey:@"NoticeCount"]];
            [cell.lblUpdates setHidden:NO];
        }
    }
    else if([cell.lblTabName.text isEqualToString:@"Events"])
    {
        if([[[NSUserDefaults standardUserDefaults] valueForKey:@"EventCount"] isEqualToString:@"0"])
            [cell.lblUpdates setHidden:YES];
        else
        {
            [cell.lblUpdates setText:[[NSUserDefaults standardUserDefaults] valueForKey:@"EventCount"]];
            [cell.lblUpdates setHidden:NO];
        }
    }
    else if([cell.lblTabName.text isEqualToString:@"Gallery"])
    {
        if([[[NSUserDefaults standardUserDefaults] valueForKey:@"GalleryCount"] isEqualToString:@"0"])
            [cell.lblUpdates setHidden:YES];
        else
        {
            [cell.lblUpdates setText:[[NSUserDefaults standardUserDefaults] valueForKey:@"GalleryCount"]];
            [cell.lblUpdates setHidden:NO];
        }
    }
    else
    {
        [cell.lblUpdates setHidden:YES];
    }
    
    if(indexPath.row == 0)
    {
        if (self.selectedTabIndex == indexPath.row) {
            cell.lblTabName.textColor = [UIColor blackColor];
            [cell.ivTabImage setImage:[UIImage imageNamed:@"whiteBulletFirstSelected.png"]];
        } else {
            cell.lblTabName.textColor = [UIColor colorWithRed:11.0f/255.0f
                                                        green:86.0f/255.0f
                                                         blue:145.0f/255.0f
                                                        alpha:1.0f];
            [cell.ivTabImage setImage:[UIImage imageNamed:@"whiteBulletFirst.png"]];
        }
        
    }
    else if(indexPath.row == [[[NSUserDefaults standardUserDefaults] objectForKey:@"TabList"] count])
    {
        if (self.selectedTabIndex == indexPath.row) {
            cell.lblTabName.textColor = [UIColor blackColor];
            [cell.ivTabImage setImage:[UIImage imageNamed:@"whiteBulletLastSelected.png"]];
        } else {
            cell.lblTabName.textColor = [UIColor colorWithRed:11.0f/255.0f
                                                        green:86.0f/255.0f
                                                         blue:145.0f/255.0f
                                                        alpha:1.0f];
            [cell.ivTabImage setImage:[UIImage imageNamed:@"whiteBulletLast.png"]];
        }
        
    }
    else
    {
        if (self.selectedTabIndex == indexPath.row) {
            cell.lblTabName.textColor = [UIColor blackColor];
            [cell.ivTabImage setImage:[UIImage imageNamed:@"whiteBulletSelected.png"]];
        } else {
            cell.lblTabName.textColor = [UIColor colorWithRed:11.0f/255.0f
                                                        green:86.0f/255.0f
                                                         blue:145.0f/255.0f
                                                        alpha:1.0f];
            [cell.ivTabImage setImage:[UIImage imageNamed:@"whiteBullet.png"]];
        }
    }
    return cell;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    self.selectedTabIndex = (int)indexPath.row;
    UIStoryboard *storyBoard = [UIStoryboard storyboardWithName:@"Main" bundle:[NSBundle mainBundle]];
    SlidingViewController *viewController = [storyBoard instantiateViewControllerWithIdentifier:[[[[NSUserDefaults standardUserDefaults] objectForKey:@"TabList"] objectAtIndex:indexPath.row] valueForKey:@"ViewControllerName"]];
    viewController.userLogin = self.userLogin;
    viewController.selectedTabIndex = self.selectedTabIndex;
    [[NSUserDefaults standardUserDefaults] setValue:[[[[NSUserDefaults standardUserDefaults] objectForKey:@"TabList"] objectAtIndex:indexPath.row] valueForKey:@"ViewControllerName"] forKey:@"VisibleViewController"];
    if(![self isKindOfClass:[HomeScreenViewController class]])
    {
        objNavigationController = self.navigationController;
        [self.navigationController popViewControllerAnimated:NO];
        [self performSelector:@selector(pushViewControllerHere:) withObject:viewController afterDelay:0];
    }
    else
    {
        [self.navigationController pushViewController:viewController animated:YES];
    }
}

#pragma mark - Action methods
-(IBAction)btnLogoutPress:(id)sender
{
    [UIView animateWithDuration:0.5 delay:0.0 options: UIViewAnimationOptionCurveEaseOut animations:^{
        self.vwSlider.frame = CGRectMake(-230, 0, 230, self.vwSlider.frame.size.height); }completion:^(BOOL finished) {
            [self.vwSlider setHidden:YES];
            [[NSUserDefaults standardUserDefaults] setObject:nil forKey:@"UserLoginData"];
            [[NSUserDefaults standardUserDefaults] setObject:nil forKey:@"TabList"];
            [self.navigationController popToRootViewControllerAnimated:YES];
     }];
}

-(IBAction)btnHomePress:(id)sender
{
    for (id controller in [self.navigationController viewControllers])
    {
        if ([controller isKindOfClass:[HomeScreenViewController class]])
        {
            [self.navigationController popToViewController:controller animated:NO];
            break;
        }
    }

    [self.vwSlider setHidden:YES];
    
    [UIView animateWithDuration:0.5 delay:0.0 options: UIViewAnimationOptionCurveEaseOut animations:^{
        self.vwSlider.frame = CGRectMake(-230, 0, 230, self.vwSlider.frame.size.height); }completion:nil];
}


- (IBAction)btnSliderClicked:(id)sender
{
    if(self.vwSlider.hidden)
        [self.vwSlider setHidden:NO];
    [UIView animateWithDuration:0.5 delay:0.0 options: UIViewAnimationOptionCurveEaseOut animations:^{
        self.vwSlider.frame = CGRectMake(0, 0, 230, self.vwSlider.frame.size.height); }completion:nil];
}

#pragma mark - UIGesture Recogniser methods
-(void)swipeleft:(UISwipeGestureRecognizer*)gestureRecognizer
{
    [UIView animateWithDuration:0.5 delay:0.0 options: UIViewAnimationOptionCurveEaseOut animations:^{
        self.vwSlider.frame = CGRectMake(-230, 0, 230, self.vwSlider.frame.size.height); }completion:nil];
}

#pragma mark - WS Response Methods

-(void)getAllTabData
{
    marrTabList = [[NSMutableArray alloc] init];
    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    [[ModelManager getInstance] tabConfigration:self.userLogin.condo_id res_id:self.userLogin.res_id WithCallback:^(NSError *err, id response) {
        if (response != nil)
        {
            response = [NSJSONSerialization JSONObjectWithData:response options:0 error:nil];
            if (response)
            {
                tabList = [[TabConfigration alloc]init];
                [tabList parseResponse:response];
                NSLog(@"tab list facility %@",tabList.facility);
                
                if([[[tabList.facility componentsSeparatedByString:@"||"] objectAtIndex:0] intValue] == 1) {
                    if([tabList.facility componentsSeparatedByString:@"||"].count == 2)
                        [marrTabList addObject:[NSDictionary dictionaryWithObjectsAndKeys:@"Facility Booking", @"TitleName", @"BookingViewController", @"ViewControllerName",[[tabList.facility componentsSeparatedByString:@"||"] objectAtIndex:1],@"Updates" ,nil]];
                    else
                        [marrTabList addObject:[NSDictionary dictionaryWithObjectsAndKeys:@"Facility Booking", @"TitleName", @"BookingViewController", @"ViewControllerName",@"0",@"Updates" , nil]];
                }
                if([[[tabList.fault_reporting componentsSeparatedByString:@"||"] objectAtIndex:0] intValue] == 1) {
                    if([tabList.fault_reporting componentsSeparatedByString:@"||"].count == 2)
                        [marrTabList addObject:[NSDictionary dictionaryWithObjectsAndKeys:@"Fault Reporting", @"TitleName", @"FaultReportingViewController", @"ViewControllerName",[[tabList.fault_reporting componentsSeparatedByString:@"||"] objectAtIndex:1],@"Updates" , nil]];
                    else
                        [marrTabList addObject:[NSDictionary dictionaryWithObjectsAndKeys:@"Fault Reporting", @"TitleName", @"FaultReportingViewController", @"ViewControllerName",@"0",@"Updates", nil]];
                }
                if([[[tabList.emergency_no componentsSeparatedByString:@"||"] objectAtIndex:0] intValue] == 1) {
                    if([tabList.emergency_no componentsSeparatedByString:@"||"].count == 2)
                        [marrTabList addObject:[NSDictionary dictionaryWithObjectsAndKeys:@"Important Number", @"TitleName", @"ImportantNumberViewController", @"ViewControllerName",[[tabList.emergency_no componentsSeparatedByString:@"||"] objectAtIndex:1],@"Updates" , nil]];
                    else
                        [marrTabList addObject:[NSDictionary dictionaryWithObjectsAndKeys:@"Important Number", @"TitleName", @"ImportantNumberViewController", @"ViewControllerName",@"0",@"Updates", nil]];
                }
                if([[[tabList.notice componentsSeparatedByString:@"||"] objectAtIndex:0] intValue] == 1) {
                    if([tabList.notice componentsSeparatedByString:@"||"].count == 2)
                    {
                        [marrTabList addObject:[NSDictionary dictionaryWithObjectsAndKeys:@"Notices", @"TitleName", @"NoticesViewController", @"ViewControllerName",[[tabList.notice componentsSeparatedByString:@"||"] objectAtIndex:1],@"Updates" , nil]];
                        [[NSUserDefaults standardUserDefaults] setValue:[NSString stringWithFormat:@"%@",[[tabList.notice componentsSeparatedByString:@"||"] objectAtIndex:1]] forKey:@"NoticeCount"];
                        [[NSUserDefaults standardUserDefaults] synchronize];
                    }
                    else
                    {
                        [marrTabList addObject:[NSDictionary dictionaryWithObjectsAndKeys:@"Notices", @"TitleName", @"NoticesViewController", @"ViewControllerName",@"0",@"Updates", nil]];
                        [[NSUserDefaults standardUserDefaults] setValue:@"0" forKey:@"NoticeCount"];
                        [[NSUserDefaults standardUserDefaults] synchronize];
                    }
                }
                if([[[tabList.management componentsSeparatedByString:@"||"] objectAtIndex:0] intValue] == 1) {
                    if([tabList.management componentsSeparatedByString:@"||"].count == 2)
                        [marrTabList addObject:[NSDictionary dictionaryWithObjectsAndKeys:@"Management", @"TitleName", @"ManagementViewController", @"ViewControllerName",[[tabList.management componentsSeparatedByString:@"||"] objectAtIndex:1],@"Updates" , nil]];
                    else
                        [marrTabList addObject:[NSDictionary dictionaryWithObjectsAndKeys:@"Management", @"TitleName", @"ManagementViewController", @"ViewControllerName",@"0",@"Updates", nil]];
                }
                if([[[tabList.event componentsSeparatedByString:@"||"] objectAtIndex:0] intValue] == 1) {
                    if([tabList.event componentsSeparatedByString:@"||"].count == 2)
                    {
                        [marrTabList addObject:[NSDictionary dictionaryWithObjectsAndKeys:@"Events", @"TitleName", @"EventsViewController", @"ViewControllerName",[[tabList.event componentsSeparatedByString:@"||"] objectAtIndex:1],@"Updates" , nil]];
                        [[NSUserDefaults standardUserDefaults] setValue:[NSString stringWithFormat:@"%@",[[tabList.event componentsSeparatedByString:@"||"] objectAtIndex:1]] forKey:@"EventCount"];
                        [[NSUserDefaults standardUserDefaults] synchronize];
                    }
                    else
                    {
                        [marrTabList addObject:[NSDictionary dictionaryWithObjectsAndKeys:@"Events", @"TitleName", @"EventsViewController", @"ViewControllerName",@"0",@"Updates", nil]];
                        [[NSUserDefaults standardUserDefaults] setValue:@"0" forKey:@"EventCount"];
                        [[NSUserDefaults standardUserDefaults] synchronize];
                    }
                }
                if([[[tabList.gallery componentsSeparatedByString:@"||"] objectAtIndex:0] intValue] == 1) {
                    if([tabList.gallery componentsSeparatedByString:@"||"].count == 2)
                    {
                        [marrTabList addObject:[NSDictionary dictionaryWithObjectsAndKeys:@"Gallery", @"TitleName", @"GalleryViewController", @"ViewControllerName",[[tabList.gallery componentsSeparatedByString:@"||"] objectAtIndex:1],@"Updates" , nil]];
                        [[NSUserDefaults standardUserDefaults] setValue:[NSString stringWithFormat:@"%@",[[tabList.gallery componentsSeparatedByString:@"||"] objectAtIndex:1]] forKey:@"GalleryCount"];
                        [[NSUserDefaults standardUserDefaults] synchronize];
                    }
                    else
                    {
                        [marrTabList addObject:[NSDictionary dictionaryWithObjectsAndKeys:@"Gallery", @"TitleName", @"GalleryViewController", @"ViewControllerName",@"0",@"Updates", nil]];
                        [[NSUserDefaults standardUserDefaults] setValue:@"0" forKey:@"GalleryCount"];
                        [[NSUserDefaults standardUserDefaults] synchronize];
                    }
                }
                [marrTabList addObject:[NSDictionary dictionaryWithObjectsAndKeys:@"Payment", @"TitleName", @"PaymentViewController", @"ViewControllerName",@"0",@"Updates", nil]];
                if([[[tabList.website componentsSeparatedByString:@"||"] objectAtIndex:0] intValue] == 1) {
                    if([tabList.website componentsSeparatedByString:@"||"].count == 2)
                        [marrTabList addObject:[NSDictionary dictionaryWithObjectsAndKeys:@"Website", @"TitleName", @"WebsiteViewController", @"ViewControllerName",[[tabList.website componentsSeparatedByString:@"||"] objectAtIndex:1],@"Updates" , nil]];
                    else
                        [marrTabList addObject:[NSDictionary dictionaryWithObjectsAndKeys:@"Website", @"TitleName", @"WebsiteViewController", @"ViewControllerName",@"0",@"Updates", nil]];
                }
                if([[[tabList.guest_list_request componentsSeparatedByString:@"||"] objectAtIndex:0] intValue] == 1) {
                    if([tabList.guest_list_request componentsSeparatedByString:@"||"].count == 2)
                        [marrTabList addObject:[NSDictionary dictionaryWithObjectsAndKeys:@"Guest List Request", @"TitleName", @"GuestViewController", @"ViewControllerName",[[tabList.guest_list_request componentsSeparatedByString:@"||"] objectAtIndex:1],@"Updates" , nil]];
                    else
                        [marrTabList addObject:[NSDictionary dictionaryWithObjectsAndKeys:@"Guest List Request", @"TitleName", @"GuestViewController", @"ViewControllerName",@"0",@"Updates", nil]];
                }
                if([tabList.push_notification intValue] > 0) {
                    [[NSUserDefaults standardUserDefaults] setValue:tabList.push_notification forKey:@"NotificationCount"];
                    [[NSUserDefaults standardUserDefaults] synchronize];
                    [self.lblUpdateCount setText:[[NSUserDefaults standardUserDefaults] valueForKey:@"NotificationCount"]];
                    [self.lblUpdateCount setHidden:NO];
                }
                
                [marrTabList addObject:[NSDictionary dictionaryWithObjectsAndKeys:@"Profile", @"TitleName", @"ProfileViewController", @"ViewControllerName",@"0",@"Updates", nil]];
                
                NSLog(@"marr tab list %@",marrTabList);
                [[NSUserDefaults standardUserDefaults] setObject:marrTabList forKey:@"TabList"];
                [[NSUserDefaults standardUserDefaults] synchronize];
                
                if([[[tabList.maintenance componentsSeparatedByString:@"||"] objectAtIndex:0] intValue] == 1)
                    [[NSUserDefaults standardUserDefaults] setValue:@"1" forKey:@"Maintenance"];
                else
                    [[NSUserDefaults standardUserDefaults] setValue:@"0" forKey:@"Maintenance"];
                
                if([[[tabList.quit_rent componentsSeparatedByString:@"||"] objectAtIndex:0] intValue] == 1)
                    [[NSUserDefaults standardUserDefaults] setValue:@"1" forKey:@"Quit Rent"];
                else
                    [[NSUserDefaults standardUserDefaults] setValue:@"0" forKey:@"Quit Rent"];

                if([[[tabList.fire_insurance componentsSeparatedByString:@"||"] objectAtIndex:0] intValue] == 1)
                    [[NSUserDefaults standardUserDefaults] setValue:@"1" forKey:@"Fire Insurance"];
                else
                    [[NSUserDefaults standardUserDefaults] setValue:@"0" forKey:@"Fire Insurance"];

                if([[[tabList.sinking_fund componentsSeparatedByString:@"||"] objectAtIndex:0] intValue] == 1)
                    [[NSUserDefaults standardUserDefaults] setValue:@"1" forKey:@"Sinking Fund"];
                else
                    [[NSUserDefaults standardUserDefaults] setValue:@"0" forKey:@"Sinking Fund"];
                
                [self.tbList reloadData];
            }
            else
            {
                [Util invokeAlertMethod:nil Body:@"Tab configration failed.Please login again." Delegate:nil];
            }
        }
        [MBProgressHUD hideHUDForView:self.view animated:YES];
    }];
}

#pragma mark - Other methods
-(void)pushViewControllerHere :(SlidingViewController *)viewController
{
    [objNavigationController pushViewController:viewController animated:YES];
}

@end