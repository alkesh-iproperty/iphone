//
//  Gallery.m
//  ResidentApp
//
//  Created by TheAppGuruz on 07/07/15.
//  Copyright (c) 2015 TheAppGuruz-New-6. All rights reserved.
//

#import "Gallery.h"

@implementation Gallery

-(int)parseResponse:(NSDictionary *)dictionary
{
    self.id = [dictionary valueForKey:@"id"];
    self.g_id = [dictionary valueForKey:@"g_id"];
    self.name = [dictionary valueForKey:@"name"];
    self.photo = [dictionary valueForKey:@"photo"];
    self.read = [dictionary valueForKey:@"read"];
    self.datetime = [dictionary valueForKey:@"datetime"];
    
    return 0;
}

@end