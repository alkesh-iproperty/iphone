//
//  UpdateNotificaitonList.h
//  ResidentApp
//
//  Created by TheAppGuruz-iOS-103 on 21/07/15.
//  Copyright (c) 2015 TheAppGuruz-New-6. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface UpdateNotificaitonList : NSObject

@property (nonatomic, strong) NSNumber *not_id;
@property (nonatomic, strong) NSNumber *pn_id;
@property (nonatomic, strong) NSNumber *condo_id;
@property (nonatomic, strong) NSNumber *res_id;
@property (nonatomic, strong) NSString *datetime;
@property (nonatomic, strong) NSString *read;
@property (nonatomic, strong) NSString *message_title;
@property (nonatomic, strong) NSNumber *send_to;
@property (nonatomic, strong) NSNumber *content_type;
@property (nonatomic, strong) NSString *content_type_data;
@property (nonatomic, strong) NSString *send_on;

-(int)parseResponse:(NSDictionary *)dictionary;

@end
