//
//  MaintenanceAmount.h
//  ResidentApp
//
//  Created by TheAppGuruz on 07/07/15.
//  Copyright (c) 2015 TheAppGuruz-New-6. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MaintenanceAmount : NSObject

@property (nonatomic, strong) NSNumber *res_id;
@property (nonatomic, strong) NSNumber *condo_id;
@property (nonatomic, strong) NSString *first_name;
@property (nonatomic, strong) NSString *last_name;
@property (nonatomic, strong) NSString *maintance_amount;

-(int)parseResponse:(NSDictionary *)dictionary;

@end