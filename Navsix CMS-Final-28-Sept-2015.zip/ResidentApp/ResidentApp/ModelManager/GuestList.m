//
//  GuestList.m
//  ResidentApp
//
//  Created by TheAppGuruz-New-6 on 21/07/15.
//  Copyright (c) 2015 TheAppGuruz-New-6. All rights reserved.
//

#import "GuestList.h"

@implementation GuestList

-(int)parseResponse:(NSDictionary *)dictionary
{
    self.block_id = [dictionary valueForKey:@"block_id"];
    self.condo_id = [dictionary valueForKey:@"condo_id"];
    self.datetime = [dictionary valueForKey:@"datetime"];
    self.glr_id = [dictionary valueForKey:@"glr_id"];
    self.name = [dictionary valueForKey:@"name"];
    self.no_of_guest = [dictionary valueForKey:@"no_of_guest"];
    self.unit_id = [dictionary valueForKey:@"unit_id"];
    self.visiting_date = [dictionary valueForKey:@"visiting_date"];
    
    return 0;
}

@end
