//
//  GuestList.h
//  ResidentApp
//
//  Created by TheAppGuruz-New-6 on 21/07/15.
//  Copyright (c) 2015 TheAppGuruz-New-6. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface GuestList : NSObject

@property (nonatomic, strong) NSString *block_id;
@property (nonatomic, strong) NSNumber *condo_id;
@property (nonatomic, strong) NSString *datetime;
@property (nonatomic, strong) NSNumber *glr_id;
@property (nonatomic, strong) NSString *name;
@property (nonatomic, strong) NSNumber *no_of_guest;
@property (nonatomic, strong) NSString *unit_id;
@property (nonatomic, strong) NSString *visiting_date;

-(int)parseResponse:(NSDictionary *)dictionary;

@end
