//
//  TabPayment.h
//  ResidentApp
//
//  Created by TheAppGuruz on 07/07/15.
//  Copyright (c) 2015 TheAppGuruz-New-6. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface TabConfigration : NSObject

@property (nonatomic, strong) NSString *facility;
@property (nonatomic, strong) NSString *fault_reporting;
@property (nonatomic, strong) NSString *emergency_no;
@property (nonatomic, strong) NSString *notice;
@property (nonatomic, strong) NSString *management;
@property (nonatomic, strong) NSString *event;
@property (nonatomic, strong) NSString *gallery;
@property (nonatomic, strong) NSString *website;
@property (nonatomic, strong) NSString *guest_list_request;
@property (nonatomic, strong) NSString *maintenance;
@property (nonatomic, strong) NSString *push_notification;
@property (nonatomic, strong) NSString *quit_rent;
@property (nonatomic, strong) NSString *fire_insurance;
@property (nonatomic, strong) NSString *sinking_fund;

-(int)parseResponse:(NSDictionary *)dictionary;

@end