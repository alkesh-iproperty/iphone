//
//  Booking.m
//  ResidentApp
//
//  Created by TheAppGuruz on 08/07/15.
//  Copyright (c) 2015 TheAppGuruz-New-6. All rights reserved.
//

#import "Booking.h"

@implementation Booking

-(int)parseResponse:(NSDictionary *)dictionary
{
    self.amount = [dictionary valueForKey:@"amount"];
    self.approve = [dictionary valueForKey:@"approve"];
    self.booking_cancelled = [dictionary valueForKey:@"booking_cancelled"];
    self.booking_changed = [dictionary valueForKey:@"booking_changed"];
    self.datetime = [dictionary valueForKey:@"datetime"];
    self.fb_id = [dictionary valueForKey:@"fb_id"];
    self.fc_id = [dictionary valueForKey:@"fc_id"];
    self.fc_name = [dictionary valueForKey:@"fc_name"];
    self.fm_id = [dictionary valueForKey:@"fm_id"];
    self.insufficient_deposit = [dictionary valueForKey:@"insufficient_deposit"];
    self.is_cancel_or_change = [NSString stringWithFormat:@"%@", [dictionary valueForKey:@"is_cancel_or_change"]];
    self.payment_type = [dictionary valueForKey:@"payment_type"];
    self.res_id = [dictionary valueForKey:@"res_id"];
    self.status = [dictionary valueForKey:@"status"];
    self.time_slot_end = [dictionary valueForKey:@"time_slot_end"];
    self.time_slot_start = [dictionary valueForKey:@"time_slot_start"];
    self.transaction_status = [dictionary valueForKey:@"transaction_status"];
    
    return 0;
}

@end