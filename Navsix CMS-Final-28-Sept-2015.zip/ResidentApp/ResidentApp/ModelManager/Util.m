//
//  Util.m
//  ResidentApp
//
//  Created by TheAppGuruz-New-6 on 07/07/15.
//  Copyright (c) 2015 TheAppGuruz-New-6. All rights reserved.
//

#import "Util.h"
#import "KeystoneMapAnnotation.h"

@implementation Util

+(NSString *)myTrim:(NSString *) string { return [string stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]]; }

+(BOOL)checkIsEmpty:(NSString *)string
{
    if ([string isEqual:[NSNull null]]) return YES;
    string = [self myTrim:[NSString stringWithFormat:@"%@", string]];
    if([string isEqualToString:@"(null)"]) string = @"";
    return ([string isEqualToString:@""])?YES:NO;
}

+(void)invokeAlertMethod:(NSString *)strTitle Body:(NSString *)strBody Delegate:(id)delegate
{
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:strTitle
                                                    message:strBody
                                                   delegate:delegate
                                          cancelButtonTitle:@"OK"
                                          otherButtonTitles:nil];
    dispatch_async(dispatch_get_main_queue(),^{
        [alert show];
    });
    alert = nil;
}

+(UIImage*)rotateImage:(UIImage*)img byOrientationFlag:(UIImageOrientation)orient
{
    if (img.imageOrientation == UIImageOrientationUp) return img;
    
    // We need to calculate the proper transformation to make the image upright.
    // We do it in 2 steps: Rotate if Left/Right/Down, and then flip if Mirrored.
    CGAffineTransform transform = CGAffineTransformIdentity;
    
    switch (img.imageOrientation) {
        case UIImageOrientationDown:
        case UIImageOrientationDownMirrored:
            transform = CGAffineTransformTranslate(transform, img.size.width, img.size.height);
            transform = CGAffineTransformRotate(transform, M_PI);
            break;
            
        case UIImageOrientationLeft:
        case UIImageOrientationLeftMirrored:
            transform = CGAffineTransformTranslate(transform, img.size.width, 0);
            transform = CGAffineTransformRotate(transform, M_PI_2);
            break;
            
        case UIImageOrientationRight:
        case UIImageOrientationRightMirrored:
            transform = CGAffineTransformTranslate(transform, 0, img.size.height);
            transform = CGAffineTransformRotate(transform, -M_PI_2);
            break;
        case UIImageOrientationUp:
        case UIImageOrientationUpMirrored:
            break;
    }
    
    switch (img.imageOrientation) {
        case UIImageOrientationUpMirrored:
        case UIImageOrientationDownMirrored:
            transform = CGAffineTransformTranslate(transform, img.size.width, 0);
            transform = CGAffineTransformScale(transform, -1, 1);
            break;
            
        case UIImageOrientationLeftMirrored:
        case UIImageOrientationRightMirrored:
            transform = CGAffineTransformTranslate(transform, img.size.height, 0);
            transform = CGAffineTransformScale(transform, -1, 1);
            break;
        case UIImageOrientationUp:
        case UIImageOrientationDown:
        case UIImageOrientationLeft:
        case UIImageOrientationRight:
            break;
    }
    
    // Now we draw the underlying CGImage into a new context, applying the transform
    // calculated above.
    CGContextRef ctx = CGBitmapContextCreate(NULL, img.size.width, img.size.height,
                                             CGImageGetBitsPerComponent(img.CGImage), 0,
                                             CGImageGetColorSpace(img.CGImage),
                                             CGImageGetBitmapInfo(img.CGImage));
    CGContextConcatCTM(ctx, transform);
    switch (img.imageOrientation) {
        case UIImageOrientationLeft:
        case UIImageOrientationLeftMirrored:
        case UIImageOrientationRight:
        case UIImageOrientationRightMirrored:
            // Grr...
            CGContextDrawImage(ctx, CGRectMake(0,0,img.size.height,img.size.width), img.CGImage);
            break;
            
        default:
            CGContextDrawImage(ctx, CGRectMake(0,0,img.size.width,img.size.height), img.CGImage);
            break;
    }
    
    // And now we just create a new UIImage from the drawing context
    CGImageRef cgimg = CGBitmapContextCreateImage(ctx);
    UIImage *imgCopy = [UIImage imageWithCGImage:cgimg];
    CGContextRelease(ctx);
    CGImageRelease(cgimg);
    
    return imgCopy;
}

+(UIImage *)resizeImage:(UIImage *)anImage width:(int)widthI height:(int)heightI
{
    int w = anImage.size.width;
    
    int h = anImage.size.height;
    
    CGImageRef imageRef = [anImage CGImage];
    
    int width, height;
    
    int destWidth = widthI;
    
    int destHeight = heightI;
    
    if(w > h){
        width = destWidth;
        height = h*destWidth/w;
    } else {
        height = destHeight;
        width = w*destHeight/h;
    }
    
    CGColorSpaceRef colorSpace = CGColorSpaceCreateDeviceRGB();
    
    CGContextRef bitmap = CGBitmapContextCreate(NULL, width, height, 8, 4 * width, colorSpace, kCGImageAlphaPremultipliedFirst);
    
    if (anImage.imageOrientation == UIImageOrientationLeft) {
        CGContextRotateCTM (bitmap, M_PI/2);
        CGContextTranslateCTM (bitmap, 0, -height);
    } else if (anImage.imageOrientation == UIImageOrientationRight) {
        CGContextRotateCTM (bitmap, -M_PI/2);
        CGContextTranslateCTM (bitmap, -width, 0);
    } else if (anImage.imageOrientation == UIImageOrientationUp) {
        
    } else if (anImage.imageOrientation == UIImageOrientationDown) { 
        CGContextTranslateCTM (bitmap, width,height);
        CGContextRotateCTM (bitmap, -M_PI);
    }
    
    CGContextDrawImage(bitmap, CGRectMake(0, 0, width, height), imageRef);
    
    CGImageRef ref = CGBitmapContextCreateImage(bitmap);
    
    UIImage *result = [UIImage imageWithCGImage:ref];
    
    CGContextRelease(bitmap);
    
    CGImageRelease(ref);
    
    CGColorSpaceRelease(colorSpace);
    
    return result;
}

static CGFloat DegreesToRadians(CGFloat ftDegree)
{
    return ftDegree * M_PI / 180;
};

+ (UIImage *)rotateImage:(UIImage *)imgRotate byDegree:(CGFloat)ftDegree;
{
    UIView *vwRotateViewBox = [[UIView alloc] initWithFrame:CGRectMake(0, 0, imgRotate.size.width, imgRotate.size.height)];
    CGAffineTransform affineTransform = CGAffineTransformMakeRotation(DegreesToRadians(ftDegree));
    vwRotateViewBox.transform = affineTransform;
    CGSize sizeRotate = vwRotateViewBox.frame.size;
    
    UIGraphicsBeginImageContext(sizeRotate);
    CGContextRef bitmap = UIGraphicsGetCurrentContext();
    
    CGContextTranslateCTM(bitmap, sizeRotate.width/2, sizeRotate.height/2);
    
    CGContextRotateCTM(bitmap, DegreesToRadians(ftDegree));
    
    CGContextScaleCTM(bitmap, 1.0, -1.0);
    CGContextDrawImage(bitmap, CGRectMake(-imgRotate.size.width / 2, -imgRotate.size.height / 2, imgRotate.size.width, imgRotate.size.height), [imgRotate CGImage]);
    
    UIImage *imgNew = UIGraphicsGetImageFromCurrentImageContext();
    UIGraphicsEndImageContext();
    UIImageWriteToSavedPhotosAlbum(imgNew, nil, nil, nil);
    
    return imgNew;
}

+(void)setViewDesign:(UIView *)vwCurrent BorderColor:(UIColor *)borderColor BorderWidth:(int)width CornerRadious:(float)cornerRadious
{
    vwCurrent.layer.borderColor = [borderColor CGColor];
    vwCurrent.layer.borderWidth = width;
    vwCurrent.layer.cornerRadius = cornerRadious;
}

+ (void)zoomToFitMapAnnotations:(MKMapView *)mapView
{
    if([mapView.annotations count] == 0)
        return;
    
    CLLocationCoordinate2D topLeftCoord;
    topLeftCoord.latitude = -90;
    topLeftCoord.longitude = 180;
    
    CLLocationCoordinate2D bottomRightCoord;
    bottomRightCoord.latitude = 90;
    bottomRightCoord.longitude = -180;
    
    for(KeystoneMapAnnotation* annotation in mapView.annotations)
    {
        topLeftCoord.longitude = fmin(topLeftCoord.longitude, annotation.coordinate.longitude);
        topLeftCoord.latitude = fmax(topLeftCoord.latitude, annotation.coordinate.latitude);
        
        bottomRightCoord.longitude = fmax(bottomRightCoord.longitude, annotation.coordinate.longitude);
        bottomRightCoord.latitude = fmin(bottomRightCoord.latitude, annotation.coordinate.latitude);
    }
    
    MKCoordinateRegion region;
    region.center.latitude = topLeftCoord.latitude - (topLeftCoord.latitude - bottomRightCoord.latitude) * 0.5;
    region.center.longitude = topLeftCoord.longitude + (bottomRightCoord.longitude - topLeftCoord.longitude) * 0.5;
    
    if([mapView.annotations count] == 1) {
        region.span.latitudeDelta = topLeftCoord.latitude/2000; // Add a little extra space on the sides
        region.span.longitudeDelta = bottomRightCoord.longitude/2000; // Add a little extra space on the sides
    } else {
        region.span.latitudeDelta = fabs(topLeftCoord.latitude - bottomRightCoord.latitude) * 2.5;
        region.span.longitudeDelta = fabs(bottomRightCoord.longitude - topLeftCoord.longitude) * 2.5;
    }
    if (region.span.longitudeDelta < 0) {
        region.span.longitudeDelta = 0.01;
    }
    region = [mapView regionThatFits:region];
    [mapView setRegion:region animated:YES];
}


@end