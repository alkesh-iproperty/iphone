//
//  Website.m
//  ResidentApp
//
//  Created by TheAppGuruz on 07/07/15.
//  Copyright (c) 2015 TheAppGuruz-New-6. All rights reserved.
//

#import "Website.h"

@implementation Website

-(int)parseResponse:(NSDictionary *)dictionary
{
    self.web_id = [dictionary valueForKey:@"web_id"];
    self.condo_id = [dictionary valueForKey:@"condo_id"];
    self.website = [dictionary valueForKey:@"website"];
    
    return 0;
}

@end