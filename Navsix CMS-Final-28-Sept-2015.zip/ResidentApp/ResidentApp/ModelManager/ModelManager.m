//
//  ModelManager.m
//  ResidentApp
//
//  Created by TheAppGuruz-New-6 on 07/07/15.
//  Copyright (c) 2015 TheAppGuruz-New-6. All rights reserved.
//

#import "ModelManager.h"
#import "AFHTTPRequestOperationManager.h"

#define Base_Url @"http://www.condomanagementsystem.com/"

@implementation ModelManager

static ModelManager *instance = nil;

+ (ModelManager *)getInstance
{
    if(!instance) {
        instance = [[ModelManager alloc] init];
    }
    return instance;
}

- (void)makeRequestToURL:(NSString*)urlString
          withParameters:(NSDictionary*)params
               andMethod:(NSString*)method
             andCallback:(callbackBlock)callback
{
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    manager.responseSerializer = [AFHTTPResponseSerializer serializer];
    if ([method isEqualToString:@"POST"]) {
        [manager POST:urlString
           parameters:params
              success:^(AFHTTPRequestOperation *operation, id responseObject) {
                  NSLog(@"POST %@", [[NSString alloc] initWithData:responseObject encoding:NSUTF8StringEncoding]);
                  callback(nil, responseObject);
              }
              failure:^(AFHTTPRequestOperation *operation, NSError *error) {
                  if (error) {
                      NSLog(@"Error %@", [error localizedDescription]);
                      callback(error, nil);
                  }
              }];
    } else {
        [manager GET:urlString
          parameters:params
             success:^(AFHTTPRequestOperation *operation, id responseObject) {
                 NSLog(@"GET %@", [NSJSONSerialization JSONObjectWithData:responseObject options:0 error:nil]);
                 callback(nil, responseObject);
             }
             failure:^(AFHTTPRequestOperation *operation, NSError *error) {
                 if (error) {
                     NSLog(@"Error %@", [error localizedDescription]);
                     callback(error, nil);
                 }
             }];
    }
}

-(void)getUserLogin:(NSString *)resident_id Password:(NSString *)password WithCallback:(callbackBlock)callback
{
    [self makeRequestToURL:[NSString stringWithFormat:@"%@resident/residentlogin?ws=condo&resident_id=%@&password=%@", Base_Url, resident_id, password]
            withParameters:nil
                 andMethod:@"POST"
               andCallback:^(NSError *err, id response) {
                   if (err) {
                       callback(err, nil);
                   } else {
                       callback(nil, response);
                   }
               }];
    
}

-(void)changeOTP:(NSNumber *)resident_id Password:(NSString *)password WithCallback:(callbackBlock)callback
{
    [self makeRequestToURL:[NSString stringWithFormat:@"%@resident/otp?ws=condo&res_id=%@&newpass=%@", Base_Url, resident_id, password]
            withParameters:nil
                 andMethod:@"POST"
               andCallback:^(NSError *err, id response) {
                   if (err) {
                       callback(err, nil);
                   } else {
                       callback(nil, response);
                   }
               }];
    
}

-(void)registerDeviceId:(NSNumber *)condo_id res_id:(NSNumber *)res_id device_id:(NSString *)device_id WithCallback:(callbackBlock)callback
{
    [self makeRequestToURL:[NSString stringWithFormat:@"%@resident/registerdevice?ws=condo&condo_id=%@&res_id=%@&device_id=%@&type=1", Base_Url, condo_id, res_id, device_id]
            withParameters:nil
                 andMethod:@"POST"
               andCallback:^(NSError *err, id response) {
                   if (err) {
                       callback(err, nil);
                   } else {
                       callback(nil, response);
                   }
               }];
    
}

-(void)addFault:(NSNumber *)condo_id res_id:(NSNumber *)res_id fault_name:(NSString *)fault_name fault_desc:(NSString *)fault_desc UploadImage:(UIImage *)uploadImage WithCallback:(callbackBlock)callback
{
    AFHTTPRequestOperationManager *manager = [[AFHTTPRequestOperationManager alloc] initWithBaseURL:[NSURL URLWithString:@"http://server.url"]];
    [manager.requestSerializer setValue:@"multipart/form-data" forHTTPHeaderField:@"Content-Type"];
    manager.responseSerializer = [AFHTTPResponseSerializer serializer];
    
    NSDictionary *params = [NSDictionary dictionaryWithObjectsAndKeys:condo_id, @"condo_id", res_id, @"res_id", fault_name, @"fault_name", fault_desc, @"fault_desc", [NSNumber numberWithInt:0], @"action", [NSNumber numberWithInt:1], @"status", nil];
    
    AFHTTPRequestOperation *op = [manager POST:[[NSString stringWithFormat:@"%@faultreporting/addfault?ws=condo&condo_id=%@&res_id=%@&fault_name=%@&fault_desc=%@&action=0&status=1", Base_Url, condo_id, res_id, fault_name, fault_desc] stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding] parameters:params constructingBodyWithBlock:^(id<AFMultipartFormData> formData) {
        [formData appendPartWithFileData:UIImagePNGRepresentation(uploadImage) name:@"fault_photo" fileName:[NSString stringWithFormat:@"Photo_%@.png", [self getCurrentDate]] mimeType:@"image/png"];
    } success:^(AFHTTPRequestOperation *operation, id responseObject) {
        callback(nil, responseObject);
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        callback(error, nil);
    }];
    [op start];
}

-(void)listFaultPhoto:(NSNumber *)condo_id res_id:(NSNumber *)res_id WithCallback:(callbackBlock)callback
{
    [self makeRequestToURL:[NSString stringWithFormat:@"%@faultreporting/listfaultphoto?ws=condo&condo_id=%@&res_id=%@", Base_Url, condo_id, res_id]
            withParameters:nil
                 andMethod:@"GET"
               andCallback:^(NSError *err, id response) {
                   if (err) {
                       callback(err, nil);
                   } else {
                       callback(nil, response);
                   }
               }];
    
}

-(NSString *) getCurrentDate
{
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    formatter.dateFormat = @"ddMMYYYY_hhmmss";
    NSDate *date = [[NSDate alloc] init];
    NSString *ret = [formatter stringFromDate:date];
    return ret;
}

-(void)listEmergencyNo:(NSNumber *)condo_id WithCallback:(callbackBlock)callback
{
    [self makeRequestToURL:[NSString stringWithFormat:@"%@emergencyno/listemergencyno?ws=condo&condo_id=%@", Base_Url, condo_id]
            withParameters:nil
                 andMethod:@"GET"
               andCallback:^(NSError *err, id response) {
                   if (err) {
                       callback(err, nil);
                   } else {
                       callback(nil, response);
                   }
               }];
}

-(void)listNotices:(NSNumber *)condo_id res_id:(NSNumber *)res_id pageNo:(NSNumber *)page WithCallback:(callbackBlock)callback
{
    [self makeRequestToURL:[NSString stringWithFormat:@"%@notice/listnotice?ws=condo&condo_id=%@&res_id=%@&page=%@", Base_Url, condo_id,res_id,page]
            withParameters:nil
                 andMethod:@"GET"
               andCallback:^(NSError *err, id response) {
                   if (err) {
                       callback(err, nil);
                   } else {
                       callback(nil, response);
                   }
               }];
}

-(void)listManagement:(NSNumber *)condo_id pageNo:(NSNumber *)page WithCallback:(callbackBlock)callback
{
    [self makeRequestToURL:[NSString stringWithFormat:@"%@management/listmanagement?ws=condo&condo_id=%@&page=%@", Base_Url, condo_id,page]
            withParameters:nil
                 andMethod:@"GET"
               andCallback:^(NSError *err, id response) {
                   if (err) {
                       callback(err, nil);
                   } else {
                       callback(nil, response);
                   }
               }];
}

-(void)listEvents:(NSNumber *)condo_id res_id:(NSNumber *)res_id pageNo:(NSNumber *)page WithCallback:(callbackBlock)callback
{
    [self makeRequestToURL:[NSString stringWithFormat:@"%@event/checkevent?ws=condo&condo_id=%@&res_id=%@&page=%@", Base_Url, condo_id,res_id,page]
            withParameters:nil
                 andMethod:@"GET"
               andCallback:^(NSError *err, id response) {
                   if (err) {
                       callback(err, nil);
                   } else {
                       callback(nil, response);
                   }
               }];
}

-(void)actionOnEvent:(NSNumber *)condo_id res_id:(NSNumber *)res_id event_id:(NSNumber *)event_id action:(NSNumber *)action no_of_person:(NSNumber *)no_of_person WithCallback:(callbackBlock)callback
{
    [self makeRequestToURL:[NSString stringWithFormat:@"%@event/EventAction?ws=condo&condo_id=%@&res_id=%@&event_id=%@&action=%@&no_of_person=%@", Base_Url, condo_id, res_id, event_id, action,no_of_person]
            withParameters:nil
                 andMethod:@"POST"
               andCallback:^(NSError *err, id response) {
                   if (err) {
                       callback(err, nil);
                   } else {
                       callback(nil, response);
                   }
               }];
}

-(void)listGallery:(NSNumber *)condo_id res_id:(NSNumber *)res_id  pageNo:(NSNumber *)page WithCallback:(callbackBlock)callback
{
    [self makeRequestToURL:[NSString stringWithFormat:@"%@gallery/listgallery?ws=condo&condo_id=%@&res_id=%@&page=%@", Base_Url, condo_id,res_id,page]
            withParameters:nil
                 andMethod:@"GET"
               andCallback:^(NSError *err, id response) {
                   if (err) {
                       callback(err, nil);
                   } else {
                       callback(nil, response);
                   }
               }];
}

-(void)listGalleryItem:(NSNumber *)condo_id g_id:(NSNumber *)g_id WithCallback:(callbackBlock)callback
{
    [self makeRequestToURL:[NSString stringWithFormat:@"%@galleryitem/listgalleryitem?ws=condo&g_id=%@&condo_id=%@&page=1", Base_Url, g_id, condo_id]
            withParameters:nil
                 andMethod:@"GET"
               andCallback:^(NSError *err, id response) {
                   if (err) {
                       callback(err, nil);
                   } else {
                       callback(nil, response);
                   }
               }];
}

-(void)listWebsite:(NSNumber *)condo_id WithCallback:(callbackBlock)callback
{
    [self makeRequestToURL:[NSString stringWithFormat:@"%@website/listwebsite?ws=condo&condo_id=%@", Base_Url, condo_id]
            withParameters:nil
                 andMethod:@"GET"
               andCallback:^(NSError *err, id response) {
                   if (err) {
                       callback(err, nil);
                   } else {
                       callback(nil, response);
                   }
               }];
}

-(void)maintenanceAmount:(NSNumber *)res_id condoID:(NSNumber *)condo_id WithCallback:(callbackBlock)callback
{
    [self makeRequestToURL:[NSString stringWithFormat:@"%@maintenancepayment/checkpaymaintenance?ws=condo&condo_id=%@&res_id=%@", Base_Url, condo_id,res_id]
            withParameters:nil
                 andMethod:@"GET"
               andCallback:^(NSError *err, id response) {
                   if (err) {
                       callback(err, nil);
                   } else {
                       callback(nil, response);
                   }
               }];
}

-(void)quitRentAmount:(NSNumber *)res_id condoID:(NSNumber *)condo_id WithCallback:(callbackBlock)callback
{
    [self makeRequestToURL:[NSString stringWithFormat:@"%@quitrent/checkpayquitrent?ws=condo&condo_id=%@&res_id=%@", Base_Url, condo_id,res_id]
            withParameters:nil
                 andMethod:@"GET"
               andCallback:^(NSError *err, id response) {
                   if (err) {
                       callback(err, nil);
                   } else {
                       callback(nil, response);
                   }
               }];
}

-(void)fireInsuranceAmount:(NSNumber *)res_id condoID:(NSNumber *)condo_id WithCallback:(callbackBlock)callback
{
    [self makeRequestToURL:[NSString stringWithFormat:@"%@fireinsurance/checkpayfireinsurance?ws=condo&condo_id=%@&res_id=%@", Base_Url, condo_id,res_id]
            withParameters:nil
                 andMethod:@"GET"
               andCallback:^(NSError *err, id response) {
                   if (err) {
                       callback(err, nil);
                   } else {
                       callback(nil, response);
                   }
               }];
}

-(void)sinkingFundAmount:(NSNumber *)res_id condoID:(NSNumber *)condo_id WithCallback:(callbackBlock)callback
{
    [self makeRequestToURL:[NSString stringWithFormat:@"%@sinkingfund/checkpaysinkingfund?ws=condo&condo_id=%@&res_id=%@", Base_Url, condo_id,res_id]
            withParameters:nil
                 andMethod:@"GET"
               andCallback:^(NSError *err, id response) {
                   if (err) {
                       callback(err, nil);
                   } else {
                       callback(nil, response);
                   }
               }];
}


-(void)payMaintenance:(NSNumber *)condo_id res_id:(NSNumber *)res_id payDate:(NSString *)pay_date maintenance_amount:(NSString *)maintenance_amount maintenance_penalty:(NSString *)maintenance_penalty totalAmount:(NSString *)totalAmount transectionID:(NSString *)transection_id transectionStatus:(NSNumber *)transection_status WithCallback:(callbackBlock)callback
{
    [self makeRequestToURL:[NSString stringWithFormat:@"%@maintenancepayment/paymaintenance?ws=condo&condo_id=%@&res_id=%@&pay_date=%@&maintenance_amount=%@&maintenance_penalty=%@&total_amount=%@&transaction_id=%@&transaction_status=%@", Base_Url, condo_id, res_id,pay_date, maintenance_amount, maintenance_penalty,totalAmount,transection_id,transection_status]
            withParameters:nil
                 andMethod:@"GET"
               andCallback:^(NSError *err, id response) {
                   if (err) {
                       callback(err, nil);
                   } else {
                       callback(nil, response);
                   }
               }];
}

-(void)payInsurance:(NSNumber *)condo_id res_id:(NSNumber *)res_id payDate:(NSString *)pay_date insurance_amount:(NSString *)insurance_amount insurance_penalty:(NSString *)insurance_penalty totalAmount:(NSString *)totalAmount transectionID:(NSString *)transection_id transectionStatus:(NSNumber *)transection_status WithCallback:(callbackBlock)callback
{
    [self makeRequestToURL:[NSString stringWithFormat:@"%@/fireinsurance/payfireinsurance?ws=condo&condo_id=%@&res_id=%@&pay_date=%@&amount=%@&penalty_amount=%@&total_amount=%@&transaction_id=%@&transaction_status=%@", Base_Url, condo_id, res_id,pay_date, insurance_amount, insurance_penalty,totalAmount,transection_id,transection_status]
            withParameters:nil
                 andMethod:@"GET"
               andCallback:^(NSError *err, id response) {
                   if (err) {
                       callback(err, nil);
                   } else {
                       callback(nil, response);
                   }
               }];
}

-(void)payRent:(NSNumber *)condo_id res_id:(NSNumber *)res_id payDate:(NSString *)pay_date rent_amount:(NSString *)insurance_amount rent_penalty:(NSString *)insurance_penalty totalAmount:(NSString *)totalAmount transectionID:(NSString *)transection_id transectionStatus:(NSNumber *)transection_status WithCallback:(callbackBlock)callback
{
    [self makeRequestToURL:[NSString stringWithFormat:@"%@/quitrent/payquitrent?ws=condo&condo_id=%@&res_id=%@&pay_date=%@&amount=%@&penalty_amount=%@&total_amount=%@&transaction_id=%@&transaction_status=%@", Base_Url, condo_id, res_id,pay_date, insurance_amount, insurance_penalty,totalAmount,transection_id,transection_status]
            withParameters:nil
                 andMethod:@"GET"
               andCallback:^(NSError *err, id response) {
                   if (err) {
                       callback(err, nil);
                   } else {
                       callback(nil, response);
                   }
               }];
}

-(void)payFund:(NSNumber *)condo_id res_id:(NSNumber *)res_id payDate:(NSString *)pay_date fund_amount:(NSString *)fund_amount fund_penalty:(NSString *)fund_penalty totalAmount:(NSString *)totalAmount transectionID:(NSString *)transection_id transectionStatus:(NSNumber *)transection_status WithCallback:(callbackBlock)callback
{
    [self makeRequestToURL:[NSString stringWithFormat:@"%@/sinkingfund/paysinkingfund?ws=condo&condo_id=%@&res_id=%@&pay_date=%@&amount=%@&penalty_amount=%@&total_amount=%@&transaction_id=%@&transaction_status=%@", Base_Url, condo_id, res_id,pay_date, fund_amount, fund_penalty,totalAmount,transection_id,transection_status]
            withParameters:nil
                 andMethod:@"GET"
               andCallback:^(NSError *err, id response) {
                   if (err) {
                       callback(err, nil);
                   } else {
                       callback(nil, response);
                   }
               }];
}


-(void)paymentConfiguration:(NSNumber *)condo_id WithCallback:(callbackBlock)callback
{
    [self makeRequestToURL:[NSString stringWithFormat:@"%@settings/paymentconfiguration?ws=condo&condo_id=%@", Base_Url, condo_id]
            withParameters:nil
                 andMethod:@"GET"
               andCallback:^(NSError *err, id response) {
                   if (err) {
                       callback(err, nil);
                   } else {
                       callback(nil, response);
                   }
               }];
}

-(void)tabConfigration:(NSNumber *)condo_id res_id:(NSNumber *)res_id WithCallback:(callbackBlock)callback
{
    NSLog(@"url of tab %@",[NSString stringWithFormat:@"%@settings/tabconfiguration?ws=condo&condo_id=%@&res_id=%@", Base_Url, condo_id,res_id]);
    [self makeRequestToURL:[NSString stringWithFormat:@"%@settings/tabconfiguration?ws=condo&condo_id=%@&res_id=%@", Base_Url, condo_id,res_id]
            withParameters:nil
                 andMethod:@"GET"
               andCallback:^(NSError *err, id response) {
                   if (err) {
                       callback(err, nil);
                   } else {
                       callback(nil, response);
                   }
               }];
}

-(void)listMasterFacility:(NSNumber *)condo_id WithCallback:(callbackBlock)callback
{
    [self makeRequestToURL:[NSString stringWithFormat:@"%@facilitymaster/listfacilitymaster?ws=condo&condo_id=%@", Base_Url, condo_id]
            withParameters:nil
                 andMethod:@"GET"
               andCallback:^(NSError *err, id response) {
                   if (err) {
                       callback(err, nil);
                   } else {
                       callback(nil, response);
                   }
               }];
}

-(void)listChildFacility:(NSNumber *)condo_id res_id:(NSNumber *)res_id fm_id:(NSNumber *)fm_id change_bk:(NSNumber *)change_bk date:(NSString *)date WithCallback:(callbackBlock)callback
{
    NSLog(@"urlll facility %@",[NSString stringWithFormat:@"%@facilitychild/listfts?ws=condo&condo_id=%@&res_id=%@&fm_id=%@&change_bk=%@&date=%@", Base_Url, condo_id, res_id, fm_id, change_bk, date]);
    [self makeRequestToURL:[NSString stringWithFormat:@"%@facilitychild/listfts?ws=condo&condo_id=%@&res_id=%@&fm_id=%@&change_bk=%@&date=%@", Base_Url, condo_id, res_id, fm_id, change_bk, date]
            withParameters:nil
                 andMethod:@"GET"
               andCallback:^(NSError *err, id response) {
                   if (err) {
                       callback(err, nil);
                   } else {
                       NSLog(@"responsee %@",response);
                       callback(nil, response);
                   }
               }];
}

-(void)addBooking:(NSNumber *)res_id ft_id:(NSNumber *)ft_id change_bk:(NSNumber *)change_bk date:(NSString *)date WithCallback:(callbackBlock)callback
{
    NSLog(@"urrllll bookingg %@",[NSString stringWithFormat:@"%@facilitybooking/bookfacility?ws=condo&res_id=%@&ft_id=%@&change_bk=%@&date=%@", Base_Url, res_id, ft_id, change_bk, date]);
    [self makeRequestToURL:[NSString stringWithFormat:@"%@facilitybooking/bookfacility?ws=condo&res_id=%@&ft_id=%@&change_bk=%@&date=%@", Base_Url, res_id, ft_id, change_bk, date]
            withParameters:nil
                 andMethod:@"POST"
               andCallback:^(NSError *err, id response) {
                   if (err) {
                       callback(err, nil);
                   } else {
                       callback(nil, response);
                   }
               }];
}

-(void)updateBooking:(NSNumber *)res_id fb_id:(NSNumber *)fb_id transectionID:(NSString *)transection_ID transectionStatus:(NSNumber *)transection_Status WithCallback:(callbackBlock)callback
{
    NSLog(@"url update %@",[NSString stringWithFormat:@"%@facilitybooking/updatebooking?ws=condo&res_id=%@&fb_id=%@&transaction_id=%@&transaction_status=%@", Base_Url, res_id, fb_id, transection_ID, transection_Status]);
    [self makeRequestToURL:[NSString stringWithFormat:@"%@facilitybooking/updatebooking?ws=condo&res_id=%@&fb_id=%@&transaction_id=%@&transaction_status=%@", Base_Url, res_id, fb_id, transection_ID, transection_Status]
            withParameters:nil
                 andMethod:@"POST"
               andCallback:^(NSError *err, id response) {
                   if (err) {
                       callback(err, nil);
                   } else {
                       callback(nil, response);
                   }
               }];
}


-(void)listBookingForResident:(NSNumber *)condo_id res_id:(NSNumber *)res_id upcoming:(NSNumber *)upcoming pageNo:(NSNumber *)page WithCallback:(callbackBlock)callback
{
    NSLog(@"booking resident %@",[NSString stringWithFormat:@"%@facilitybooking/listresbooking?ws=condo&condo_id=%@&res_id=%@&upcoming=%@&page=%@", Base_Url, condo_id, res_id, upcoming, page]);
    [self makeRequestToURL:[NSString stringWithFormat:@"%@facilitybooking/listresbooking?ws=condo&condo_id=%@&res_id=%@&upcoming=%@&page=%@", Base_Url, condo_id, res_id, upcoming, page]
            withParameters:nil
                 andMethod:@"GET"
               andCallback:^(NSError *err, id response) {
                   if (err) {
                       callback(err, nil);
                   } else {
                       callback(nil, response);
                   }
               }];
}

-(void)changeBooking:(NSNumber *)res_id ft_id:(NSNumber *)ft_id change_bk:(NSNumber *)change_bk date:(NSString *)date WithCallback:(callbackBlock)callback
{
    [self makeRequestToURL:[NSString stringWithFormat:@"%@facilitybooking/bookfacility?ws=condo&res_id=%@&ft_id=%@&change_bk=%@&date=%@", Base_Url, res_id, ft_id, change_bk, date]
            withParameters:nil
                 andMethod:@"POST"
               andCallback:^(NSError *err, id response) {
                   if (err) {
                       callback(err, nil);
                   } else {
                       callback(nil, response);
                   }
               }];
}

-(void)cancelBooking:(NSNumber *)res_id fb_id:(NSNumber *)fb_id WithCallback:(callbackBlock)callback
{
    [self makeRequestToURL:[NSString stringWithFormat:@"%@facilitybooking/CancelBooking?ws=condo&res_id=%@&fb_id=%@", Base_Url, res_id, fb_id]
            withParameters:nil
                 andMethod:@"POST"
               andCallback:^(NSError *err, id response) {
                   if (err) {
                       callback(err, nil);
                   } else {
                       callback(nil, response);
                   }
               }];
}

-(void)addGuestListRequest:(NSNumber *)condo_id block_id:(NSString *)block_id unit_id:(NSString *)unit_id name:(NSString *)name no_of_guest:(NSNumber *)no_of_guest visiting_date:(NSString *)visiting_date WithCallback:(callbackBlock)callback
{
    [self makeRequestToURL:[[NSString stringWithFormat:@"%@guestlistrequest/createguestlistrequest?ws=condo&condo_id=%@&block_id=%@&unit_id=%@&name=%@&no_of_guest=%@&visiting_date=%@&status=1", Base_Url,condo_id,block_id,unit_id,name,no_of_guest,visiting_date] stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]
            withParameters:nil
                 andMethod:@"POST"
               andCallback:^(NSError *err, id response) {
                   if (err) {
                       callback(err, nil);
                   } else {
                       callback(nil, response);
                   }
               }];
}

-(void)recentListRequest:(NSNumber *)condo_id block_id:(NSString *)block_id unit_id:(NSString *)unit_id WithCallback:(callbackBlock)callback
{
    [self makeRequestToURL:[[NSString stringWithFormat:@"%@guestlistrequest/guestlist?ws=condo&condo_id=%@&block_id=%@&unit_id=%@", Base_Url,condo_id,block_id,unit_id] stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]
            withParameters:nil
                 andMethod:@"POST"
               andCallback:^(NSError *err, id response) {
                   if (err) {
                       callback(err, nil);
                   } else {
                       callback(nil, response);
                   }
               }];
}

-(void)deleteGuestListRequest:(NSNumber *)glr_id WithCallback:(callbackBlock)callback
{
    [self makeRequestToURL:[[NSString stringWithFormat:@"%@guestlistrequest/deleteglr?ws=condo&glr_id=%@", Base_Url,glr_id] stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]
            withParameters:nil
                 andMethod:@"POST"
               andCallback:^(NSError *err, id response) {
                   if (err) {
                       callback(err, nil);
                   } else {
                       callback(nil, response);
                   }
               }];
}


-(void)updateGuestListRequest:(NSString *)name no_of_guest:(NSNumber *)no_of_guest visiting_date:(NSString *)visiting_date glr_id:(NSNumber *)glr_id WithCallback:(callbackBlock)callback
{
    [self makeRequestToURL:[[NSString stringWithFormat:@"%@guestlistrequest/guestlistupdate?ws=condo&name=%@&no_of_guest=%@&visiting_date=%@&glr_id=%@", Base_Url,name,no_of_guest,visiting_date,glr_id] stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]
            withParameters:nil
                 andMethod:@"POST"
               andCallback:^(NSError *err, id response) {
                   if (err) {
                       callback(err, nil);
                   } else {
                       callback(nil, response);
                   }
               }];
}

-(void)updateNotificationData:(NSNumber *)resident_id pageNo:(NSNumber *)page WithCallback:(callbackBlock)callback
{
    [self makeRequestToURL:[NSString stringWithFormat:@"%@pushnotification/pnlist?ws=condo&res_id=%@&page=%@", Base_Url, resident_id,page]
            withParameters:nil
                 andMethod:@"POST"
               andCallback:^(NSError *err, id response) {
                   if (err) {
                       callback(err, nil);
                   } else {
                       callback(nil, response);
                   }
               }];
}

-(void)readUpdateNotification:(NSNumber *)not_id WithCallback:(callbackBlock)callback
{
    [self makeRequestToURL:[NSString stringWithFormat:@"%@pushnotification/upunreadnp?ws=condo&id=%@", Base_Url, not_id]
            withParameters:nil
                 andMethod:@"POST"
               andCallback:^(NSError *err, id response) {
                   if (err) {
                       callback(err, nil);
                   } else {
                       callback(nil, response);
                   }
               }];
}

-(void)readUpdateNotice:(NSNumber *)not_id WithCallback:(callbackBlock)callback
{
    [self makeRequestToURL:[NSString stringWithFormat:@"%@notice/upunreadnotice?ws=condo&id=%@", Base_Url, not_id]
            withParameters:nil
                 andMethod:@"POST"
               andCallback:^(NSError *err, id response) {
                   if (err) {
                       callback(err, nil);
                   } else {
                       callback(nil, response);
                   }
               }];
}

-(void)updateProfile:(NSNumber *)res_id titleNo:(NSNumber *)title first_name:(NSString *)first_name last_name:(NSString *)last_name mobile_no:(NSString *)mobile_no email:(NSString *)email WithCallback:(callbackBlock)callback
{
    [self makeRequestToURL:[NSString stringWithFormat:@"%@resident/updateprofile?ws=condo&res_id=%@&title=%@&first_name=%@&last_name=%@&mobile_no=%@&email=%@", Base_Url, res_id, title, first_name, last_name, mobile_no, email]
            withParameters:nil
                 andMethod:@"POST"
               andCallback:^(NSError *err, id response) {
                   if (err) {
                       callback(err, nil);
                   } else {
                       callback(nil, response);
                   }
               }];
}

-(void)changePassword:(NSNumber *)res_id old_password:(NSString *)old_password new_password:(NSString *)new_password WithCallback:(callbackBlock)callback
{
    [self makeRequestToURL:[NSString stringWithFormat:@"%@resident/changepassword?ws=condo&res_id=%@&old_password=%@&new_password=%@", Base_Url, res_id, old_password, new_password]
            withParameters:nil
                 andMethod:@"POST"
               andCallback:^(NSError *err, id response) {
                   if (err) {
                       callback(err, nil);
                   } else {
                       callback(nil, response);
                   }
               }];
}

-(void)updateUnReadGallery:(NSNumber *)gallary_id WithCallback:(callbackBlock)callback
{
    NSLog(@"gallry %@",[NSString stringWithFormat:@"%@gallery/upunreadgallery?ws=condo&id=%@", Base_Url, gallary_id]);
    [self makeRequestToURL:[NSString stringWithFormat:@"%@gallery/upunreadgallery?ws=condo&id=%@", Base_Url, gallary_id]
            withParameters:nil
                 andMethod:@"POST"
               andCallback:^(NSError *err, id response) {
                   if (err) {
                       callback(err, nil);
                   } else {
                       callback(nil, response);
                   }
               }];
}

-(void)updateUnReadEvent:(NSNumber *)gallary_id WithCallback:(callbackBlock)callback
{
    [self makeRequestToURL:[NSString stringWithFormat:@"%@event/upunreadevent?ws=condo&id=%@", Base_Url, gallary_id]
            withParameters:nil
                 andMethod:@"POST"
               andCallback:^(NSError *err, id response) {
                   if (err) {
                       callback(err, nil);
                   } else {
                       callback(nil, response);
                   }
               }];
}

@end