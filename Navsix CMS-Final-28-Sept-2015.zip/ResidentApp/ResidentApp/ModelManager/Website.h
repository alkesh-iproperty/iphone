//
//  Website.h
//  ResidentApp
//
//  Created by TheAppGuruz on 07/07/15.
//  Copyright (c) 2015 TheAppGuruz-New-6. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Website : NSObject

@property (nonatomic, strong) NSNumber *web_id;
@property (nonatomic, strong) NSNumber *condo_id;
@property (nonatomic, strong) NSString *website;

-(int)parseResponse:(NSDictionary *)dictionary;

@end