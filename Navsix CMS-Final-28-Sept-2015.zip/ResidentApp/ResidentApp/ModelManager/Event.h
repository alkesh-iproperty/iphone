//
//  Event.h
//  ResidentApp
//
//  Created by TheAppGuruz on 07/07/15.
//  Copyright (c) 2015 TheAppGuruz-New-6. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Event : NSObject

@property (nonatomic, strong) NSNumber *id;
@property (nonatomic, strong) NSNumber *event_id;
@property (nonatomic, strong) NSNumber *condo_id;
@property (nonatomic, strong) NSNumber *event_type;
@property (nonatomic, strong) NSString *event_img;
@property (nonatomic, strong) NSString *read;
@property (nonatomic, strong) NSString *event_name;
@property (nonatomic, strong) NSString *event_desc;
@property (nonatomic, strong) NSString *start_time;
@property (nonatomic, strong) NSString *end_time;
@property (nonatomic, strong) NSNumber *total_person;
-(int)parseResponse:(NSDictionary *)dictionary;

@end