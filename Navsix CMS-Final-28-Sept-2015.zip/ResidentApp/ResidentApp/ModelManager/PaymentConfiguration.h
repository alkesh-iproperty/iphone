//
//  PaymentConfiguration.h
//  ResidentApp
//
//  Created by TheAppGuruz on 07/07/15.
//  Copyright (c) 2015 TheAppGuruz-New-6. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface PaymentConfiguration : NSObject

@property (nonatomic, strong) NSNumber *p_id;
@property (nonatomic, strong) NSNumber *condo_id;
@property (nonatomic, strong) NSNumber *environment;
@property (nonatomic, strong) NSString *production_client_id;
@property (nonatomic, strong) NSString *sandbox_client_id;
@property (nonatomic, strong) NSNumber *accept_credit_cards;
@property (nonatomic, strong) NSString *merchant_name;
@property (nonatomic, strong) NSString *privacy_policy_url;
@property (nonatomic, strong) NSString *user_agreement_url;
@property (nonatomic, strong) NSString *password;
@property (nonatomic, strong) NSString *pin;
@property (nonatomic, strong) NSString *user_email;
@property (nonatomic, strong) NSString *phone_number;
@property (nonatomic, strong) NSString *phone_country_code;

-(int)parseResponse:(NSDictionary *)dictionary;

@end