//
//  UpdateNotificaitonList.m
//  ResidentApp
//
//  Created by TheAppGuruz-iOS-103 on 21/07/15.
//  Copyright (c) 2015 TheAppGuruz-New-6. All rights reserved.
//

#import "UpdateNotificaitonList.h"

@implementation UpdateNotificaitonList

-(int)parseResponse:(NSDictionary *)dictionary
{
    self.not_id = [dictionary valueForKey:@"id"];
    self.pn_id = [dictionary valueForKey:@"pn_id"];
    self.condo_id = [dictionary valueForKey:@"condo_id"];
    self.res_id = [dictionary valueForKey:@"res_id"];
    self.datetime = [dictionary valueForKey:@"datetime"];
    self.read = [dictionary valueForKey:@"read"];
    self.message_title = [dictionary valueForKey:@"message_title"];
    self.send_to = [dictionary valueForKey:@"send_to"];
    self.content_type = [dictionary valueForKey:@"content_type"];
    self.content_type_data = [dictionary valueForKey:@"content_type_data"];
    self.send_on = [dictionary valueForKey:@"send_on"];
    
    return 0;
}

@end
