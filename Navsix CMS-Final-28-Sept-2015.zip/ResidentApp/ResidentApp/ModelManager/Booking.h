//
//  Booking.h
//  ResidentApp
//
//  Created by TheAppGuruz on 08/07/15.
//  Copyright (c) 2015 TheAppGuruz-New-6. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Booking : NSObject

@property (nonatomic, strong) NSNumber *amount;
@property (nonatomic, strong) NSNumber *approve;
@property (nonatomic, strong) NSNumber *booking_cancelled;
@property (nonatomic, strong) NSNumber *booking_changed;
@property (nonatomic, strong) NSString *datetime;
@property (nonatomic, strong) NSNumber *deposit_amount;
@property (nonatomic, strong) NSNumber *fb_id;
@property (nonatomic, strong) NSNumber *fc_id;
@property (nonatomic, strong) NSString *fc_name;
@property (nonatomic, strong) NSNumber *fm_id;
@property (nonatomic, strong) NSNumber *insufficient_deposit;
@property (nonatomic, strong) NSString *is_cancel_or_change;
@property (nonatomic, strong) NSNumber *payment_type;
@property (nonatomic, strong) NSNumber *res_id;
@property (nonatomic, strong) NSNumber *status;
@property (nonatomic, strong) NSString *time_slot_end;
@property (nonatomic, strong) NSString *time_slot_start;
@property (nonatomic, strong) NSNumber *transaction_status;


-(int)parseResponse:(NSDictionary *)dictionary;

@end