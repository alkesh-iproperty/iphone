//
//  PaymentConfiguration.m
//  ResidentApp
//
//  Created by TheAppGuruz on 07/07/15.
//  Copyright (c) 2015 TheAppGuruz-New-6. All rights reserved.
//

#import "PaymentConfiguration.h"

@implementation PaymentConfiguration

-(int)parseResponse:(NSDictionary *)dictionary
{
    self.p_id = [dictionary valueForKey:@"p_id"];
    self.condo_id = [dictionary valueForKey:@"condo_id"];
    self.environment = [dictionary valueForKey:@"environment"];
    self.production_client_id = [dictionary valueForKey:@"production_client_id"];
    self.sandbox_client_id = [dictionary valueForKey:@"sandbox_client_id"];
    self.accept_credit_cards = [dictionary valueForKey:@"accept_credit_cards"];
    self.merchant_name = [dictionary valueForKey:@"merchant_name"];
    self.privacy_policy_url = [dictionary valueForKey:@"privacy_policy_url"];
    self.user_agreement_url = [dictionary valueForKey:@"user_agreement_url"];
    self.password = [dictionary valueForKey:@"password"];
    self.pin = [dictionary valueForKey:@"pin"];
    self.user_email = [dictionary valueForKey:@"user_email"];
    self.phone_number = [dictionary valueForKey:@"phone_number"];
    
    return 0;
}

@end