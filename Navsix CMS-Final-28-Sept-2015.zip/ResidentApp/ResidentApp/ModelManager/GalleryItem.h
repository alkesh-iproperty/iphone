//
//  GalleryItem.h
//  ResidentApp
//
//  Created by TheAppGuruz on 07/07/15.
//  Copyright (c) 2015 TheAppGuruz-New-6. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface GalleryItem : NSObject

@property (nonatomic, strong) NSNumber *gi_id;
@property (nonatomic, strong) NSNumber *g_id;
@property (nonatomic, strong) NSNumber *condo_id;
@property (nonatomic, strong) NSString *name;
@property (nonatomic, strong) NSString *photo_name;
@property (nonatomic, strong) NSString *photo_desc;
@property (nonatomic, strong) NSString *datetime;

-(int)parseResponse:(NSDictionary *)dictionary;

@end