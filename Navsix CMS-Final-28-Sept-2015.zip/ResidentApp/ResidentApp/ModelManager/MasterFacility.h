//
//  MasterFacility.h
//  ResidentApp
//
//  Created by TheAppGuruz on 07/07/15.
//  Copyright (c) 2015 TheAppGuruz-New-6. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MasterFacility : NSObject

@property (nonatomic, strong) NSNumber *fm_id;
@property (nonatomic, strong) NSString *fm_name;
@property (nonatomic, strong) NSNumber *total_no_of_facility;
@property (nonatomic, strong) NSNumber *book_limit_per_month;
@property (nonatomic, strong) NSNumber *advance_book_period;
@property (nonatomic, strong) NSNumber *payment_type;
@property (nonatomic, strong) NSString *images;
@property (nonatomic, strong) NSString *icon_image;
@property (nonatomic, strong) NSString *details;

-(int)parseResponse:(NSDictionary *)dictionary;

@end