//
//  Management.m
//  ResidentApp
//
//  Created by TheAppGuruz on 07/07/15.
//  Copyright (c) 2015 TheAppGuruz-New-6. All rights reserved.
//

#import "Management.h"

@implementation Management

-(int)parseResponse:(NSDictionary *)dictionary
{
    self.mgmt_id = [dictionary valueForKey:@"mgmt_id"];
    self.name = [dictionary valueForKey:@"name"];
    self.designation = [dictionary valueForKey:@"designation"];
    self.photo = [dictionary valueForKey:@"photo"];
    self.mobile_number = [dictionary valueForKey:@"mobile_number"];
    
    return 0;
}

@end