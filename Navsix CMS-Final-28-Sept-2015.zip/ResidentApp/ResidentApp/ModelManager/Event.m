//
//  Event.m
//  ResidentApp
//
//  Created by TheAppGuruz on 07/07/15.
//  Copyright (c) 2015 TheAppGuruz-New-6. All rights reserved.
//

#import "Event.h"

@implementation Event

-(int)parseResponse:(NSDictionary *)dictionary
{
    self.id = [dictionary valueForKey:@"id"];
    self.event_id = [dictionary valueForKey:@"event_id"];
    self.condo_id = [dictionary valueForKey:@"condo_id"];
    self.event_type = [dictionary valueForKey:@"event_type"];
    self.event_name = [dictionary valueForKey:@"event_name"];
    self.read = [dictionary valueForKey:@"read"];
    self.event_img = [dictionary valueForKey:@"event_img"];
    self.total_person = [dictionary valueForKey:@"total_person"];
    self.event_desc = [dictionary valueForKey:@"event_desc"];
    self.start_time = [dictionary valueForKey:@"start_time"];
    self.end_time = [dictionary valueForKey:@"end_time"];
    
    return 0;
}

@end