//
//  UserLogin.m
//  ResidentApp
//
//  Created by TheAppGuruz on 07/07/15.
//  Copyright (c) 2015 TheAppGuruz-New-6. All rights reserved.
//

#import "UserLogin.h"

@implementation UserLogin

-(int)parseResponse:(NSDictionary *)dictionary
{
    self.res_id = [dictionary valueForKey:@"res_id"];
    self.condo_id = [dictionary valueForKey:@"condo_id"];
    self.condo_name = [dictionary valueForKey:@"condo_name"];
    self.first_name = [dictionary valueForKey:@"first_name"];
    self.last_name = [dictionary valueForKey:@"last_name"];
    self.resident_id = [dictionary valueForKey:@"resident_id"];
    self.email = [dictionary valueForKey:@"email"];
    self.app_login = [dictionary valueForKey:@"app_login"];
    self.block_id = [dictionary valueForKey:@"block_id"];
    self.block_name = [dictionary valueForKey:@"block_name"];
    self.unit_id = [dictionary valueForKey:@"unit_id"];
    self.unit_name = [dictionary valueForKey:@"unit_name"];
    self.mobile_no = [dictionary valueForKey:@"mobile_no"];
    self.maintance_amount = [dictionary valueForKey:@"maintance_amount"];
    self.currency_code = [dictionary valueForKey:@"currency_code"];
    self.title = [dictionary valueForKey:@"title"];
    self.latitude = [dictionary valueForKey:@"latitude"];
    self.longitude = [dictionary valueForKey:@"longitude"];
    self.slider_images = [NSMutableArray arrayWithArray:[dictionary valueForKey:@"slider_images"]];
    self.payment_gateway = [NSDictionary dictionaryWithDictionary:[dictionary valueForKey:@"payment_gateway"]];
    return 0;
}

- (void)encodeWithCoder:(NSCoder *)encoder
{
    [encoder encodeObject:self.res_id forKey:@"res_id"];
    [encoder encodeObject:self.condo_id forKey:@"condo_id"];
    [encoder encodeObject:self.condo_name forKey:@"condo_name"];
    [encoder encodeObject:self.first_name forKey:@"first_name"];
    [encoder encodeObject:self.last_name forKey:@"last_name"];
    [encoder encodeObject:self.resident_id forKey:@"resident_id"];
    [encoder encodeObject:self.email forKey:@"email"];
    [encoder encodeObject:self.app_login forKey:@"app_login"];
    [encoder encodeObject:self.block_id forKey:@"block_id"];
    [encoder encodeObject:self.block_name forKey:@"block_name"];
    [encoder encodeObject:self.unit_id forKey:@"unit_id"];
    [encoder encodeObject:self.unit_name forKey:@"unit_name"];
    [encoder encodeObject:self.mobile_no forKey:@"mobile_no"];
    [encoder encodeObject:self.maintance_amount forKey:@"maintance_amount"];
    [encoder encodeObject:self.slider_images forKey:@"slider_images"];
    [encoder encodeObject:self.currency_code forKey:@"currency_code"];
    [encoder encodeObject:self.title forKey:@"title"];
    [encoder encodeObject:self.latitude forKey:@"latitude"];
    [encoder encodeObject:self.longitude forKey:@"longitude"];
    [encoder encodeObject:self.payment_gateway forKey:@"payment_gateway"];
}

- (id)initWithCoder:(NSCoder *)decoder
{
    if((self = [super init])) {
        self.res_id = [decoder decodeObjectForKey:@"res_id"];
        self.condo_id = [decoder decodeObjectForKey:@"condo_id"];
        self.condo_name = [decoder decodeObjectForKey:@"condo_name"];
        self.first_name = [decoder decodeObjectForKey:@"first_name"];
        self.last_name = [decoder decodeObjectForKey:@"last_name"];
        self.resident_id = [decoder decodeObjectForKey:@"resident_id"];
        self.email = [decoder decodeObjectForKey:@"email"];
        self.app_login = [decoder decodeObjectForKey:@"app_login"];
        self.block_id = [decoder decodeObjectForKey:@"block_id"];
        self.block_name = [decoder decodeObjectForKey:@"block_name"];
        self.unit_id = [decoder decodeObjectForKey:@"unit_id"];
        self.unit_name = [decoder decodeObjectForKey:@"unit_name"];
        self.mobile_no = [decoder decodeObjectForKey:@"mobile_no"];
        self.maintance_amount = [decoder decodeObjectForKey:@"maintance_amount"];
        self.slider_images = [decoder decodeObjectForKey:@"slider_images"];
        self.currency_code = [decoder decodeObjectForKey:@"currency_code"];
        self.title = [decoder decodeObjectForKey:@"title"];
        self.latitude = [decoder decodeObjectForKey:@"latitude"];
        self.longitude = [decoder decodeObjectForKey:@"longitude"];
        self.payment_gateway = [decoder decodeObjectForKey:@"payment_gateway"];
    }
    return self;
}

@end