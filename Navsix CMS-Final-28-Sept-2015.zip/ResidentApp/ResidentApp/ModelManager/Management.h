//
//  Management.h
//  ResidentApp
//
//  Created by TheAppGuruz on 07/07/15.
//  Copyright (c) 2015 TheAppGuruz-New-6. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Management : NSObject

@property (nonatomic, strong) NSNumber *mgmt_id;
@property (nonatomic, strong) NSString *name;
@property (nonatomic, strong) NSString *designation;
@property (nonatomic, strong) NSString *photo;
@property (nonatomic, strong) NSString *mobile_number;

-(int)parseResponse:(NSDictionary *)dictionary;

@end