//
//  ModelManager.h
//  ResidentApp
//
//  Created by TheAppGuruz-New-6 on 07/07/15.
//  Copyright (c) 2015 TheAppGuruz-New-6. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface ModelManager : NSObject

typedef void (^callbackBlock)(NSError* err, id response);

+ (ModelManager *)getInstance;

-(void)getUserLogin:(NSString *)securityId Password:(NSString *)password WithCallback:(callbackBlock)callback;
-(void)registerDeviceId:(NSNumber *)condo_id res_id:(NSNumber *)res_id device_id:(NSString *)device_id WithCallback:(callbackBlock)callback;
-(void)addFault:(NSNumber *)condo_id res_id:(NSNumber *)res_id fault_name:(NSString *)fault_name fault_desc:(NSString *)fault_desc UploadImage:(UIImage *)uploadImage WithCallback:(callbackBlock)callback;
-(void)listFaultPhoto:(NSNumber *)condo_id res_id:(NSNumber *)res_id WithCallback:(callbackBlock)callback;
-(void)listEmergencyNo:(NSNumber *)condo_id WithCallback:(callbackBlock)callback;
-(void)listNotices:(NSNumber *)condo_id res_id:(NSNumber *)res_id pageNo:(NSNumber *)page WithCallback:(callbackBlock)callback;
-(void)listManagement:(NSNumber *)condo_id pageNo:(NSNumber *)page WithCallback:(callbackBlock)callback;
-(void)listEvents:(NSNumber *)condo_id res_id:(NSNumber *)res_id pageNo:(NSNumber *)page WithCallback:(callbackBlock)callback;
-(void)actionOnEvent:(NSNumber *)condo_id res_id:(NSNumber *)res_id event_id:(NSNumber *)event_id action:(NSNumber *)action no_of_person:(NSNumber *)no_of_person WithCallback:(callbackBlock)callback;
-(void)listGallery:(NSNumber *)condo_id res_id:(NSNumber *)res_id  pageNo:(NSNumber *)page WithCallback:(callbackBlock)callback;
-(void)listGalleryItem:(NSNumber *)condo_id g_id:(NSNumber *)g_id WithCallback:(callbackBlock)callback;
-(void)listWebsite:(NSNumber *)condo_id WithCallback:(callbackBlock)callback;
-(void)maintenanceAmount:(NSNumber *)res_id condoID:(NSNumber *)condo_id WithCallback:(callbackBlock)callback;
-(void)payMaintenance:(NSNumber *)condo_id res_id:(NSNumber *)res_id payDate:(NSString *)pay_date maintenance_amount:(NSString *)maintenance_amount maintenance_penalty:(NSString *)maintenance_penalty totalAmount:(NSString *)totalAmount transectionID:(NSString *)transection_id transectionStatus:(NSNumber *)transection_status WithCallback:(callbackBlock)callback;
-(void)paymentConfiguration:(NSNumber *)condo_id WithCallback:(callbackBlock)callback;
-(void)tabConfigration:(NSNumber *)condo_id res_id:(NSNumber *)res_id WithCallback:(callbackBlock)callback;
-(void)listMasterFacility:(NSNumber *)condo_id WithCallback:(callbackBlock)callback;
-(void)listChildFacility:(NSNumber *)condo_id res_id:(NSNumber *)res_id fm_id:(NSNumber *)fm_id change_bk:(NSNumber *)change_bk date:(NSString *)date WithCallback:(callbackBlock)callback;
-(void)addBooking:(NSNumber *)res_id ft_id:(NSNumber *)ft_id change_bk:(NSNumber *)change_bk date:(NSString *)date WithCallback:(callbackBlock)callback;
-(void)listBookingForResident:(NSNumber *)condo_id res_id:(NSNumber *)res_id upcoming:(NSNumber *)upcoming pageNo:(NSNumber *)page WithCallback:(callbackBlock)callback;
-(void)changeBooking:(NSNumber *)res_id ft_id:(NSNumber *)ft_id change_bk:(NSNumber *)change_bk date:(NSString *)date WithCallback:(callbackBlock)callback;
-(void)cancelBooking:(NSNumber *)res_id fb_id:(NSNumber *)fb_id WithCallback:(callbackBlock)callback;
-(void)updateBooking:(NSNumber *)res_id fb_id:(NSNumber *)fb_id transectionID:(NSString *)transection_ID transectionStatus:(NSNumber *)transection_Status WithCallback:(callbackBlock)callback;
-(void)changeOTP:(NSNumber *)resident_id Password:(NSString *)password WithCallback:(callbackBlock)callback;
-(void)addGuestListRequest:(NSNumber *)condo_id block_id:(NSString *)block_id unit_id:(NSString *)unit_id name:(NSString *)name no_of_guest:(NSNumber *)no_of_guest visiting_date:(NSString *)visiting_date WithCallback:(callbackBlock)callback
;
-(void)recentListRequest:(NSNumber *)condo_id block_id:(NSString *)block_id unit_id:(NSString *)unit_id WithCallback:(callbackBlock)callback;
-(void)deleteGuestListRequest:(NSNumber *)glr_id WithCallback:(callbackBlock)callback;
-(void)updateGuestListRequest:(NSString *)name no_of_guest:(NSNumber *)no_of_guest visiting_date:(NSString *)visiting_date glr_id:(NSNumber *)glr_id WithCallback:(callbackBlock)callback;
-(void)updateNotificationData:(NSNumber *)resident_id pageNo:(NSNumber *)page WithCallback:(callbackBlock)callback;
-(void)readUpdateNotification:(NSNumber *)not_id WithCallback:(callbackBlock)callback;
-(void)readUpdateNotice:(NSNumber *)not_id WithCallback:(callbackBlock)callback;
-(void)updateProfile:(NSNumber *)res_id titleNo:(NSNumber *)title first_name:(NSString *)first_name last_name:(NSString *)last_name mobile_no:(NSString *)mobile_no email:(NSString *)email WithCallback:(callbackBlock)callback;
-(void)changePassword:(NSNumber *)res_id old_password:(NSString *)old_password new_password:(NSString *)new_password WithCallback:(callbackBlock)callback;
-(void)updateUnReadGallery:(NSNumber *)gallary_id WithCallback:(callbackBlock)callback;
-(void)updateUnReadEvent:(NSNumber *)gallary_id WithCallback:(callbackBlock)callback;
-(void)quitRentAmount:(NSNumber *)res_id condoID:(NSNumber *)condo_id WithCallback:(callbackBlock)callback;
-(void)fireInsuranceAmount:(NSNumber *)res_id condoID:(NSNumber *)condo_id WithCallback:(callbackBlock)callback;
-(void)sinkingFundAmount:(NSNumber *)res_id condoID:(NSNumber *)condo_id WithCallback:(callbackBlock)callback;
-(void)payInsurance:(NSNumber *)condo_id res_id:(NSNumber *)res_id payDate:(NSString *)pay_date insurance_amount:(NSString *)insurance_amount insurance_penalty:(NSString *)insurance_penalty totalAmount:(NSString *)totalAmount transectionID:(NSString *)transection_id transectionStatus:(NSNumber *)transection_status WithCallback:(callbackBlock)callback;
-(void)payRent:(NSNumber *)condo_id res_id:(NSNumber *)res_id payDate:(NSString *)pay_date rent_amount:(NSString *)insurance_amount rent_penalty:(NSString *)insurance_penalty totalAmount:(NSString *)totalAmount transectionID:(NSString *)transection_id transectionStatus:(NSNumber *)transection_status WithCallback:(callbackBlock)callback;
-(void)payFund:(NSNumber *)condo_id res_id:(NSNumber *)res_id payDate:(NSString *)pay_date fund_amount:(NSString *)fund_amount fund_penalty:(NSString *)fund_penalty totalAmount:(NSString *)totalAmount transectionID:(NSString *)transection_id transectionStatus:(NSNumber *)transection_status WithCallback:(callbackBlock)callback;
@end