//
//  GalleryItemCollectionViewCell.h
//  ResidentApp
//
//  Created by TheAppGuruz-iOS-103 on 08/07/15.
//  Copyright (c) 2015 TheAppGuruz-New-6. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface GalleryItemCollectionViewCell : UICollectionViewCell

@property (strong, nonatomic) IBOutlet UIImageView *ivIcon;
@property (strong, nonatomic) IBOutlet UILabel *lblTitle;

@end
