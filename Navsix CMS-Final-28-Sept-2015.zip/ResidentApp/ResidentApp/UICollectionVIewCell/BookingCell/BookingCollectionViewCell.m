//
//  BookingCollectionViewCell.m
//  ResidentApp
//
//  Created by TheAppGuruz-iOS-103 on 08/07/15.
//  Copyright (c) 2015 TheAppGuruz-New-6. All rights reserved.
//

#import "BookingCollectionViewCell.h"

@implementation BookingCollectionViewCell

@end
