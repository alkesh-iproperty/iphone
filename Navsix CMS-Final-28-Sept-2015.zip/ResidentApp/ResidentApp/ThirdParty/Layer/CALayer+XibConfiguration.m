//
//  CALayer+XibConfiguration.m
//  JoraApp
//
//  Created by Krupa-iMac on 22/02/14.
//  Copyright (c) 2014 TheAppGuruz. All rights reserved.
//

#import "CALayer+XibConfiguration.h"

@implementation CALayer (XibConfiguration)

-(void)setBorderUIColor:(UIColor*)color
{
    self.borderColor = color.CGColor;
}

-(UIColor*)borderUIColor
{
    return [UIColor colorWithCGColor:self.borderColor];
}

@end
