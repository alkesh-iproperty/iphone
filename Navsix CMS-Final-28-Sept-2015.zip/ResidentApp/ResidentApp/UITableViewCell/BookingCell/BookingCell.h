//
//  BookingCell.h
//  ResidentApp
//
//  Created by TheAppGuruz on 09/07/15.
//  Copyright (c) 2015 TheAppGuruz-New-6. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BookingCell : UITableViewCell

@property (nonatomic, strong) IBOutlet UILabel *lblTitle;
@property (nonatomic, strong) IBOutlet UILabel *lblAmount;
@property (nonatomic, strong) IBOutlet UIButton *btnBook;
@property (weak, nonatomic) IBOutlet UILabel *lblBooked;

@end
