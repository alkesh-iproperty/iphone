//
//  ManagementCell.h
//  ResidentApp
//
//  Created by TheAppGuruz on 10/07/15.
//  Copyright (c) 2015 TheAppGuruz-New-6. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ManagementCell : UITableViewCell

@property (nonatomic, strong) IBOutlet UIImageView *ivIcon;
@property (nonatomic, strong) IBOutlet UILabel *lblDesignation;
@property (nonatomic, strong) IBOutlet UILabel *lblName;

@end
