//
//  ProfileBookingCell.h
//  ResidentApp
//
//  Created by TheAppGuruz on 09/07/15.
//  Copyright (c) 2015 TheAppGuruz-New-6. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ProfileBookingCell : UITableViewCell

@property (nonatomic, strong) IBOutlet UILabel *lblTitle;
@property (nonatomic, strong) IBOutlet UILabel *lblCanceled;
@property (nonatomic, strong) IBOutlet UIButton *btnCancel;
@property (weak, nonatomic) IBOutlet UIButton *btnChange;
@end
