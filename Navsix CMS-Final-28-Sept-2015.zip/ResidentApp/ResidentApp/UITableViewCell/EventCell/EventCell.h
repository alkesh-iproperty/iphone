//
//  EventCell.h
//  ResidentApp
//
//  Created by TheAppGuruz-New-6 on 23/07/15.
//  Copyright (c) 2015 TheAppGuruz-New-6. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface EventCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UIImageView *ivEventIcon;
@property (weak, nonatomic) IBOutlet UILabel *lblEventDescription;
@property (weak, nonatomic) IBOutlet UILabel *lblEventDate;

@end
